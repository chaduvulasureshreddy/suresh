<?php 
class CI_Mail
{

}


?>