<?php 
	$lang['success'] = "successfully registered";
	$lang['failed'] = "Registration failed please try again";

?>