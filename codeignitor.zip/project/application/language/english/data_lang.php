<?php 
	$lang['success'] = "successfully registered";
	$lang['failed'] = "Registration failed please try again";
	$lang['logerror'] = "Enter correct username and password";
	$lang['updateg'] = "successfully updated";
	$lang['logerror1'] = "not updated";
	$lang['succ'] = "your message sended";
	$lang['fail'] = "your messaage not send";
	

?>