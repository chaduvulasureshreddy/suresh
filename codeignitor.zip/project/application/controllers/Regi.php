<?php
class Regi extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->helper('form');
		$this->load->database();
		$this->load->library('form_validation');
		 $this->load->model('register');

	}
	public function index()
	{
		$this->form_validation->set_rules('uname','username','required');
		$this->form_validation->set_rules('umail','Email','required');
		$this->form_validation->set_rules('pwd','Password','required');
		if($this->form_validation->run()==FALSE){
		$this->load->view('reg');
		}
		else{
			$name = $this->input->post('uname');
			$email = $this->input->post('umail');
			$password = $this->input->post('pwd');
			$pass = password_hash($password,PASSWORD_DEFAULT);
			// echo $name,$email,$pass;
			$data = array('name'=>$name,'mail'=>$email,'password'=>$pass);
			// print_r($data);exit;
			$rt = $this->register->demo($data);
			if($rt=='success')
			{
				echo "successfully register";
			}
			else{
				echo "registrstion fail";
			}

		}
	}

	public function log()
	{
		$this->form_validation->set_rules('name','User Name','required');
		$this->form_validation->set_rules('passw','Password','required');
		if ($this->form_validation->run()==FALSE) {
			$this->load->view('login');		
		}
		else{
			$gy = $this->register->login();
			if($gy=='	ssuccess')
			{
				echo "entered correct details";
			}
			else{
				echo "enter worng details";
			}
		}
	}

}
?>