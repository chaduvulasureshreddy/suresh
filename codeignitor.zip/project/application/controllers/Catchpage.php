<?php
	class Catchpage extends CI_Controller
	{
		public function index()
		{
			$this->output->cache(1);
			$this->load->view('Test');
		}
		public function dalete_file_catch()
		{
			$this->output->delete_cache('Catchpage');
		}
	}
?>