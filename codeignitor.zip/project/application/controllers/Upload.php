<?php
	class Upload extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			$this->load->helper('form');
			$this->load->helper('html');

		}
		public function index()
		{
			$this->load->view('upload',array('error' => ' ' ));
		}
		public function do_upload()
		{
			// $dat = $_FILES['uploadfile'];
			// print_r($dat);exit;

			$config['upload_path'] = './upload/';
			$config['allowed_types'] = 'jpg|png|gif';
			$config['max_size'] = 100;
			$config['max_width'] = 1024;
			$config['max_height'] = 700;

			$this->load->library('upload',$config);
			if(!$this->upload->do_upload('uploadfile')) {
				$error = array('error'=>$this->upload->display_errors());
				$this->load->view('upload',$error);
				// echo  "not uploaded";
			}
			else{
				$data = array('upload_data'=>$this->upload->data());
				$this->load->view('upload_success',$data);
				// echo "uploaded";	
				
			}
		}
		public function pass()
		{
			$str = "suresh reddy";
			$gt = "jhg";
			echo $str.br(1);
			// echo password_hash($str, PASSWORD_DEFAULT)."\n";
			// echo password_needs_rehash($str,PASSWORD_DEFAULT);
			$rt = convert_uuencode($str);
			echo "somr".$rt.br(1);
			echo convert_uudecode($rt).br(1);
			echo PASSWORD_BCRYPT('suresh');
			echo $this->PASSWORD_BCRYPT()->password_verify('suresh');
		}
	}

?>