<?php 
class Loadnewlibraries extends CI_Controller
{
	public function hello()
	{
		$this->load->library('mail');
		echo $this->mail->show();
	}
	
} 
?>