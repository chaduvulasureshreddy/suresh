<?php
	class Main extends CI_Controller
	{
		public function __construct()
		{
			parent::__construct();
			 $this->load->database();
			 $this->load->helper('form');
			 // $idiom = $this->session->get_userdata('language');
			 $this->lang->load('data','english');
			
			 $this->load->helper('url');
			 $this->load->helper('date');
			 $this->load->library('pagination');
			 $this->load->library('session');
			 $this->load->model('main_model');
			 $this->load->library('form_validation');

		} 
		public function index()
		{
			 $this->form_validation->set_rules('user_name','username','required');
			 $this->form_validation->set_rules('user_email','Email','required');
			 if($this->form_validation->run()==FALSE){
			 	// $data['error']=array('error'=>'');
				$this->load->view('ind');
			}

		}
		public function regaction()
		{	
			
			$in =  $this->main_model->regist();
			$config['upload_path'] = "./upload/";
			$config['allowed_types'] = 'gif|png|jpg';
			$this->load->library('upload',$config);
			if(!$this->upload->do_upload('tuch')){
				 $data['error'] = $this->upload->display_errors();
				 // print_r($data['error']);
				$this->load->view('ind');
				
			}
			else{
			if($in){
					$this->session->set_flashdata('success',$this->lang->line('success'));
					redirect(base_url());
				}
				else{
					$this->session->set_flashdata('failed',$this->lang->line('failed'));
					redirect(base_url());
				}
			}
		}
		public function district()
		{
			$state = $this->input->post('state');
			$disarray = array(
                        "andhra" => array("Kurnool", "Chittoor", "Kadapa"),
                        "telangana" => array("Hyderabad", "Warangal", "Secunderab"),
                        "assam" => array("Guwahati", "Majuli", "Dibrugarh")
                    );
			if($state !== 'Select')
			{
	           echo "<label>City:</label>";
	            echo "<select>";
	            foreach($disarray[$state] as $value)
	            {
	                echo "<option>". $value . "</option>";
            	}
            	echo "</select>";
        	} 
        }
        public function namecheck()
        {
        	$name = $this->input->post('user_name');
        	$this->db->select('*');
        	$this->db->from('my_users');
        	 $this->db->where('name',$name);
        	 $que =$this->db->get();
        	if($que->num_rows()>0){
        		echo "not ok";
        	}
        	else{
        		echo "ok";
        	}
        }
        public function mailcheck()
        {	
        	   $mail = $this->input->post('user_email');
        	$this->db->select('*');
        	$this->db->from('my_users');
        	 $this->db->where('loginid',$mail);
        	 $que =$this->db->get();
        	if($que->num_rows()>0){
        		echo "notok";
        	}
        	else{
        		echo "ok";
        	}
        }
        public function users()
        {
        	$config = array();
			$config["base_url"] = base_url() . "main/users";
			$total_row = $this->main_model->record_count();
			$config["total_rows"] = $total_row;
			$config["per_page"] = 5;
			$config['use_page_numbers'] = TRUE;
			$config['num_links'] = $total_row/$config["per_page"];
			$config['cur_tag_open'] = '&nbsp;<a class="current">&nbsp;&nbsp;';
			$config['cur_tag_close'] = '</a>';
			$config['next_link'] = '--Next--';
			$config['prev_link'] = '--Previous--';
			// echo $total_row;exit;
			$this->pagination->initialize($config);
			// echo $this->uri->segment(3);exit;
			// $page =0;
			$grt = $this->uri->segment(3);
				//   if($this->uri->segment(3)==2){
			  // $page = (5*$this->uri->segment(3))/2;
				// 	 // $page = $page+$config["per_page"];
				//   	$page = 5;
				 
				//   }	
				//   else if($this->uri->segment(3)==3){
				// 	 $page=10;
				//  }
				// 	else if ($this->uri->segment(3)==4) {
				// 		$page=
				// 	}
				// // for($i=0;$i<$total_row;$i++)
				// {
				// 	 // $page = 0;
				// 	 if($this->uri->segment(3)==$i){
				// 		$page=$page+$config["per_page"];
				// 		echo $page;	
				// 	 }

				// }	
				

				// $page =$i;
			if($grt>0){
				$page = ($grt-1)*$config["per_page"];
			}

			
			else{
			$page = 0;
			}
		
			$data["results"] = $this->main_model->fetch_data($config["per_page"], $page);
			$str_links = $this->pagination->create_links();
			$data["links"] = explode('&nbsp;',$str_links);

			// View data according to array.
			$this->load->view("userslist", $data);
		
			        	
        	// $gt = $this->main_model->user();
        	// $fg['data'] = $gt->result_array();
        	// $this->load->view('userslist',$fg);
        }
        public function userlogin()
        {
        	$this->load->view('loginpage');
        }
        public function logaction()
        {
        	$date = date_create();
			$ti =  date_timestamp_get($date);
			 $af = array('time'=>$ti);
        	$ft = $this->main_model->logi();
        	if($ft->num_rows()==1){
			$df= $ft->result_array();

			$this->session->set_userdata('suresh',$df);
			$this->session->set_userdata('reddy',$af);
			redirect('main/dashboard');
			}
			else 
			{
				$this->session->set_flashdata('logerror',$this->lang->line('logerror'));
				// $sm = array('logerror'=>'enter correct username and password');
				// mark_as_flash($sm);
				
				// $this->session->set_tempdata('logerror','enter correct username and password',25);
				redirect('main/userlogin');
			}
        	
        }
        public function del()
        {
        	$this->main_model->dele();
        }
        public function dashboard()
        {
        	$ft = $this->main_model->user();
        	$fg['some'] = $ft->result_array();
        	$this->load->view('dashboard',$fg);
        }
        public function edit()
        { 	
        	$gr['tan'] = $this->main_model->edit();
        	$this->load->view('upda',$gr);
        }
        public function updat()
        {      
			$gf = $this->main_model->upac();
			if($gf>0){
				$this->session->set_flashdata('updateg',$this->lang->line('updateg'));
				redirect('userlist');
			}
			else{
				$this->session->set_flashdata('logerror',$this->lang->line('logerror1'));
				redirect('userlist');
			}
        }
        public function noti()
        {
        	$no = $this->main_model->get_note();
        	$ft['data'] = $no->result_array();

        	$this->load->view('notification',$ft);
        }
        public function logout()
        {
        	$this->session->unset_userdata('suresh');
        	$this->session->sess_destroy();
        	redirect('login');
        }
        public function notiaction()
        {
        	$com = $this->main_model->notify();
        	if($com == 1){
        		$this->session->set_flashdata('succ',$this->lang->line('succ'));
        		redirect('main/dashboard');
        	}
        	else{
        		$this->session->set_flashdata('fail',$this->lang->line('fail'));
        		redirect('main/dashboard');
        	}
        }
        public function passwo()
        {
        	$str = "suresh";
        	$rt = password_hash($str, PASSWORD_DEFAULT)."\n";
        	// echo $rt;exit;
        	$ht = '$2y$10$OIUmeAvt1qKTn6muGYSjfOV9WJHGKLyaffoZn5.P06kbBMasbC5Za';
        	// echo password_verifyrd_needs_rehash($ht,"s")."<br/>";
        	//  echo BCrypt($str);
        	 if(password_verify('suresh',$ht)){
        	 	echo "password is valied";
        	 }
        	 else{	
        	 	echo "not valied";
        	 }
        	  password_needs_rehash($ht,PASSWORD_DEFAULT);
   //      	$this->load->library('bcrypt');
   //      	$password = 'hunter2';
			// $hash = $this->bcrypt->hash_password($password);
			// echo $hash;
        }
        public function codeconv()
		{
			$this->load->library('encrypt');
			$dtr = "suresh working in rize software solutions";
			echo $this->encrypt->encode($dtr);
		}
		public function send_mail()
		{
			$sender = $this->input->post('user');
			$reci = $this->input->post('use');
			$subject = $this->input->post('sub');
			$body = $this->input->post('bod');
			$comment = $this->input->post('com');
			$this->load->library('email');
			$this->email->from($sender,'suresh');
			$this->email->to($reci);
			$this->email->subject($subject);
			$this->email->message($body);
			$this->email->message($comment);
			$this->email->send();
		}


	}
	
?>