<?php
class Ajax_demo extends CI_Controller
{
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->model('Ajax_model');
	}
	public function index()
	{

		$this->form_validation->set_rules('uname','User Name','required');
		$this->form_validation->set_rules('umail','Mail','required');
		$this->form_validation->set_rules('pwd','Password','required');
		if($this->form_validation->run()==FALSE)
		{
		$this->load->view('demo');
		}
		else
		{
			$gh = $this->Ajax_model->insert_row();
			if($gh==1)
			{
				echo "Register successfully";
			}
			else
			{
				echo 'fail to register tryagain';
			}	
		}
	}
	public function namecheck()
	{
		$na = $this->input->post('name');
		// $na = 'csr';
		$this->db->select('*');
		$this->db->from('suresh');
		$this->db->where('name',$na);
		$qu = $this->db->get();
		// echo $qu->num_rows();exit;			
		if($qu->num_rows()>0)
		{
			echo "fail";
		}
		else
		{
			echo 'success';
		}
	}
}

?>