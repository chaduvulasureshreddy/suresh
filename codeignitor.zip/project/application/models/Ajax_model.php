<?php 
 class Ajax_model extends CI_Model
 {
 	public function insert_row()
 	{
 		$na = $this->input->post('uname');
 		$ma = $this->input->post('umail');
 		$pass = $this->input->post('pwd');
 		$data = array('name'=>$na,'mail'=>$ma,'password'=>$pass);
 		$qu = $this->db->insert('suresh',$data);
 		return  $this->db->affected_rows();
 	}
 }

?>