<?php 
	class Main_model extends CI_Model
	{
		public function regist()
		{
			$name = $this->input->post('user_name');
			$mail = $this->input->post('user_email');
			$psd = $this->input->post('userpass');
			// $pwd = password_hash($psd, PASSWORD_DEFAULT);
			$address = $this->input->post('address');
			$gender = $this->input->post('gender');
			$state = $this->input->post('state');	
			$city = $this->input->post('city');	
			$img = $_FILES['tuch'];
			$fil = $_FILES['tuch']['name'];
			// $path = $_FILES['tuch']['tmp_name'];
			// $target_path  = "upload/";	
			// $img_path =$target_path.$fil;
			// move_uploaded_file($path, $img_path);
			$data = array('name'=>$name,'loginid'=>$mail,'password'=>$psd,'address'=>$address,'gender'=>$gender,'state'=>$state,'city'=>$city,'image'=>$fil);
			$in = $this->db->insert('my_users',$data);
			return $in;
		}
		public function name()
		{
			return $this->input->post('user_name');
		}
		// public function user()
		// {
			// $this->db->select('*');
			// $this->db->from('my_users');
			// $ft = $this->db->get();
			// return $ft;
			public function fetch_data($limit,$id) {
			 $this->db->limit($limit,$id);
			// $this->db->where('id', 76);
			 $this->db->order_by('S_NO','DESC');
			$query = $this->db->get("my_users");
			// echo $query->num_rows();exit;
			if ($query->num_rows() > 0) {
			foreach ($query->result() as $row) {
			$data[] = $row;
			}

			return $data;
			}
			return false;
			}
		// }
		public function record_count() {
			return $this->db->count_all("my_users");
		}
		public function user()
		{
			$this->db->select('*');
			$this->db->from('my_users');
			$ft = $this->db->get();
			return $ft;
		}
		public function logi()
		{
			$un = $this->input->post('username');
			$pwd = $this->input->post('pass');
			$this->db->select('*');
			$this->db->from('my_users');
			$this->db->where(array('loginid'=>$un,'password'=>$pwd));
			$ft = $this->db->get();
			return $ft;	
		}

		public function dele()
		{
			$id = $_POST['id'];
			$this->db->where('S_NO',$id);
			if($this->db->delete('my_users'))
			{
			 	echo 'deleted';

			}
			 else
			{
			 	echo "not deleted";
			}

		}
		public function edit()
		{
			$id = $this->uri->segment(3);
			$this->db->select('*');
			$this->db->from('my_users');
			$this->db->where('S_NO',$id);
			$get = $this->db->get();
			return $get;
		}
		public function upac()
		{
			$id = $this->input->post('id');
			$name = $this->input->post('user_name');
			$mail = $this->input->post('user_email');
			$psd = $this->input->post('userpass');
			$address = $this->input->post('address');
			$gender = $this->input->post('gender');
			$state = $this->input->post('state');	
			$city = $this->input->post('city');
			$pa = $_FILES['imageUpload']['name'];
			 // echo $pa;exit;
			$pat = $_FILES['imageUpload']['tmp_name'];

			if(!$pa)
			{
				$this->db->select('image');
				$this->db->from('my_users');
				$this->db->where('S_NO',$id);
				$ft = $this->db->get();
				$ge = $ft->result_array();
				
				$pa = $ge[0]['image'];
				
			}
			else{
			 $target_path  = "upload/";
			 $path =$target_path.$pa;
			 
			 move_uploaded_file($pat, $path);
			}			
			$data = array('name'=>$name,'loginid'=>$mail,'password'=>$psd,'address'=>$address,'gender'=>$gender,'state'=>$state,'city'=>$city,'image'=>$pa);
			$this->db->where('S_NO',$id);
			$in = $this->db->update('my_users',$data);
			$en = $this->db->affected_rows();
			return $en;	
		}
		public function notify()
		{
			$sender = $this->input->post('user');
			$reci = $this->input->post('use');
			$subject = $this->input->post('sub');
			$body = $this->input->post('bod');
			$comment = $this->input->post('com');
			$in = array('sender'=>$sender,'reciver'=>$reci,'subject'=>$subject,'body'=>$body,'commant'=>$comment);
			$this->db->insert('message',$in);
			$ft = $this->db->affected_rows();
			return $ft;
		}
		public function get_note()
		{
			$gt = $this->session->userdata('suresh');
			$sender = $gt[0]['name'];
			
			$this->db->select('*');

			$this->db->from('message');
			
			$this->db->where('reciver',$sender);
			$this->db->order_by('meg_no','DESC');		

			$gh = $this->db->get();
			return $gh;
		}
		
		
	}
?>