<?php
	class Register extends CI_Model
	{
		public function demo($data)
		{
		
			if($this->db->insert('suresh',$data))
			{
				return "success";
			}
			else{
				return 'fail';
			}
		}
		public function login()
		{
			
	        	$na = $this->input->post('name');
				$pa = $this->input->post('passw');
				  // echo $na,$pa;exit;
				$this->db->select('password');
				$this->db->from('suresh');
				$this->db->where('name',$na);
				$query = $this->db->get();
				$rt = $query->result_array();
				// print_r($rt);exit;
				$ht = $rt[0]['password'];
				// echo $ht;exit;
			 	// echo $pa;exit;
				 if(password_verify($pa,$ht)){
	        	 	return "success";
	        	 }
	        	 else{
	        	 	return 'fail';
	        	 }



		}
	}

?>