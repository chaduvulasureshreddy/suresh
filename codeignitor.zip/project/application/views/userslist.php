<!-- <!DOCTYPE html>
<html>
<head>
	<title>user list</title>
		<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
	
<body>

<?php //include('nav.php'); ?>
<span style="color: green"><?php //echo $this->session->flashdata('updateg	'); ?></span>
<span style="color: red"><?php //echo $this->session->flashdata('logerror'); ?></span>		
<table border="1" width= 100% id="myTable" >

	<tr>
		<th>S_No</th><th>Name</th><th>Email</th><th>password</th><th>address</th><th>Gender</th><th>State</th><th>City</th><th>images</th><th>Edit</th><th>Delete</th>
	</tr>




	<?php //foreach($data as $row){ ?>

		<tr id="tr_<?php//echo $row['S_NO']; ?>">
			<td><?php //echo $row['S_NO']; ?></td>
			<td><?php //echo $row['name']; ?></td>
			<td><?php //echo $row['loginid']; ?></td>
			<td><?php //echo $row['password']; ?></td>
			<td><?php //echo $row['address']; ?></td>
			<td><?php //echo $row['gender']; ?></td>
			<td><?php //echo $row['state']; ?></td>
			<td><?php //echo $row['city']; ?></td>


			<td><img src="<?php// echo base_url().$row['image']; ?>" width="60px" height="50px"> </td>
			 <td><?php //echo anchor("main/edit/{$row['S_NO']}",'edit'); ?></td>
			<td><a href="javascript:void(0)" data-id="<?php //echo $row['S_NO'];  ?>" action="<?php //$row['image']; ?>" class="delete_element">Delete</a><td>
		</tr>
	<?php //	} ?>

</table>
	<script  src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
		$(document).on('click','.delete_element',function(){
			var id = $(this).data('id');
			// alert(id);
			if(confirm('Do you want delete this row?'))
				$.ajax({
					type : 'post',
					url :'/project/index.php/main/del',
					data:{'id':id},

					success:function(data){
						if(data=='deleted'){
							$("#tr_"+id).remove();
						}
					}
				});
});
</script>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
	<script>
	$(document).ready(function(){
    $('#myTable').DataTable();	
	});
	</script>
</head>

</body>
</html> -->
<html>
<head>
<title>Codelgniter pagination</title>

<style>
	a{
		text-decoration: none;

	}
	li a {
		
		padding: 5px;
	
		background-color: lightblue;
	}
</style>
</head>
<body>
<div class="main">
<div id="content">
<?php include('nav.php'); ?>
<h3 id='form_head'>Codelgniter Pagination Example </h3><br/>
<span style="color: green"><?php echo $this->session->flashdata('updateg'); ?></span>
<span style="color: red"><?php echo $this->session->flashdata('logerror'); ?></span>	

<table border="1" width= 100% id="myTable" style="border-collapse: collapse;">
 <!-- <?php //echo base_url();exit; ?> -->

	<tr>
		<th>S_No</th><th>Name</th><th>Email</th><th>password</th><th>address</th><th>Gender</th><th>State</th><th>City</th><th>images</th><th>Edit</th><th>Delete</th>
	</tr>

<?php foreach($results as $row){ ?>

		<tr id="tr_<?php echo $row->S_NO; ?>">
			<td><?php echo $row->S_NO; ?></td>
			<td><?php echo $row->name; ?></td>
			<td><?php echo $row->loginid; ?></td>
			<td><?php echo $row->password; ?></td>
			<td><?php echo $row->address; ?></td>
			<td><?php echo $row->gender; ?></td>
			<td><?php echo $row->state; ?></td>
			<td><?php echo $row->city; ?></td>


			<td><img src="<?php echo base_url()."upload/".$row->image; ?>" width="60px" height="50px"> </td>
			 <td><?php echo anchor("main/edit/{$row->S_NO}",'edit'); ?></td>
			<td><a href="javascript:void(0)" data-id="<?php echo $row->S_NO;  ?>" action="<?php $row->image; ?>" class="delete_element">Delete</a><td>
		</tr>
	<?php } ?>

</table>

<div id="pagination">
<ul class="tsc_pagination" style="list-style-type: none;">

<!-- Show pagination links -->
<?php foreach ($links as $link) {
echo "<li style='float:left;'>". $link."</li>";
} ?>
</ul>
</div>
</div>
</div>
</body>
<script  src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
		$(document).on('click','.delete_element',function(){
			var id = $(this).data('id');
			// alert(id);
			if(confirm('Do you want delete this row?'))
				$.ajax({
					type : 'post',
					url :'/project/index.php/main/del',
					data:{'id':id},

					success:function(data){
						if(data=='deleted'){
							$("#tr_"+id).remove();
						}
					}
				});
});
</script>
</html>