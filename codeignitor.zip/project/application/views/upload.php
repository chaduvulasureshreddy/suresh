<!DOCTYPE html>
<html>
<head>
	<title>File Upload</title>
</head>
<body>
<?php echo $error;; ?>
<?php echo form_open_multipart('upload/do_upload'); ?>
	<label>Upload</label>
	<input type="file" name='uploadfile'><br/><br/>
	<input type="submit" name="sub"	>
<?php echo form_close(); ?>
</body>
</html>