<!DOCTYPE html>
<html>
<head>
	<title>Login Action</title>
</head>
<body>
	<?php echo form_open('regi/log'); ?>
		<label>user name</label><input type="text" name="name">
		<span style="color: red;"><?php echo form_error('name'); ?></span><br/>
		<label>password</label><input type="password" name="passw">
		<span style="color: red;"><?php echo form_error('passw'); ?></span><br/>
		<input type="submit" value="Login" name="log">
	<?php echo form_close(); ?>
</body>
</html>