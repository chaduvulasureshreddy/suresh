<!DOCTYPE html>
<html>
<head>
	<title>Form</title>
</head>
<body>

<?php// echo validation_errors(); ?>
<?php echo form_open('Ajax_demo/index'); ?>
	<label>User name</label>:<input type="name" id="un" name="uname">
	<span id="name_status"></span> 
	<span style="color:red;"><?php echo form_error('uname'); ?></span><br/>
	<label>Mail</label>:<input type="email" id="um" name="umail"><span style="color:red;"><?php echo form_error('uname'); ?></span><br/>
	<label>password</label>:<input type="password" id="pwd" name="pwd"><span style="color:red;"><?php echo form_error('uname'); ?></span><span id="df"></span><br/>
	<input type="submit" value="submit" name="sub">

<?php echo form_close(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script>
	$(document).ready(function(){
		$('#un').keyup(function(){
			var x = this.value;
			// alert(x);
			if(x){
				$.ajax({
					type: 'post',
					url : '/project/index.php/ajax_demo/namecheck',
					data:{'name':x},
					success:function(data){
						if(data=='success'){
							 $('#name_status').text('ok');
							 
						}
						else{
							 
							 $('#name_status').text('already exists');
						}
					}
					
				});
				
			}
		});
		$('#pwd').keyup(function(){
			var y = this.value;
			// alert(y);
			var z = y.length;
			// alert(z);
			if(z<3){
				$('#df').text('Week password');
			}
			else if(3<z<6){
				$('#df').text('Medium password');

			}
			else{
				$('#df').text('strong password');
			}

		});





	});
</script>

</body>
</html>