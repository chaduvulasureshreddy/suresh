<!DOCTYPE html>
<html>
<head>
<style type="text/css">
  *{
    margin:0px;
    padding:0px;
  }
  body{
    background-color: gray;
    color: white;
  }
  input{
    padding: 2px 25px 2px 0px;

    margin: 5px;
  }
  lable{
    color:#ffe500;
  }
  nav a{
    padding: 10px;
    margin-left:43px ;
    border: 2px solid black;
    text-decoration: none;
  }
  .he{
    margin-top: 25px !importent;
  }

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
          //-------------------Image validatio code START------------------------------//
            $("select.state").change(function(){

            var selectedState = $(".state option:selected").val();

            $.ajax({

                type: "POST",

                url: "main/district",

                data: { state : selectedState } 

            }).done(function(data){

                  $("#response").html(data);

            });

        });
         var file = document.getElementById('demo');

  file.onchange = function(e){
      var ext = this.value.match(/\.([^\.]+)$/)[1];
      switch(ext)
      {
          case 'jpg':
          case 'bmp':
          case 'png':
          case 'tif':
              
              break;
          default:
              alert('not allowed');
              this.value='';
      }


  };
    });

 //------------------------------image code END ------------------------------------------///

function checkname()
{
 var name=document.getElementById( "UserName" ).value;
  
 if(name)
 {
  $.ajax({
  type: 'post',
  url: 'main/namecheck',
  data: {
   user_name:name,
  },
  success: function (response) {
   $( '#name_status' ).html(response);
   if(response=="OK")  
   {
    return true;  
   }
   else
   {
    return false; 
   }
  }
  });
 }
 else
 {
  $( '#name_status' ).html("");
 // $('sub').hide();
  return false;
 }
}

function checkemail()
{
 var email=document.getElementById( "UserEmail" ).value;
  
 if(email)
 {
  $.ajax({
  type: 'post',
  url: 'main/mailcheck',
  data: {
   user_email:email,
  },
  success: function (response) {
   $( '#email_status' ).html(response);
   if(response=="OK") 
   {
    return true;  
   }
   else
   {
    document.getElementById('sub').style.disabled= 'true';

    return false; 
   }
  }
  });
 }
 else
 {
  $( '#email_status' ).html("");
  $('sub').hide();
  return false;
 }
}

function checkall()
{
 var namehtml=document.getElementById("name_status").innerHTML;
 var emailhtml=document.getElementById("email_status").innerHTML;

 if((namehtml && emailhtml)=="OK")
 {
  return true;
 }
 else
 {
  return false;
 }
}
//------------------username START------------------------//
// if(name)
//   $.ajax({
//   type: "POST",
//   url: "new_project.php",
//   data: "username=" + $('#id_of_username_input'),
//   success: function(retval){
//     if (retval == true)
//       // Username not in use, tell your visitor
//     else {
//       "Username in use";
//     }
//   }
// }};
//---------------------user name END----------------//

</script>
<script type="text/javascript">
  function myFunction(){
      var name = document.getElementById("UserName").value;
      var email = document.getElementById("UserEmail").value;
    var password = document.getElementById("UserPassword").value;
    var password1 = document.getElementById("cpassword").value;
    
  if(password != password1){
      alert("pasword must match");
      return false;

    }
    // else if(name == strlen(10)){
    //       alert("Fill Your name");
    //       return false;

    //     }
    //     else if(email == loginid){
    //       alert("must fill");
    //       return false;
    //     }
    return true;

  }

</script>
<script>
$var = document.getElementById('name_status');

</script>
</head>

<body>
<header>
<?php
  include("nav.php");
?>

</header>

<h2 style="color: blue;text-align: center;">Student Registration Form</h2>
    
<?php echo form_open('main/regaction',array('enctype'=>'multipart/form-data ')); ?>
    <center>
<table>

<tr>
<td><lable>UserName:</lable></td>
 <td><input type="text" name="user_name" id="UserName" required onkeyup="checkname();">
 <span id="name_status"></span></td>
 
 </tr>
 <tr>
 <td><lable>Email:</lable></td>
 <td><input type="text" name="user_email" id="UserEmail" required onkeyup="checkemail();">
 <span id="email_status"></span></td>
 </tr>
 
 <tr>
 <td><lable>password:</lable></td>
 <td><input type="password" name="userpass" id="UserPassword" required></td>
 </tr>
 
<tr>
<td><lable>confirm password</lable></td>
<td><input type="password" name="cpwd" required id="cpassword"></td>
</tr>

<tr>
    <td><lable>Address:</label></td>
    <td><textarea  rows="4" cols="40" name="address" required></textarea></td>
</tr>
<tr>
    <td><lable>Gender:</lable></td>
    <td><input type="radio" value="male" name="gender" required>Male 
    <input type="radio" name="gender" value="female">Female</td>

</tr>

            <tr>

                <td>

                    <lable>Your Location:</lable>
                </td>
                <td>

                    <select class="state" name="state">

                        <option value="">State</option>

                        <option value="andhra" >andhra</option>

                        <option value="telangana">telangana</option>

                        <option value="assam">assam</option>

                    </select>


                
          <select id="response" name="city"><option value="">City</option></select>
                </td>

            </tr>

   
        <tr>
    <td><lable>Upload image:</lable></td>
    <td><input type="file" name="tuch" value="" id="demo" required="">
        </td>

</tr>





 <tr>
 <td colspan="4" align="center">
 <input type="submit" id="sub" name="submit_form" value="Submit" onclick="return myFunction()">
 <input type="reset" >
</td>
</tr>
</table>
<span style="color:green;font-size: 26px;">
  <?php  
    if(@$_REQUEST['msg']=='succ'){
      echo "You have Successfully Registered";
    }
  ?>
</span>
<span style="color;red;font-size: 26px;">
  <?php  
    if(@$_REQUEST['msg']=='fail'){
      echo "rigister failed please try again";
    }
  ?>

</span>

  


</form>
<script>
  function myFunction(){
  var z =document.getElementById('name_status').innerHTML;
  //alert(z);
    var x = z.length;
    //alert(x);
    if (x>2 ) {
       //document.getElementById('ck').style.visibility = 'disable';
       alert("User name already exists,please try with another user name");
       document.getElementById('UserName').focus();
       return false;
    }
    
    //alert();
    //alert(z);
  //alert(document.suresh.value);
  }

</script>
</center>
</body>
</html>

