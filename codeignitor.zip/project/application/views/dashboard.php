<?php
$fg = $this->session->userdata('suresh');
$tim = $this->session->userdata('reddy');
$tr =  $tim['time'];


// echo now()."<br/>";
$dis = now()-$tr;
if($dis>3600){
	$this->session->unset_userdata('suresh');
	$this->session->unset_userdata('reddy');
        	$this->session->sess_destroy();
        	redirect('main/userlogin');
}
else{
	// $this->session->unset_userdata('reddy');
	$tr = now();



 

if($fg)
{	
?>
<!DOCTYPE html>
<html>
<head>
	<title> profile</title>
	<style type="text/css">
	label{
		padding: 5px;
		margin:5px;
	}
	input,select{
		padding: 5px;
		margin:15px;
	}
	textarea{
			padding: 5px;
		margin:15px;

	}
	.a{
		 text-decoration: none;
		 border:2px solid black;
		 background-color: red;
		 color:white;
		 padding: 3px;
		 margin-left: 15px;
	}
	</style>
</head>
<body>
<?php echo form_open('main/notiaction'); ?>
	<table >
		<tr>
			<td><input type="hidden" name="user" value="<?php echo $fg[0]['name']; ?>" ></td>
			<td>&nbsp;</td>
		</tr>
		<tr>
			<td><label>users</label></td>
			<td>
				<select name="use" id="sel">
					<option>---users---</option>
					<?php 
						foreach($some as $row)
						{
							if($fg[0]['name']!=$row['name'])
							{

								echo "<option value='". $row['name'] ."'>" .$row['name'] ."</option>" ;
								echo $row['name'];	
							}

						}
					?>
				</select><span id="sd" style="color: red;"></span>
			<td>

		</tr>
		<tr>
			<td><label>subject</label></td>
			<td><input type="text" id="fb" name="sub"><span id="gf" style="color:red;"></span>

		</tr>
		<tr>
			<td><label>Body</label></td>
			<td><textarea rows="10" cols="60" name="bod"></textarea></td>
		</tr>
		<tr>
			<td><label>Comment</label>
			<td><textarea rows="5" cols="60" name="com"></textarea></td>
		</tr>
		<tr>
			
			<td style="text-align: center;" colspan="2"><input type="submit" name="send" onclick="return myFunction()"  value="submit"></td>
		</tr>
		<tr>
			<td colspan="2" style="color: green; text-align: center;">
				<?php
					echo $this->session->flashdata('succ');
					echo $this->session->flashdata('fail');
				?>
			</td>
		</tr>
		<tr>
			<td><?php echo anchor('notification','Notifications',array('class'=>'a')); ?></td>
			<td><?php echo anchor('logout','Logout',array('class'=>'a')); ?></td>
		</tr>
		

	</table>
</form>
<script type="text/javascript">
	function myFunction(){
	var x = document.getElementById('fb').value;
	var y = document.getElementById('sel').value;
	
	
	if(y=="---users---")
	{
		document.getElementById('sd').innerHTML="select any one user";
	return false;
	}
	else if(x==""){
		document.getElementById('gf').innerHTML="please enter subject";
		return false;
	}
	else{
		return true;
	}
	}
</script>
</body>
</html>
<?php
}
else{
	$this->session->set_flashdata('logi','if you want to send messages, please login with your username and password');
	redirect('main/userlogin');
}
}
?>




