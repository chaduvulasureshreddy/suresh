    <nav style="background: lightblue;min-height: 50px;color:blue;margin-top: 20px; ">
      <?php echo anchor(base_url(),'Registration',array('class'=>'he')); ?>
      <?php echo anchor('userlist','Users_list',array('class'=>'he')); ?>
       <?php echo anchor('login','Login',array('class'=>'he')); ?>    
      
      
    </nav>