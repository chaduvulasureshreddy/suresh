<!DOCTYPE html>
<html>
<head>
<style type="text/css">
  *{
    margin:0px;
    padding:0px;
  }
  body{
    background-color:white ;
    color: black;
  }
  input{
    padding: 2px 25px 2px 0px;

    margin: 5px;
  }
  lable{
    color:#ffe500;
  }
  nav a{
    padding: 10px;
    margin-left:43px ;
    border: 2px solid black;
    text-decoration: none;
  }
  .he{
    margin-top: 25px !importent;
  }
  img{
    width: 75px;
    height: 75px; 
  }

</style>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
<script type="text/javascript">
 $(document).ready(function(){
          //-------------------Image validatio code START------------------------------//
            $("select.state").change(function(){
            var selectedState = $(".state option:selected").val();
            $.ajax({
                type: "POST",
                url: "/project/index.php/main/district",
                data: { state : selectedState } 
            }).done(function(data){
                  $("#response").html(data);
            });
        });
         var file = document.getElementById('demo');
  file.onchange = function(e){
      var ext = this.value.match(/\.([^\.]+)$/)[1];
      switch(ext)
      {
          case 'jpg':
          case 'bmp':
          case 'png':
          case 'tif':     
              break;
          default:
              alert('not allowed');
              this.value='';
      }
  };
    $("#UserName").keyup(function(){
      var x =this.value;
      if(x)
      {
        $.ajax
        ({
          type : 'post',
          url :'/project/index.php/main/namecheck',
          data :{'user_name':x},
          success:function(response){
            if(response=='ok'){
              $('#name_status').text('ok');
              $('#name_status').css('color','green');
            }else{
              $('#name_status').text('already exists'); 
              $('#name_status').css('color','red'); 
            }
          }
        });
      }
    });
    $('#UserEmail').keyup(function()
        {
          var mai = this.value;
          if(mai)
          {
           $.ajax({
              type : 'post',
                url :'/project/index.php/main/mailcheck',
                data:{'user_email':mai},
                success:function(response)
                {
                  if(response=='ok')
                  {
                    $('#email_status').text('ok');
                    $('#email_status').css('color','green');
                  }
                  else
                  {
                    $('#email_status').text('already exists');
                    $('#email_status').css('color','red'); 
                  }
                }
          });
        }
    });
    $('#UserPassword').keyup(function(){
      var pass = this.value;
      var password_length = pass.length;
      // alert(password_length);
      if(password_length>2 && password_length<6){
        $('#pas_status').text('your password will be week');
        $('#pas_status').css('color','red');
      }
      else if(password_length>5 && password_length<8 ){
        $('#pas_status').text('your Password will be strong');
        $('#pas_status').css('color','green'); 
      }
      else{
         $('#pas_status').text('The password length must be 3 to 7');
         $('#pas_status').css('color','red'); 

       
      }
      

    });
    $('#cpassword').keyup(function(){
      var cpass = this.value;
      var pass = $('#UserPassword').val();
      if(cpass!=pass){
        $('#cpas_status').text('password must be mach');
         $('#cpas_status').css('color','red'); 
      }
      else if(cpass==pass){
        $('#cpas_status').text('password mached');
         $('#cpas_status').css('color','green'); 
      }

      
      // alert(password_length);
      
      

    });
   
  });
</script>
</head>
<body>
<header>
<?php
  include("nav.php");
?>
</header>
<h2 style="color: blue;text-align: center;">Student Registration Form</h2>  
<?php echo form_open('main/regaction',array('enctype'=>'multipart/form-data')); ?>
    <center>
<table>
<tr>
<td><lable>UserName:</lable></td>
 <td>
      <input type="text" name="user_name" id="UserName" required pattern="^[a-z A-Z]{5,10}$" title="user name must me alphabet and the length must be 5-10">
 <span id="name_status"></span></td>
 </tr>
 <tr>
 <td><lable>Email:</lable></td>
 <td><!-- <input type="text" name="user_email" id="UserEmail" required onkeyup="checkemail();"> -->
  <input type="email" name="user_email" id="UserEmail" required>
 <span id="email_status"></span></td>
 </tr>
 <tr>
 <td><lable>password:</lable></td>
 <td><input type="password" name="userpass" id="UserPassword" required ><span id="pas_status"></span></td>
 </tr>
<tr>
<td><lable>confirm password</lable></td>
<td><input type="password" name="cpwd" required id="cpassword"><span id="cpas_status"></td>
</tr>
<tr>
    <td><lable>Address:</label></td>
    <td><textarea  rows="4" cols="40" name="address" required></textarea></td>
</tr>
<tr>
    <td><lable>Gender:</lable></td>
    <td><input type="radio" value="male" name="gender" required>Male 
    <input type="radio" name="gender" value="female">Female</td>

</tr>
            <tr>
                <td>
                    <lable>Your Location:</lable>
                </td>
                <td>
                    <select class="state" name="state">
                        <option value="">State</option>
                        <option value="andhra" >andhra</option>
                        <option value="telangana">telangana</option>
                        <option value="assam">assam</option>
                    </select>
          <select id="response" name="city"><option value="">City</option></select>
                </td>
            </tr>
        <tr>
    <td><lable>Upload image:</lable></td>
    <td><input type="file" name="tuch"  id="demo" class="imageUpload" required>
    <span class="imageOutput" ></span>
    

   
</tr>

 <script>
   
      $images = $('.imageOutput');

        $(".imageUpload").change(function(){
            readURL(this);
        });
    

        function readURL(input) {

            if (input.files && input.files[0]) {

                $.each(input.files, function() {
                    var reader = new FileReader();
                    reader.onload = function (e) {           
                        $images.append('<img src="'+ e.target.result+'" />')
                    }
                    reader.readAsDataURL(this);
                });

            }
        }
    </script> 
 <tr>
 <td colspan="4" align="center">
 <input type="submit" id="sub" name="submit_form" value="Submit" onclick="return myFunction()">
 <input type="reset" >
</td>
</tr>
</table>
</form>
<span>
</span>
<span style="color: green">
    <?php echo $this->session->flashdata('success');  ?>
</span>
<span style="color: green">
  <?php echo $this->session->flashdata('failed  ');  ?>
</span>
<script>
  function myFunction(){  
     var namehtml=document.getElementById("name_status").innerHTML;
     var emailhtml=document.getElementById("email_status").innerHTML;  
    var password = document.getElementById("UserPassword").value;
    var password1 = document.getElementById("cpassword").value;
    var name = document.getElementById("UserName").value;
    // alert(name);
    if(name==""){
      alert("Enter your namehtml");
      return false;
    }
     else if(namehtml != "ok")
     {
      
     document.getElementById('name_status').style.color='red' ;  
     
      return false;
     }
     else if(emailhtml != "ok"){
      document.getElementById('email_status').style.color='red' ;
            return false;
     }
  else if(password != password1){
      alert("pasword must match");
      return false;
    }


  }

  

 
</script>
</center>
</body>
</html>