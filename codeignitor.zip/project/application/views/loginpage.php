<!DOCTYPE html>
<html>
<head>
	<title>Login users</title>
</head>
<body>
	<?php include('nav.php'); ?>	
	<?php echo form_open('main/logaction'); ?>
		<label>Email</label>
		<input type="email" name="username"><br/>
		<label>Password</label>
		<input type="password" name="pass"><br/>
		<input type="submit" name="sub" value="Login">

	<?php echo form_close(); ?>
	<span style="color: red">
		<?php 
			echo $this->session->flashdata('login');
			echo $this->session->flashdata('logi');
			
			echo $this->session->flashdata('logerror');
			echo $this->session->flashdata('sess');
			
			// echo $this->session->tempdata('logerror'); 
		?>
	</span>

</body>
</html>