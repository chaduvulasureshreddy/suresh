<?php
$fg = $this->session->userdata('suresh');
$tim = $this->session->userdata('reddy');

$tr =  $tim['time'];
// echo now()."<br/>";
$dis = now()-$tr;
if($dis>3600){
	$this->session->unset_userdata('suresh');
	$this->session->unset_userdata('reddy');
        	$this->session->sess_destroy();
        	$this->session->set_flashdata('sess','session expired');
	redirect('main/userlogin');
}
else{


 



if($fg)
{
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>Messages</title>
	<style type="text/css">
	.a{
		padding:25px;
	}
	</style>
	<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.13/css/jquery.dataTables.min.css">
	<script   src="https://code.jquery.com/jquery-3.1.1.slim.min.js"></script>
	<script src="https://cdn.datatables.net/1.10.13/js/jquery.dataTables.min.js"></script>
	<script>
	$(document).ready(function(){
    $('#myTable').DataTable();	
	});
	</script>

</head>

<body>
<header>
	<nav style="background-color:lightblue;height:50px;">
		<?php echo anchor('message','Dashboard',array('class'=>'a')); ?>
			<?php echo anchor('logout','Logout',array('class'=>'a')); ?>
	</nav>
</header>

	<table border="1" width="100%" id="myTable" style="border-collapse: collapse;">
	<thead>
		<tr>
			<th>From</th>
			<th>Subject</th>
			<th>Body</th>
			<th>Comment</th>
			<th>Time</th>
		</tr>
	</thead>
	<tbody>
		<?php
			foreach($data as $fe):
		?>
		<tr style="min-height: 55px;">
			
				<td><?php echo $fe['sender']; ?></td>
				<td><?php echo $fe['subject']; ?></td>
				<td><?php echo $fe['body']; ?></td>
				<td><?php echo $fe['commant']; ?></td>
				<td><?php echo $fe['timee']; ?></td>
		</tr>
		<?php
				endforeach;
			?>
	</tbody>
	</table>
</body>
</html>
<?php
}
else{
	$this->session->set_flashdata('login','if you want to see your messages please login with your username and password');
	redirect('main/userlogin');	
}
}
?>