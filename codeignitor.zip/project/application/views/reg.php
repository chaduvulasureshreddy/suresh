<!DOCTYPE html>
<html>
<head>
	<title>Form</title>
</head>
<body>

<?php// echo validation_errors(); ?>
<?php echo form_open('Regi/index'); ?>
	<label>User name</label>:<input type="name" id="un" name="uname">
	<span style="color:red;"><?php echo form_error('uname'); ?></span><br/>
	<label>Mail</label>:<input type="email" id="um" name="umail"><span style="color:red;"><?php echo form_error('uname'); ?></span><br/>
	<label>password</label>:<input type="password" id="pwd" name="pwd"><span style="color:red;"><?php echo form_error('uname'); ?></span><br/>
	<input type="submit" value="submit" name="sub">

<?php echo form_close(); ?>

</body>
</html>