-- phpMyAdmin SQL Dump
-- version 4.0.10deb1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jul 15, 2017 at 01:11 PM
-- Server version: 5.5.55-0ubuntu0.14.04.1
-- PHP Version: 5.5.9-1ubuntu4.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `suresh`
--

-- --------------------------------------------------------

--
-- Table structure for table `fgrdgfdg`
--

CREATE TABLE IF NOT EXISTS `fgrdgfdg` (
  `s_no` int(11) NOT NULL AUTO_INCREMENT,
  `date` varchar(10) NOT NULL,
  PRIMARY KEY (`s_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `fgrdgfdg`
--

INSERT INTO `fgrdgfdg` (`s_no`, `date`) VALUES
(14, '0.00100250'),
(15, '0000-00-00'),
(16, '0000-00-00');

-- --------------------------------------------------------

--
-- Table structure for table `image`
--

CREATE TABLE IF NOT EXISTS `image` (
  `img_no` int(11) NOT NULL AUTO_INCREMENT,
  `small_img` text NOT NULL,
  `main_img` text NOT NULL,
  PRIMARY KEY (`img_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=135 ;

--
-- Dumping data for table `image`
--

INSERT INTO `image` (`img_no`, `small_img`, `main_img`) VALUES
(121, 'upload/small/wedding_PNG19532.png', 'upload/wedding_PNG19532.png'),
(122, 'upload/small/best-download-gif-325.gif', 'upload/best-download-gif-325.gif'),
(123, 'upload/small/download.jpg', 'upload/download.jpg'),
(124, 'upload/small/images (6).jpg', 'upload/images (6).jpg'),
(125, 'upload/small/Screenshot from 2017-01-20 17:14:38.png', 'upload/Screenshot from 2017-01-20 17:14:38.png'),
(126, 'upload/small/Screenshot from 2017-01-26 14:20:06.png', 'upload/Screenshot from 2017-01-26 14:20:06.png'),
(127, 'upload/small/images (7).jpg', 'upload/images (7).jpg'),
(128, 'upload/small/some.gif', 'upload/some.gif'),
(129, 'upload/small/practices webs', 'upload/practices webs'),
(130, 'upload/small/practices webs', 'upload/practices webs'),
(131, 'upload/small/some.gif', 'upload/some.gif'),
(132, 'upload/small/download.jpg', 'upload/download.jpg'),
(133, 'upload/small/some.gif', 'upload/some.gif'),
(134, 'upload/small/practices webs', 'upload/practices webs');

-- --------------------------------------------------------

--
-- Table structure for table `message`
--

CREATE TABLE IF NOT EXISTS `message` (
  `meg_no` int(150) NOT NULL AUTO_INCREMENT,
  `sender` varchar(50) NOT NULL,
  `reciver` varchar(50) NOT NULL,
  `subject` text NOT NULL,
  `body` text NOT NULL,
  `commant` text NOT NULL,
  `timee` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`meg_no`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=59 ;

--
-- Dumping data for table `message`
--

INSERT INTO `message` (`meg_no`, `sender`, `reciver`, `subject`, `body`, `commant`, `timee`) VALUES
(1, 'suresh', 'reddy', 'djfgjhdgjk', 'ghkhkjh', 'jhgjhd', '0000-00-00 00:00:00'),
(2, 'suresh', 'dyfy ', 'dhgjhgjhjhjh', 'wyeyujs', 'hjfgjsg', '2017-01-31 05:53:39'),
(3, 'suresh', 'ranjith', 'this is suresh', 'jhgfjhgdhfgsjfsghhs\r\nfsfgsujygfvjk\r\nsgvusgv\r\nvdkugv', 'nice to chat with u', '2017-01-31 06:01:25'),
(4, 'suresh', 'ranjith', 'hhgfjdgfhgfhjg', 'fjsgfjhsfjsf  hghfghf g bxdkjgkj', 'jhgjfjkjh iukj', '2017-01-31 06:16:27'),
(5, 'venkat', 'suresh', 'gdjgaajhggxfbjhgjh', 'gfhjgfdg dgyshvj', 'dgf gdhf sdfhsg fsh', '2017-01-31 06:32:17'),
(6, 'ranjit', 'suresh', 'this is ranjit welcome to rize software solutions', 'rize software solutions is a one of the the leading company in the software field', 'join with us', '2017-01-31 06:57:05'),
(7, 'suresh', 'venkat', 'hi', 'this is suresh', 'jjghhgv g c gbccbcb', '2017-01-31 07:18:22'),
(8, 'suresh', 'venkat', 'jhzdgjghjg', 'bjjhgsj dghj  dghj', 'ghhgv hg jv', '2017-01-31 07:22:48'),
(9, 'venkat', 'jh sgfus', 'hi', 'i am cool', 'i am too', '2017-01-31 07:24:47'),
(10, 'venkat', 'suresh', 'hi suresh', 'hi suresh', 'nice suresh', '2017-01-31 08:39:37'),
(11, 'venkat', 'suresh', 'how r u', 'how r u', 'how r u', '2017-01-31 08:40:08'),
(12, 'venkat', 'suresh', 'who r u', 'who r u', 'who r u\r\n', '2017-01-31 08:40:37'),
(13, 'venkat', 'suresh', 'what about u', 'what about u', 'what about u', '2017-01-31 08:40:55'),
(14, 'venkat', 'suresh', 'hgghg hsdghghsd', 'rthf hsggj  suresh siresgfg f ghgfhf', 'gf yudygug gjhg  jgjdj jvhjd vdj', '2017-01-31 08:41:17'),
(15, 'venkat', 'suresh', 'cnbmnvb ', 'dhgggjgj ', 'hdfghdhf', '2017-01-31 08:41:30'),
(16, 'venkat', 'suresh', 'hvdggh', 'fbfdbf rgddf rdd rd ', 'dddf fg dsf sfn', '2017-01-31 08:41:46'),
(17, 'venkat', 'suresh', 'ffgg fhasz sdffs fnn', 'fffgffg dfdgdg dcbxx dsfhsdg sdgsdg  fdsghsfh shag', 'asgasg dgasg dssdhf dgdagh', '2017-01-31 08:42:21'),
(18, 'venkat', 'suresh', 'ddsdsfsssfsf', 'g hgdjgjsjsgjh sgjd ksjgf asg sa gaky a eh', 'apcdefgh ijklmnopq rstuvw xyz', '2017-01-31 08:43:49'),
(19, 'venkat', 'suresh', 'abcDEFG', 'HISJDGHDSGV JEGSJDGJ SJYGV', 'bvcnbz vxcn zbfvcv jsgf vja', '2017-01-31 08:44:19'),
(20, 'suresh', 'linga', 'as dfasd asdfa sdfad', 'asp asc asdasd asdasd chaduvula sureshreddy\r\nsuresh reddy suresh reddy suresh reddy', 'chaduvula suresh reddy', '2017-01-31 09:34:48'),
(24, 'suresh', 'venkat', 'zfhsgfgh', 'bcvbnzv bzvn fv nzbvc nbvc bvcbv zsh', 'surseg', '2017-01-31 09:41:14'),
(25, 'suresh', 'venkat', 'gsgfjg hsgjhsgf jg j jfg', 'hhhgfg ghssg hgsjag hgsjsfb  shjf sgcj', 'hghfgsf', '2017-01-31 09:42:14'),
(26, 'suresh', 'ranjith', 'fshsff', 'vjgjhgfj hdgjgjds gdhsgdyeg xzgfggfz jsfjgsh sjgfjgshf hgfjsfg', 'hdhsg hsdgf jdsjgsh jsgfj', '2017-01-31 09:52:15'),
(27, 'suresh', 'ranjith', 'fshsff', 'vjgjhgfj hdgjgjds gdhsgdyeg xzgfggfz jsfjgsh sjgfjgshf hgfjsfg', 'hdhsg hsdgf jdsjgsh jsgfj', '2017-01-31 09:52:15'),
(28, 'suresh', 'ranjith', 'hdghfhjgf jgjhg  jdgjhsdvb', 'dhjsygafj sjgaiy  sajf jjsfg sjfhjhhsgasf sjgfjfa', 'hjsdgj sfjsgf sjgfsjhf jhfgsjf fdgsjagf sjgfjsg jsfgjs', '2017-01-31 09:53:52'),
(32, 'venkat', 'linga', 'dgffdh vghgjn tfjm ftnjh', 'gjngj fghn fgnhnm gjng fgn', 'nvmbmg ggjgt dj hg jg ', '2017-02-23 06:26:02'),
(33, 'suresh reddy chaduvula', 'linga', 'i am new user', 'these is suresh reddy', 'this is suresh reddy', '2017-02-23 11:56:33'),
(34, 'suresh reddy chaduvula', 'linga', 'i am new user', 'this is suresh reddy', 'this is suresh reddy', '2017-02-23 11:57:15'),
(35, 'suresh', 'linga', 'hello suresh', 'i am also new user', 'sfdsdfsfda', '2017-02-23 11:58:29'),
(36, 'venkat', 'linga', 'hi suresh', 'what else', 'asdgdfsgsdgdfsg dfb r rthb rth trn ', '2017-02-23 12:23:29'),
(37, 'venkat', 'linga', 'xg b rb h fh rhb f rgb ', 'dfgdgjh dghvbjhu  dgvhjkb hvudv  djvhdv gvhv db ', 'jghfdb djhvn dhv dugvsL jhvg ', '2017-02-23 12:24:27'),
(38, 'venkat', 'suresh reddy chaduvula', 'hi suresh ', 'your r a new employee of this company ', 'dr fn th tyj tyj  fgng  vhnh fhbn xfhm drg ern  ftghrn tfn ', '2017-02-23 12:29:37'),
(39, 'suresh', 'suresh reddy chaduvula', 'this is suresh ', 'hi,\r\n   Hi chaduvula suresh reddy ,plese send the details of yours\r\nthanking you,\r\nsuresh reddyt''', 'fstr f gtj ', '2017-02-25 09:48:49'),
(40, 'suresh', 'uday', 'gfdfdfg', 'dgdfgfgs s  t   h b ghfdhdfhdf rhdf', 'sdgsdg et er ry5h ', '2017-02-25 09:50:00'),
(41, 'suresh', 'ranjith', 'fdg  ye5  euy t eytue  ejret ndg  ', 'yridy ti iuyri  kjygitrhtg nike 4h tekn h  rei ', 'ujy tdb suf geufmn   hue4yt g ejt ie teuikjs eg ', '2017-02-25 09:50:32'),
(42, 'suresh', 'c suresh', 'hfhbfsdh', ' h ghfd rt ytrrrru 8rt rtu8 69496 tu', 'ywsj f yr5ym va wet tr sy uk', '2017-02-25 09:51:05'),
(43, 'suresh', '---users---', 'dszgsf', 'ser n htjr ftrt', 'gfj rsthjs', '2017-02-25 09:51:36'),
(52, 'suresh', 'suresh reddy', 'jghik khjkjhmh', 'hkgkj', 'hgkkr k,', '2017-02-25 10:07:52'),
(53, 'suresh', 'sureshd', 'fgfghdf', 'hfdhghf', 'hdfhfh', '2017-02-27 11:52:00'),
(54, 'suresh', 'suresg', 'sdfsdfsfsdgs', 'gsgsdgsgsdsg', 'sgdgsgsgdg gvx dbc fvf dfgb ', '2017-03-01 05:42:10'),
(55, 'suresh', 'suresg', 'this is suresh reddy', 'working in rize software solutions ', ' their are some vacancies in my company if you are interested send your resume to suresh@rize.com ', '2017-03-01 05:53:47'),
(56, 'suresh reddy chaduvula', 'suresh', 'dgfdgfdsfg', 'gsdfgsdfgsgd  hhshfdsdfh fhgdfh', 'fhsdh fhbsfh dghb dgh', '2017-03-01 12:01:52'),
(57, 'suresh', 'suresh reddy chaduvula', 'ufjsdfg', 'gdusy gfsu yfsu dy', 'dyfsuyfgs heeuf', '2017-03-06 04:16:04'),
(58, 'fgdhgf', 'gsfwxwfc', 'fgdfgfd', 'dfgdfg', 'dfgdfg', '2017-05-31 12:49:44');

-- --------------------------------------------------------

--
-- Table structure for table `my_users`
--

CREATE TABLE IF NOT EXISTS `my_users` (
  `S_NO` int(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(35) NOT NULL,
  `loginid` varchar(35) NOT NULL,
  `password` varchar(15) NOT NULL,
  `address` text NOT NULL,
  `gender` varchar(10) NOT NULL,
  `state` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL,
  `image` varchar(50) NOT NULL,
  PRIMARY KEY (`S_NO`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=123 ;

--
-- Dumping data for table `my_users`
--

INSERT INTO `my_users` (`S_NO`, `name`, `loginid`, `password`, `address`, `gender`, `state`, `city`, `image`) VALUES
(79, 'uday', 'uday@gmail.com', '12345', 'hyderabad ameerpet rize software solutions', 'male', 'telangana', 'Warangal', 'images (2).jpg'),
(81, 'suresh reddy', 'sureshreddy@gmail.com', '12345', 'vhs shfdhesv hdfwh wf bwu nb', 'male', 'telangana', 'Secunderab', 'images (4).jpg'),
(82, 'c suresh', 'reddy@gmail.com', '789456', 'kurnool', 'male', 'andhra', 'Kurnool', 'images (7).jpg'),
(83, 'suresh reddy chaduvula', 'chaduvulasureshreddy@gmail.com', 'sureshreddy@96', 'sr nager hyderabad', 'male', 'andhra', 'Kurnool', 'images (3).jpg'),
(85, 'fh hffh', 'bfhbfhfh@hfg .thjfh', '12345', 'dfhfghfdhfhg', 'male', 'andhra', 'Kurnool', 'download.jpg'),
(86, 'fgdyv ghj', 'gyff@hg.k', 'dfg', 'gfhgf ', 'male', 'andhra', 'Chittoor', 'download.jpg'),
(87, 'gsfwxwfc', 'fhf@hhjh', '123', 'kuffty', 'male', 'andhra', 'Kurnool', 'images (4).jpg'),
(88, 'sureshreddy', 'sureshreddy@outlook.com', '12345', 'gjhf jd ghg jg hg jghjrb drghj bg', 'male', 'assam', 'Guwahati', 'images (5).jpg'),
(89, 'ranjit', 'ranjit@gmail.com', '123456', 'kjhhg dhgdjgf dfjgh djgdjgf dfgdhgk hgg hjgf  dsg', 'male', 'telangana', 'Hyderabad', 'wedding_PNG19532.png'),
(90, 'venka', 'venka@gaml.com', '123456', 'dfg d h  hgb th', 'male', 'telangana', 'Hyderabad', 'images (3).jpg'),
(91, 'fhfghfhfhfgh', 'hgf@fds.hj', '123456', 'dgdgfgf', 'male', 'telangana', 'Hyderabad', 'Screenshot from 2017-01-26 14:20:06.png'),
(93, 'suresg', 'suresg@gmail.com', '123456', 'fhfgh ryhtr try ryr yyt r r', 'male', 'andhra', 'Kurnool', 'images (3).jpg'),
(94, 'sureshd', 'suresh@gmail.ccom', '123456', 'fhfghfhg', 'male', 'andhra', 'Kurnool', 'images (8).jpg'),
(95, 'dgdgsdgsdgs', 'gdgs@ch.gjt', 'suresh', 'jgfgjdgh', 'male', 'telangana', 'Hyderabad', 'wedding_PNG19532.png'),
(96, 'fhfhf', 'hfgh@gfgf.gh', 'df', 'ffdgdfg dgdg ', 'male', 'andhra', 'Kurnool', 'images (2).jpg'),
(98, 'reddy', 'reddy@gmail.comd', '123456', 'ghg g g hjhjghjg hhgj ghng gjn rth ', 'male', 'telangana', 'Hyderabad', 'images (8).jpg'),
(99, 'suresgd', 'sdgsh@hg.sdkfg', '123456', 'sfdgdgdfg', 'male', 'andhra', 'Kurnool', 'images (2).jpg'),
(100, 'dfdgdfgf', 'gsdgsdg@dgdv.jffj', 'suresh', 'kghfk fhg jkfhg g uhg', 'male', 'telangana', 'Hyderabad', 'images (1).jpg'),
(101, 'dsffddsff', 'ssdfdsf@rfg.jhd', '123456789', 'fgfhfgh dr h', 'male', 'telangana', 'Hyderabad', 'images (1).jpg'),
(102, 'fhgfhgfhbfh', 'fhgfg@hfsyd.jgfjd', '14789', 'jhg sjhg jhsfgufhjvuywygefjhdv', 'male', 'andhra', 'Kurnool', 'images (3).jpg'),
(104, 'sures', 'sure@gmail.com', '12589', 'ggdgf gfj udgbuyzs ug o udgmdvjrgg ', 'male', 'andhra', 'Kurnool', 'images (3).jpg'),
(105, 'sureshf', 'reddy@gmail.comds', '123654', 'gdfgc gb fgb rdgv  dv ', 'male', 'telangana', 'Hyderabad', 'images (1).jpg'),
(106, 'fsdfsfsfd', 'suresh@gmail.comsf', '123456dfs', 'dsffsf', 'male', 'andhra', 'Kurnool', 'unnamed.jpg'),
(107, 'hsdhfsh', 'gdssg@fg.hsdg', 'sjgdsfg', 'hhgf', 'male', 'telangana', 'Hyderabad', 'images (3).jpg'),
(108, 'fgdgfg', 'fgdfg@dg.fh', '14587', 'fghfhfh', 'male', 'andhra', 'Kurnool', 'images (4).jpg'),
(109, 'ffdgdfg', 'vgfdgfdgd@gfg.gfg', '123456', 'dgdfggdf', 'male', 'andhra', 'Kurnool', 'images (4).jpg'),
(110, 'fdkfjb', 'fkjdkj@djfh.jhfdg', '14569', 'hfug ey iuh veutrjt ge e4  hl uet hrhua b gt', 'male', 'andhra', 'Kurnool', 'download (1).jpg'),
(111, 'dfsdgdv', 'gdg@d.dfg', '14569', 'dgdfg t ', 'male', 'assam', 'Guwahati', 'images (3).jpg'),
(112, 'dgfhdffg', 'fhfdhf@hff.ff', '14569', 'dfgfdh r n h th r', 'male', 'andhra', 'Kurnool', 'images (3).jpg'),
(113, 'fdsfsdfdf', 'dsfs@gfg.hgf', '147852', 'bfh  hdh', 'male', 'andhra', 'Kurnool', 'images (7).jpg'),
(114, 'fdsfsdfdfd', 'dsfsd@gfg.hgf', '14569', 'bfh  hdh', 'male', 'telangana', 'Hyderabad', 'images (1).jpg'),
(115, 'gfjdhfg', 'hgug@kghiru.ju', '1456', 'kifg tiu it iunriu y iet getgu yrjg tj ', 'male', 'andhra', 'Kurnool', 'images (7).jpg'),
(116, 'suresh hf', 'sdghsf@gmal.cifn', 'suresh', 'gsfdshf s fshdfs fs sddsgf  sfsdv  s hf hf dg fscv s dsf skjdf sdb s  hgsdg sd gd fsfgsgflf s fus fsfsfgs fyfsf ', 'male', 'telangana', 'Hyderabad', 'images (8).jpg'),
(117, 'dfdsfsfsd', 'sureshdf@gmail.com', '12345', 'dgfdgsd', 'male', 'andhra', 'Kurnool', 'images (8).jpg'),
(118, 'dfdsfsfsd', 'sureshdf@gmail.com', '12345', 'dgfdgsd', 'male', 'andhra', 'Kurnool', 'images (8).jpg'),
(119, 'fgdgdgf', 'gfgfjg@jf.dgfd', '1456987', 'isudyysu d f sg syufgsbcsyufgsdbsuygf sgdf  ', 'male', 'telangana', 'Hyderabad', 'images (6).jpg'),
(120, 'jdsfghsd', 'sdhgfs@hdgs.fg', '14569', 'fdjjghjf jdgf rfg rjfgr', 'male', 'andhra', 'Kurnool', 'upload/images (8).jpg'),
(121, 'jgghfjg', 'jdg@jfg.h', '1234567', 'jghjd d djfgd gdd gh', 'male', 'andhra', 'Kurnool', 'upload/images (8).jpg'),
(122, 'suresh', 'chaduvulasuresh@gmialcom', '123456', 'dfhs dshfsjdg f', 'male', 'telangana', 'Hyderabad', 'architecture_codeigniter.png');

-- --------------------------------------------------------

--
-- Table structure for table `suresh`
--

CREATE TABLE IF NOT EXISTS `suresh` (
  `id` int(25) NOT NULL AUTO_INCREMENT,
  `name` varchar(55) NOT NULL,
  `mail` varchar(55) NOT NULL,
  `password` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `suresh`
--

INSERT INTO `suresh` (`id`, `name`, `mail`, `password`) VALUES
(1, 'hfgdsjf', 'hfgh@hfgsdf.fkjsdhgf', '$2y$10$xP6qEtcGcc.Xpj0hp2'),
(2, 'suresh', 'suresh@gmail.com', '$2y$10$.0L5iXCEZYn2u4HGP1'),
(3, 'reddy', 'reddy@gmail.com', '$2y$10$CBzLM1Q8nGoqcKZcBP'),
(4, 'sureshreddy', 'fsfd@jfg.kj', '$2y$10$pCHM.6j9vHe/jIH.cq'),
(5, 'ranji', 'hgfds@sfg.jhgf', '$2y$10$Cm5NZBKukYvug7mfTv'),
(6, 'csr', 'csr@gmail.com', '$2y$10$xXoxjnpD0tKKC.P/uW'),
(7, 'cvsr', 'suresjhg@dg.kfj', '$2y$10$dhloJLoXhEMfqQSdq66cuexnGfpBdqtGnJIaTurcqrA55Cbp2Q9oi'),
(8, 'hhfhfghfg', 'hfghfhg@g.ft', '$2y$10$LE43KuiqCroSE3svChwmZejR88TyCfy5FVTA9zyPXzbQbu6v6ewpm'),
(9, 'hgfhf', 'fghfgh@dhf.gfh', 'vfdfd'),
(10, 'hgfhfdsfssf', 'fghfgh@dhf.gfhsdfs', 'fsfsfsdf'),
(11, 'fdsfdsfs', 'fsfsfds@gdfg.gjgh', 'sfsdfsdfs'),
(12, 'fdsfdsfs', 'fsfsfds@gdfg.gjgh', 'sfsdfsdfs'),
(13, 'fdsfdsfstfhgf', 'fsfsffhfgds@gdfg.gjgh', 'fhggfhfhfdhg'),
(14, 'suresh', 'reddy@gmail.com', '12345');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
