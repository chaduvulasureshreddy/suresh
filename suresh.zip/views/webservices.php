<html>
    <head>
        <title>Webservice Test</title>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
        <script type="text/javascript">
            function sendRequest() {

                var siteurl = jQuery("#siteurl").val();
                var json_request = jQuery.trim(jQuery('#json_request').val());
                var method = jQuery.trim(jQuery('#json_method').val());
                if (method === '' || json_request === '') {
                    jQuery('#errormsg').html("please enter all required data..!");
                    return;
                } else {
                    jQuery('#errormsg').html("");
                }
                jQuery.ajax({
                    dataType: 'json',
                    type: "POST",
                    url: siteurl + 'data/' + method,
                    data: json_request,
                    success: function(response) {
                        console.log('ff');
                        jQuery('#jsonResponse').val(JSON.stringify(response));
                    }
                });
            }
        </script>
    </head>
    <body>
        <h3>Webservice Test</h3>
        <div>
            <form action="post" name="webservices" id="webservices">
                <input type="hidden" name="siteurl" id="siteurl" class="service_call" value="<?php echo base_url(); ?>" />
                <label>Method Call: </label>
                <input type="text" name="method" id="json_method" class="service_call" size="130" /><br/>
                <label>Parameters: </label>
                <input type="text" name="request" id="json_request" class="service_call" size="130" /><br/>
                <div id="errormsg" style="color: #ff0000;">&nbsp;</div>
                <input type="button" name="submit" value="submit" onClick="sendRequest()" />
            </form>
        </div>
        <div>
            <h3>Response: </h3>
            <textarea id="jsonResponse" cols="100" rows="8"></textarea>
        </div>
        <table>
            <tr><td colspan="2">&nbsp;</td></tr>
            <tr>
                <td></td>
                <td>Following are the Web Service URL's:</td>
            </tr>
            <tr><td colspan="2">&nbsp;</td></tr>

            <!-- User Registrations -->
            <?php $i = 1; ?>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For Registration</td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">userRegistration</span></td></tr>
            <tr>
                <td></td>
                <td>{"username":"chaitanya","password":"123456","email":"chaitu.kuru@gmail.com","shopname":"appsols","type":"S","mobile":"9652298217","dob":"1988-12-24","address":"Hyderabad","city":"Hyd","landmark":"Banjarahills"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    username    : name of user<br/>
                    password    : password of user<br/>
                    email       : email of user<br/>
                    shopname    : shop name of user<br/>
                    type        : Business Type(S - Shopping, B- Beauty Parlaour, H- Hospitals, R - Restarnts)<br/>
                    mobile      : mobile no. of user<br/>
                    dob         : dob of user<br/>
                    address     : address of user<br/>
                    city        : city of user<br/>
                    landmark    : landmark for address<br/>

                </td>
            </tr>
            <tr><td colspan="2">&nbsp;</td></tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For Login</td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">login</span></td></tr>
            <tr>
                <td></td>
                <td>{"email":"chaitu.kuru@gmail.com","password":"123456"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    username    : user name of user<br/>
                    email       : email of user<br/>
                    password    : password of user<br/>
                </td>
            </tr>
            <tr><td colspan="2">&nbsp;</td></tr>

            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For Update Profile</td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">editProfile</span></td></tr>
            <tr>
                <td></td>
                <td>{"user_id":"1","shopname":"appsols","mobile":"9652298217","dob":"1988-12-24","address":"Hyderabad","city":"hyd","landmark":"Banjarahills"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    user_id     : id of user <br/>
                    shopname    : shop name of user<br/>
                    mobile      : mobile no. of user<br/>
                    dob         : dob of user<br/>
                    address     : address of user<br/>
                    city        : city of user<br/>
                    landmark    : landmark for address<br/>
                </td>
            </tr>
            <tr><td colspan="2">&nbsp;</td></tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For Brands Insertion</td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">brandsInsertion</span></td></tr>
            <tr>
                <td></td>
                <td>{"userid":"1","category":"dresses","brandname":"chudidar","price":"100","discount":"10","final_price":"90","offer":"n/a"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    userid      :   id of user<br/>
                    category    :   category of product<br/>
                    brandname   :   name of brand<br/>
                    price       :   price of brand<br/>
                    discount    :   discount of brand<br/>
                    final_price :   final_price of brand<br/>
                    offer       :   offers if any
                </td>
            </tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For Brands Updation</td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">brandsEdit</span></td></tr>
            <tr>
                <td></td>
                <td>{"id":"1","userid":"1","category":"dresses","brandname":"chudidar","price":"100","discount":"10","final_price":"90","offer":"n/a"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    id          :   id of brand <br/>
                    userid      :   id of user<br/>
                    category    :   category of product<br/>
                    brandname   :   name of brand<br/>
                    price       :   price of brand<br/>
                    discount    :   discount of brand<br/>
                    final_price :   final_price of brand<br/>
                    offer       :   offers if any
                </td>
            </tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For All Brands </td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">getAllBrandsofUser</span></td></tr>
            <tr>
                <td></td>
                <td>{"userid":"1"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    userid : id of user
                </td>
            </tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>For Brands Updation</td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">brandsEdit</span></td></tr>
            <tr>
                <td></td>
                <td>{"id":"1","userid":"1","category":"dresses","brandname":"chudidar","price":"100","discount":"10","final_price":"90","offer":"n/a"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    id          :   id of brand <br/>
                    userid      :   id of user<br/>
                    category    :   category of product<br/>
                    brandname   :   name of brand<br/>
                    price       :   price of brand<br/>
                    discount    :   discount of brand<br/>
                    final_price :   final_price of brand<br/>
                    offer       :   offers if any
                </td>
            </tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>To Get User Info </td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">getUserData</span></td></tr>
            <tr>
                <td></td>
                <td>{"userid":"1"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    userId : id of user
                </td>
            </tr>
            <tr>
                <td><?php
                    echo $i;
                    $i++;
                    ?>.</td>
                <td>To Get Brand Info </td>
            </tr>
            <tr><td></td><td>Method: <span style="font-size:13px;color:#333">getBrandData</span></td></tr>
            <tr>
                <td></td>
                <td>{"id":"1"}</td>
            </tr>
            <tr><td></td><td colspan="2">Parameters to be passed: </td></tr>
            <tr>
                <td></td>
                <td style="font-size:13px;color:#333">
                    userId : id of user
                </td>
            </tr>
        </table>
    </body>
</html>