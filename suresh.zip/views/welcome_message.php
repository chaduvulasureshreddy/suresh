<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Welcome to CodeIgniter</title>

        <style type="text/css">

            ::selection { background-color: #E13300; color: white; }
            ::-moz-selection { background-color: #E13300; color: white; }

            body {
                background-color: #fff;
                margin: 40px;
                font: 13px/20px normal Helvetica, Arial, sans-serif;
                color: #4F5155;
            }

            a {
                color: #003399;
                background-color: transparent;
                font-weight: normal;
            }

            h1 {
                color: #444;
                background-color: transparent;
                border-bottom: 1px solid #D0D0D0;
                font-size: 19px;
                font-weight: normal;
                margin: 0 0 14px 0;
                padding: 14px 15px 10px 15px;
            }

            code {
                font-family: Consolas, Monaco, Courier New, Courier, monospace;
                font-size: 12px;
                background-color: #f9f9f9;
                border: 1px solid #D0D0D0;
                color: #002166;
                display: block;
                margin: 14px 0 14px 0;
                padding: 12px 10px 12px 10px;
            }

            #body {
                margin: 0 15px 0 15px;
            }

            p.footer {
                text-align: right;
                font-size: 11px;
                border-top: 1px solid #D0D0D0;
                line-height: 32px;
                padding: 0 10px 0 10px;
                margin: 20px 0 0 0;
            }

            #container {
                margin: 10px;
                border: 1px solid #D0D0D0;
                box-shadow: 0 0 8px #D0D0D0;
            }
        </style>
    </head>
    <body>

        <div class="content-wrapper">
            <?php // echo '<pre>';print_r($studentInfo);?>
            <!-- Main content -->
            <section class="content">
                <div class="row">
                    <div class="col-md-11">

                    </div>
                    <div>
                        <div class="col-md-8 col-xs-offset-2">
                            <!-- general form elements -->
                            <div class="box box-primary">
                                <!-- /.box-header -->
                                <div class="panel-body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <h4><b>Student Profile Information:</b></h4>
                                        </div>
                                        <div class="col-sm-3">
                                            <div id="old_img">
                                                <div class="form-group">
                                                    <?php if (!empty($studentInfo['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $studentInfo['student_image'])) { ?>
                                                        <img src="<?php echo base_url() . 'uploads/profile_pics/' . $studentInfo['student_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                                                    <?php } else { ?>
                                                        <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                                                    <?php } ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="student_admission_id">Admission Number:</label>
                                                <?php echo ucfirst($studentInfo['sch_admission_id']); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="student_name">Student Name:</label>
                                                <?php echo ucfirst($studentInfo['student_name']); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="class_name">Father Name:</label>
                                                <?php echo ucfirst($studentInfo['student_father_name']); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="section_name">Mother Name:</label>
                                                <?php echo ucfirst($studentInfo['student_mother_name']); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="class_name">Gender:</label>
                                                <?php
                                                if ($studentInfo['student_gender'] == 'M')
                                                    echo ucfirst('boy');
                                                else
                                                    echo ucfirst('girl');
                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="section_name">Date of Birth:</label>
                                                <?php echo date('dS-F-Y', strtotime($studentInfo['student_dob'])); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="class_name">Class Name:</label>
                                                <?php echo ucfirst($studentInfo['class_name']); ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="section_name">Section Name:</label>
                                                <?php echo ucfirst($studentInfo['section_name']); ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="class_name">Contact Number:</label>
                                                <?php echo $studentInfo['student_mobile']; ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="section_name">Blood Group:</label>
                                                <?php
                                                if ($studentInfo['student_blood_group']) {
                                                    echo ucfirst($studentInfo['student_blood_group']);
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="student_caste">Caste:</label>
                                                <?php
                                                if ($studentInfo['student_caste']) {
                                                    echo ucfirst($studentInfo['student_caste']);
                                                } else {
                                                    echo 'N/A';
                                                }
                                                ?>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label for="student_fee_amount">Fee Amount:</label>
                                                <?php echo 'Rs: ' . $studentInfo['student_fee'] . '/-'; ?>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label for="student_address">Address:</label>
                                                <?php echo ucfirst($studentInfo['student_address']); ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!--</div>-->
                                <!--</div>-->
                            </div>
                            <!--/.col (left) -->
                        </div>
                    </div>
                </div>
            </section>
            <!-- /.content -->
        </div>

    </body>
</html>