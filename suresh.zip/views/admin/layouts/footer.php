<!-- /.content-wrapper -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <!--<b>Version</b> 2.3.7-->
    </div>
    <strong>Copyright &copy; 2016 <a href="<?php echo base_url(); ?>">Amel IT | School Dashboard</a>.</strong> All rights reserved.
</footer>
<!-- Add the sidebar's background. This div must be placed
     immediately after the control sidebar -->
<div class="control-sidebar-bg"></div>
</div>
<!-- ./wrapper -->
<!-- jQuery 2.2.3 -->
<!--<script src="<?php echo base_url(); ?>assets/admin/js/jquery-2.2.3.min.js"></script>-->
<!-- Bootstrap 3.3.6 -->
<script src="<?php echo base_url(); ?>assets/admin/js/bootstrap.min.js"></script>
<!-- DataTables -->
<script src="<?php echo base_url(); ?>assets/admin/js/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>assets/admin/js/dataTables.bootstrap.min.js"></script>
<!-- date-range-picker -->
<!--<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.11.2/moment.min.js"></script>-->
<!--<script src="<?php // echo base_url(); ?>assets/admin/js/timepicker.js"></script>-->
<!-- SlimScroll -->
<!--<script src="<?php // echo base_url(); ?>assets/admin/js/jquery.slimscroll.min.js"></script>-->
<!-- FastClick -->
<!--<script src="<?php // echo base_url(); ?>assets/admin/js/fastclick.js"></script>-->
<!-- AdminLTE App -->
<script src="<?php echo base_url(); ?>assets/admin/js/app.min.js"></script>
<!-- AdminLTE for demo purposes -->
<!--<script src="<?php // echo base_url(); ?>assets/admin/js/demo.js"></script>-->
<!-- page script -->
<!-- CK Editor -->
<!--<script src="https://cdn.ckeditor.com/4.5.7/full/ckeditor.js"></script>-->
<script>
    $(function () {
        $("#example1").DataTable();
        $('#example2').DataTable({
            "paging": true,
            "lengthChange": false,
            "searching": false,
            "ordering": true,
            "info": true,
            "autoWidth": false
        });

    });
</script>
</body>
</html>