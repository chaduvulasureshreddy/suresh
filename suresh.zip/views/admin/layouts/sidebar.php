<?php
if ($this->router->fetch_method() == 'index') {
    $menu_item = "home";
}

if ($this->router->fetch_method() == 'students' || $this->router->fetch_method() == 'view_student_info') {
    $menu_item = "allinfo";
}

if ($this->router->fetch_method() == 'manage_students' || $this->router->fetch_method() == 'add_student' || $this->router->fetch_method() == 'edit_student' || $this->router->fetch_method() == 'view_student' || $this->router->fetch_method() == 'uploadstudentImages') {
    $menu_item = "students";
}

if ($this->router->fetch_method() == 'manage_drivers' || $this->router->fetch_method() == 'add_driver' || $this->router->fetch_method() == 'edit_driver' || $this->router->fetch_method() == 'view_driver') {
    $menu_item = "drivers";
}

if ($this->router->fetch_method() == 'manage_busroutes' || $this->router->fetch_method() == 'add_busroute' || $this->router->fetch_method() == 'edit_busroute' || $this->router->fetch_method() == 'view_busroute') {
    $menu_item = "busroutes";
}

if ($this->router->fetch_method() == 'manage_home_works' || $this->router->fetch_method() == 'add_home_work' || $this->router->fetch_method() == 'edit_home_work') {
    $menu_item = "homeworks";
}
if ($this->router->fetch_method() == 'manage_results' || $this->router->fetch_method() == 'add_result' || $this->router->fetch_method() == 'edit_result') {
    $menu_item = "results";
}
if ($this->router->fetch_method() == 'manage_halltickets' || $this->router->fetch_method() == 'add_hallticket' || $this->router->fetch_method() == 'edit_result') {
    $menu_item = "results";
}
if ($this->router->fetch_method() == 'edit_profile' || $this->router->fetch_method() == 'change_password' || $this->router->fetch_method() == 'settings' || $this->router->fetch_method() == 'logout') {
    $menu_item = "settings";
}

if ($this->router->fetch_method() == 'manage_classes' || $this->router->fetch_method() == 'add_class' || $this->router->fetch_method() == 'edit_class') {
    $menu_item = "classes";
}
if ($this->router->fetch_method() == 'manage_sections' || $this->router->fetch_method() == 'add_section' || $this->router->fetch_method() == 'edit_section') {
    $menu_item = "sections";
}
if ($this->router->fetch_method() == 'manage_remarks' || $this->router->fetch_method() == 'add_remark' || $this->router->fetch_method() == 'edit_remark') {
    $menu_item = "remarks";
}
if ($this->router->fetch_method() == 'manage_attendance' || $this->router->fetch_method() == 'add_attendance' || $this->router->fetch_method() == 'edit_attendance' || $this->router->fetch_method() == 'getStudentsAttendanceData') {
    $menu_item = "attendance";
}
if ($this->router->fetch_method() == 'manage_fees' || $this->router->fetch_method() == 'add_fee' || $this->router->fetch_method() == 'getStudentFeeInfo' || $this->router->fetch_method() == 'viewStudentFeeInfo' || $this->router->fetch_method() == 'search_student' || $this->router->fetch_method() == 'pending_fee' || $this->router->fetch_method() == 'getStudentsPendingData' || $this->router->fetch_method() == 'getStudentsData' || $this->router->fetch_method() == 'pending_fee_amount' || $this->router->fetch_method() == 'getStudentFeesData' || $this->router->fetch_method() == 'paid_fee_amount') {
    $menu_item = "fees";
}
if ($this->router->fetch_method() == 'add_bus_fee' || $this->router->fetch_method() == 'viewStudentBusFeeInfo' || $this->router->fetch_method() == 'pending_busfee_amount' || $this->router->fetch_method() == 'paid_busfee_amount' || $this->router->fetch_method() == 'getStudentBusFeeInfo' || $this->router->fetch_method() == 'getStudentbussFeeInfo' || $this->router->fetch_method() == 'getStudentsBusFeePendingData' || $this->router->fetch_method() == 'pending_busfee') {
    $menu_item = "busfees";
}
if ($this->router->fetch_method() == 'add_books_fee' || $this->router->fetch_method() == 'viewStudentBooksFeeInfo' || $this->router->fetch_method() == 'pending_booksfee_amount' || $this->router->fetch_method() == 'paid_booksfee_amount' || $this->router->fetch_method() == 'getStudentBooksFeeInfo' || $this->router->fetch_method() == 'getStudentbookFeeInfo' || $this->router->fetch_method() == 'getStudentsBooksFeePendingData' || $this->router->fetch_method() == 'pending_booksfee') {
    $menu_item = "booksfees";
}
if ($this->router->fetch_method() == 'manage_messages' || $this->router->fetch_method() == 'send_message') {
    $menu_item = "messages";
}
if ($this->router->fetch_method() == 'manage_examtypes' || $this->router->fetch_method() == 'add_examtype' || $this->router->fetch_method() == 'edit_examtype') {
    $menu_item = "examtypes";
}
if ($this->router->fetch_method() == 'manage_subjects' || $this->router->fetch_method() == 'add_subject' || $this->router->fetch_method() == 'edit_subject') {
    $menu_item = "subjects";
}
?>
<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left">
                <a href="<?php echo base_url() . 'dashboard' ?>">
                    <img src="<?php echo $user_data['profile_pic']; ?>" height="50" width="50" class="img-circle" alt="">
                </a>
            </div>
            <div class="pull-left info">
                <p><?php echo ucfirst($user_data['institutename']); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu">
            <li class="header">MAIN NAVIGATION</li>
            <li class="<?php
            if ($menu_item == 'home') {
                echo 'active';
            }
            ?>">
                <a href="<?php echo base_url(); ?>dashboard">
                    <i class="fa fa-dashboard"></i> <span>Dashboard</span>
                </a>
            </li>
            <li class="<?php
            if ($menu_item == 'allinfo') {
                echo 'active';
            }
            ?>">
                <a href="<?php echo base_url(); ?>allinfo/students?class_id=&section_id=">
                    <i class="fa fa-globe"></i> <span>Student Records</span>
                </a>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'classes') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-cloud"></i> <span>Classes</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_classes') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>classdata/manage_classes"><i class="fa fa-circle-o"></i> Manage Classes</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_class') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>classdata/add_class"><i class="fa fa-circle-o"></i> Add Class</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'sections') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-sellsy"></i> <span>Sections</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_sections') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>section/manage_sections"><i class="fa fa-circle-o"></i> Manage Sections</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_section || getStudentsData') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>section/add_section"><i class="fa fa-circle-o"></i> Add Section</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'subjects') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-subway"></i> <span>Subjects</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_subjects') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>subject/manage_subjects"><i class="fa fa-circle-o"></i> Manage Subjects</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_subject') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>subject/add_subject"><i class="fa fa-circle-o"></i> Add Subject</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'students') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-users"></i> <span>Students</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_students') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>admin/manage_students?class_id=&section_id="><i class="fa fa-circle-o"></i> Manage Students</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_student') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>admin/add_student"><i class="fa fa-circle-o"></i> Add Student</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'homeworks') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-wordpress"></i> <span>Homeworks</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_home_works') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>homework/manage_home_works?date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Manage Home Works</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_home_work') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>homework/add_home_work"><i class="fa fa-circle-o"></i> Add Home Work</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'results') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-registered"></i> <span>Results</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_results') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>results/manage_results?exam_date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Manage Results</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_result') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>results/add_result"><i class="fa fa-circle-o"></i> Add Result</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'remarks') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-warning"></i> <span>STUDENT PERFORMANCE</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_remarks') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>remark/manage_remarks?date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Manage Student Performances</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_remark') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>remark/add_remark"><i class="fa fa-circle-o"></i> Add Student Performance</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'attendance') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-adjust"></i> <span>Attendance</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_attendance') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>attendance/manage_attendance?date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Manage Attendance</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_attendance') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>attendance/add_attendance"><i class="fa fa-circle-o"></i> Mark Attendance</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'fees') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-money"></i> <span>Tuition Fee</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'search_student') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>fees/search_student"><i class="fa fa-circle-o"></i> Search By Student</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_fee') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>fees/add_fee?class_id=&section_id="><i class="fa fa-circle-o"></i> Search By Class</a></li>
                    <li <?php if ($this->router->fetch_method() == 'pending_fee') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>fees/pending_fee?class_id=&section_id="><i class="fa fa-circle-o"></i> Search Pending Fees By Class</a></li>
                    <li <?php if ($this->router->fetch_method() == 'paid_fee_amount') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>fees/paid_fee_amount?start_date=&end_date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Paid Fees Amounts</a></li>
                    <li <?php if ($this->router->fetch_method() == 'pending_fee_amount') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>fees/pending_fee_amount"><i class="fa fa-circle-o"></i> Pending Fees Amounts</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'booksfees') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-book"></i> 
                    <span>Books Fee</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'add_books_fee') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>booksfees/add_books_fee?class_id=&section_id="><i class="fa fa-circle-o"></i> Search By Class</a></li>
                    <li <?php if ($this->router->fetch_method() == 'pending_booksfee') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>booksfees/pending_booksfee?class_id=&section_id="><i class="fa fa-circle-o"></i>Pending Booksfees By Class</a></li>
                    <li <?php if ($this->router->fetch_method() == 'paid_booksfee_amount') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>booksfees/paid_booksfee_amount?start_date=&end_date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Paid Booksfees Amount</a></li>
                    <li <?php if ($this->router->fetch_method() == 'pending_booksfee_amount') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>booksfees/pending_booksfee_amount"><i class="fa fa-circle-o"></i> Pending Booksfees Amounts</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'busfees') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-money"></i> <span>Bus Fee</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'add_bus_fee') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>busfees/add_bus_fee?class_id=&section_id="><i class="fa fa-circle-o"></i> Search By Class</a></li>
                    <li <?php if ($this->router->fetch_method() == 'pending_busfee') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>busfees/pending_busfee?class_id=&section_id="><i class="fa fa-circle-o"></i>Pending Busfees By Class</a></li>
                    <li <?php if ($this->router->fetch_method() == 'paid_busfee_amount') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>busfees/paid_busfee_amount?start_date=&end_date=&class_id=&section_id="><i class="fa fa-circle-o"></i> Paid Busfees Amounts</a></li>
                    <li <?php if ($this->router->fetch_method() == 'pending_busfee_amount') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>busfees/pending_busfee_amount"><i class="fa fa-circle-o"></i> Pending Busfees Amounts</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'drivers') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-drupal"></i> <span>Drivers</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_drivers') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>driver/manage_drivers"><i class="fa fa-circle-o"></i> Manage Drivers</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_driver') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>driver/add_driver"><i class="fa fa-circle-o"></i> Add Driver</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'busroutes') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-bus"></i> <span>Busroutes</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_busroutes') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>busroute/manage_busroutes"><i class="fa fa-circle-o"></i> Manage Busroutes</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_busroute') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>busroute/add_busroute"><i class="fa fa-circle-o"></i> Add Busroute</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'examtypes') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-sticky-note-o"></i> <span>Exam Types</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_examtypes') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>examtypes/manage_examtypes"><i class="fa fa-circle-o"></i> Manage Exam Types</a></li>
                    <li <?php if ($this->router->fetch_method() == 'add_examtype') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>examtypes/add_examtype"><i class="fa fa-circle-o"></i> Add Exam Type</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'messages') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-mercury"></i> <span>Message To Parents</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <li <?php if ($this->router->fetch_method() == 'manage_messages') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>messages/manage_messages?date="><i class="fa fa-circle-o"></i> Manage Messages </a></li>
                    <li <?php if ($this->router->fetch_method() == 'send_message') { ?> class="active" <?php } ?>><a href="<?php echo base_url(); ?>messages/send_message"><i class="fa fa-circle-o"></i> Send Message</a></li>
                </ul>
            </li>
            <li class="treeview <?php
            if ($menu_item == 'settings') {
                echo 'active';
            }
            ?>">
                <a href="#">
                    <i class="fa fa-cog"></i> <span>Settings</span>
                    <span class="pull-right-container">
                        <i class="fa fa-angle-left pull-right"></i>
                    </span>
                </a>
                <ul class="treeview-menu">
                    <!--<li <?php if ($this->router->fetch_method() == 'edit_profile') { ?> class="active" <?php } ?> ><a href="<?php echo base_url(); ?>admin/edit_profile"><i class="fa fa-circle-o"></i> Edit Profile</a></li>-->
                    <li <?php if ($this->router->fetch_method() == 'change_password') { ?> class="active" <?php } ?> ><a href="<?php echo base_url(); ?>admin/change_password"><i class="fa fa-circle-o"></i> Change Password</a></li>
                    <li <?php if ($this->router->fetch_method() == 'logout') { ?> class="active" <?php } ?> ><a href="<?php echo base_url(); ?>admin/logout"><i class="fa fa-circle-o"></i> Logout</a></li>
                </ul>
            </li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>
<style>
    /*    .sidebar {
            height: 600px !important;
            overflow-y: scroll;
            padding-bottom: 10px;
        }
    
    
    
        .main-header {
            max-height: 100px;
            position: fixed;
            width: 100%;
            z-index: 1030;
        }
    
    
        .main-sidebar, .left-side {
            left: 0;
            min-height: 100%;
            padding-top: 50px;
            position: fixed;
            top: 0;
            transition: transform 0.3s ease-in-out 0s, width 0.3s ease-in-out 0s;
            width: 230px;
            z-index: 810;
        }*/

</style>