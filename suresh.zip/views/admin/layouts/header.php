<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <link rel="shortcut icon" type="image/ico" href="<?php echo base_url(); ?>assets/images/favicon.ico"/>
        <title>Amel IT | School Dashboard</title>
        <!-- Tell the browser to be responsive to screen width -->
        <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
        <!-- Bootstrap 3.3.6 -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/bootstrap.min.css">
        <!-- Bootstrap TimePicker -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/timepicker.css">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
        <!-- Ionicons -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
        <!-- DataTables -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/dataTables.bootstrap.css">
        <!-- Theme style -->
        <link rel="stylesheet" href="<?php echo base_url() ?>assets/admin/css/bootstrap-multiselect.css" type="text/css"/>
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/AdminLTE.min.css">
        <!-- AdminLTE Skins. Choose a skin from the css/skins
             folder instead of downloading all of them to reduce the load. -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/_all-skins.min.css">
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/admin/css/styles.css">
        <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

        <script src="<?php echo base_url(); ?>assets/admin/js/jquery-2.2.3.min.js"></script>
        <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
        <script src="<?php echo base_url(); ?>assets/admin/js/jquery.validate.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>assets/admin/js/bootstrap-multiselect.js"></script>
        <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
        <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
        <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
        <![endif]-->
    </head>
    <body class="hold-transition skin-blue sidebar-mini">
        <div class="loading-overlay" id="loading_icon">
            <span class="fa fa-spinner fa-spin loading-icon"></span>  
            <!--/var/www/html/school_website/assets/admin/images-->
            <!--<img class="loading-icon" src="<?php // echo base_url() . 'assets/admin/images/loading.gif'       ?>" alt="loading.."/>-->
            <span class="loading-icon-span">Loading.. please wait</span>
        </div>
        <div class="wrapper">
            <header class="main-header">
                <!-- Logo -->
                <a href="javascript:void(0);" class="logo">
                    <!-- mini logo for sidebar mini 50x50 pixels -->
                    <span class="logo-mini"><b>School</b></span>
                    <!-- logo for regular state and mobile devices -->
                    <span class="logo-lg"><b>School</b> Dashboard</span>
                </a>
                <!-- Header Navbar: style can be found in header.less -->
                <nav class="navbar navbar-static-top">
                    <!-- Sidebar toggle button-->
                    <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </a>
                    <div class="navbar-custom-menu">
                        <ul class="nav navbar-nav">
                            <!-- User Account: style can be found in dropdown.less -->
                            <li class="dropdown user user-menu">
                                <a href="<?php echo base_url() . 'dashboard' ?>"><!-- class="dropdown-toggle" data-toggle="dropdown" -->
                                    <img src="<?php echo $user_data['profile_pic']; ?>" class="user-image" alt="">
                                    <span class="hidden-xs"><?php echo ucfirst($user_data['institutename']); ?></span>
                                </a>
                            </li>
                            <!-- Control Sidebar Toggle Button -->
                            <li>
                                <a href="<?php echo base_url() . 'admin/logout'; ?>">Log out</a>
                            </li>
                        </ul>
                    </div>
                </nav>
            </header>