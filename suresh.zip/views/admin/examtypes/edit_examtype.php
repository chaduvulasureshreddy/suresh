<!-- Content Wrapper. Contains page content -->
<style>
    label.error, .errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Examtype
            <small>Edit Examtype</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'examtypes/manage_examtypes' ?>">Manage Examtypes</a></li>
            <li class="active">Edit Examtype</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="classForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="first_name">Examtype Name:<span class="text-danger">*</span></label>
                                <input type="hidden" class="form-control" name="examtype_id" id="examtype_id" value="<?php echo $examtype_details['id']; ?>" required>
                                <input type="text" class="form-control" name="exam_name" id="exam_name" placeholder="Examtype Name" onkeyup="toCheckExamtypeName()" value="<?php echo $examtype_details['exam_name']; ?>" required>
                                <span class="errormessage" id="examtype_exist_message"></span>
                            </div>
                            <div class="form-group">
                                <label for="about">Status:</label>
                                <select class="form-control" name="exam_status" id="exam_status">
                                    <option value="A" <?php
                                    if ($examtype_details['exam_status'] == "A") {
                                        echo "selected";
                                    }
                                    ?>>Active</option>
                                    <option value="I" <?php
                                    if ($examtype_details['exam_status'] == "I") {
                                        echo "selected";
                                    }
                                    ?>>In Active</option>

                                </select>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="examtype_save">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
    $("#classForm").validate({
        rules: {
            exam_name: "required"
        },
        messages: {
            exam_name: "Please enter examtype name"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    function toCheckExamtypeName() {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Examtypes/toCheckExamtypeName",
            data: {exam_name: $('#exam_name').val(), examtype_id: $('#examtype_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#examtype_exist_message').html('Examtype already exist with this name');
                            $('#examtype_save').prop('disabled', true);
                        } else {
                            $('#examtype_exist_message').html('');
                            $('#examtype_save').prop('disabled', false);
                        }
                    }
        });
    }
</script>