<!-- Content Wrapper. Contains page content -->

<style>
    #dvPreview
    {
        filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=image);
        height: 200px;
        width: 200px;
        display: none;
    }
    label.error, .errormessage {
        color: red;
    }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Drivers
            <small>Add Driver</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Add Driver</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <!--            <div class="box-header with-border">
                                  <h3 class="box-title">Quick Example</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="" id="driverForm" method="POST" enctype="multipart/form-data">
                        <div class="box-body">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="driver_name">Driver Name:<span class="text-danger">*</span></label>
                                        <input type="text" minlength="3" class="form-control" name="driver_name" id="driver_name" value="" placeholder="Driver Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mobile_number">Mobile Number:<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="mobile_number" id="mobile_number" value="" placeholder="Mobile Number" onkeyup="toChkDriver()" required>
                                        <span class="errormessage" id="driver_exist_message"></span>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="aadhar_number">Aadhar Number:<span class="text-danger">*</span></label>
                                        <input type="text" minlength="3" class="form-control" name="aadhar_number" id="aadhar_number" value="" placeholder="Aadhar Number" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="license_number">Driving License:<span class="text-danger">*</span></label>
                                        <input type="text" minlength="3" class="form-control" name="license_number" id="license_number" value="" placeholder="Driving License" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pno">Password: <span class="text-danger">*</span></label>
                                        <input type="text" minlength="3" class="form-control" name="password" id="password" value="" placeholder="Please enter password" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="driver_status">Status: <span class="text-danger">*</span></label>
                                        <select name="driver_status" id="driver_status" class="form-control" required>
                                            <option value="">Please Select Status</option>
                                            <option value="A">Active</option>
                                            <option value="I">Inactive</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pno">Driver Description:</label>
                                        <textarea name="driver_description" id="driver_description" class="form-control" placeholder="Enter Driver Description"></textarea>
                                    </div>
                                </div>
                            </div>


                            <div class="form-group">
                                <div class="col-sm-6">
                                    <label for="Image">Image:</label>
                                    <input type="file" name="driver_pic" id="fileupload" accept="image/*">
                                </div>
                                <div class="col-sm-6">
                                    <div id="dvPreview">
                                    </div>
                                </div>
                            </div>

                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="driver_save">Save</button>
                            <span class="pull-right">Note: <span class="text-danger">*</span> fields are mandatory</span>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>

    function toChkDriver() {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Driver/toCheckDriver",
            data: {mobile_number: $('#mobile_number').val(), id: ''},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#driver_exist_message').html('Driver already exist with this number');
                            $('#driver_save').prop('disabled', true);
                        } else {
                            $('#driver_exist_message').html('');
                            $('#driver_save').prop('disabled', false);
                        }
                    }
        });
    }
    $(function () {
        $("#fileupload").change(function () {
            $("#dvPreview").html("");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            if (regex.test($(this).val().toLowerCase())) {
                if (typeof (FileReader) != "undefined") {
                    $("#dvPreview").show();
                    $("#dvPreview").append("<img />");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $("#dvPreview img").attr("src", e.target.result);
                        $("#dvPreview img").attr("height", '100');
                        $("#dvPreview img").attr("width", '100');
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            } else {
                alert("Please upload a valid image file.");
            }
        });
    });

    $("#driverForm").validate({
        rules: {
            driver_name: "required",
            password: "required",
            driver_status: "required",
            aadhar_number: "required",
            mobile_number: {
                required: true,
                number: true
            },
            license_number: "required"
        },
        messages: {
            driver_name: "Please enter driver name",
            password: "Please enter password",
            driver_status: "Please select driver status",
            aadhar_number: "Please enter aadhar number",
            license_number: "Please select driving license",
            mobile_number: {
                required: "Please enter mobile number",
                number: "Please enter numbers only"
            }

        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
</script>