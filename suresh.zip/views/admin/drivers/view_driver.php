<!-- Content Wrapper. Contains page content -->
<style>
    label.error,.errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            View Driver
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'driver/manage_drivers' ?>">Manage Drivers</a></li>
            <li class="active">View Driver</li>
        </ol>
    </section>
    <?php // echo '<pre>';print_r($driverInfo);?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-11">

            </div>
            <div>
                <div class="col-md-8 col-xs-offset-2">
                    <ul class=" list-unstyled list-inline">
                        <li>
                            <a href="<?php echo base_url() . 'driver/manage_drivers' ?>" class="btn btn-sm btn-primary" style="float:left">
                                <i class="fa fa-arrow-left"></i> Back
                            </a>
                        </li>
                        <li class=" pull-right">
                            <button class="btn btn-sm btn-primary" style="float:left" onclick="toDownloadPdf()">
                                <i class="fa fa-download"></i> Download Driver Info
                            </button>
                        </li>
                    </ul>
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- /.box-header -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h4><b>Driver Profile Information:</b></h4>
                                </div>
                                <div class="col-sm-3">
                                    <div id="old_img">
                                        <div class="form-group">
                                            <?php if (!empty($driverInfo['driver_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $driverInfo['driver_image'])) { ?>
                                                <img src="<?php echo base_url() . 'uploads/profile_pics/' . $driverInfo['driver_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                                            <?php } else { ?>
                                                <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <input type="hidden" id="id" value="<?php echo $driverInfo['id']; ?>" name="id">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_name">Driver Name:</label>
                                        <?php echo ucfirst($driverInfo['driver_name']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="id">Aadhar Number:</label>
                                        <?php echo $driverInfo['aadhar_number']; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="class_name">Driving License:</label>
                                        <?php echo $driverInfo['license_number']; ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="section_name">Mobile Number:</label>
                                        <?php echo $driverInfo['mobile_number']; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="class_name">Driving Description:</label>
                                        <?php echo $driverInfo['driver_description']; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--</div>-->
                        <!--</div>-->
                    </div>
                    <!--/.col (left) -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>
    function toDownloadPdf() {
        var driver_id = $('#id').val();
        var url = '<?php echo base_url() ?>' + 'driver/toDownloadAsPdf?id=' + driver_id;
        document.location = url;
    }
</script>