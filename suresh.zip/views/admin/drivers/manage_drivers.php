<!-- Content Wrapper. Contains page content -->
<style>
    .dataTables_empty{
        text-align: center;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Drivers
            <small>Manage Drivers</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Manage Drivers</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <!--            <div class="box-header">
                                  <h3 class="box-title">Data Table With Full Features</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div style="padding:10px;">
                        <div class="row">
                            <div class="col-sm-10">

                            </div>
                            <?php if ($drivers) { ?>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <button class="btn btn-primary btn-md" onclick="toExportDriversData()">
                                            <i class="fa fa-download"></i> Export Drivers Data </button>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <!--<input type="checkbox" name="select_all" id="select_all"/>-->
                                    </th>
                                    <th>Id</th>
                                    <th>Image</th>
                                    <th>Driver Name</th>
                                    <th>Mobile Number</th>
                                    <th>Aadhar Number</th>
                                    <th>License</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($drivers) {
                                    foreach ($drivers as $k => $user_row) {
                                        ?>
                                        <tr>
                                            <td><input type="checkbox" class="checkbox" name="selectAll_<?php echo $user_row['id']; ?>" id="selectAll_<?php echo $user_row['id']; ?>" data-id="<?php echo $user_row['id']; ?>"></td>
                                            <td><?php echo ++$k; ?></td>
                                            <?php if (!empty($user_row['driver_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $user_row['driver_image'])) { ?>
                                                <td><img src="<?php echo base_url() . 'uploads/profile_pics/' . $user_row['driver_image']; ?>" height="50" width="50" class="user-image" alt="No Image"></td>
                                            <?php } else { ?>
                                                <td><img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="50" width="50" class="user-image" alt="No Image"></td>
                                            <?php } ?>
                                            <td><?php echo ucfirst($user_row['driver_name']); ?></td>
                                            <td><?php echo $user_row['mobile_number']; ?></td>
                                            <td><?php echo $user_row['aadhar_number']; ?></td>
                                            <td><?php echo $user_row['license_number']; ?></td>
                                            <td><?php
                                                if ($user_row['driver_status'] == 'A') {
                                                    echo "Active";
                                                } else {
                                                    echo "Inactive";
                                                }
                                                ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'driver/view_driver/' . $user_row['id'] ?>"><i class="fa fa-eye"></i> View</a>&nbsp;&nbsp;&nbsp;
                                                <a href="<?php echo base_url() . 'driver/edit_driver/' . $user_row['id'] ?>"><i class="fa fa-edit"></i> Edit</a>&nbsp;&nbsp;&nbsp;
                                                <a href="<?php echo base_url() . 'driver/delete_driver/' . $user_row['id'] ?>" onclick="return confirm('Are you sure you want to delete this ?');"><i class="fa fa-remove"></i> Delete</a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <?php if ($drivers) { ?>
                        <div style="padding:10px;"><button class="btn btn-md btn-primary" id="delete_all">Delete All</button></div>
<?php } ?>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
    //alert($('#category_id').val());


    function toExportDriversData() {

        var url = '<?php echo base_url() ?>' + 'driver/export_drivers_data';
        document.location = url;
    }

    $("#select_all").change(function () {  //"select all" change
        $(".checkbox").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
    });

//".checkbox" change
    $('.checkbox').change(function () {
        //uncheck "select all", if one of the listed checkbox item is unchecked
        if (false == $(this).prop("checked")) { //if this item is unchecked
            $("#select_all").prop('checked', false); //change "select all" checked status to false
        }
        //check "select all" if all checkbox items are checked
        if ($('.checkbox:checked').length == $('.checkbox').length) {
            $("#select_all").prop('checked', true);
        }
    });

    $('#delete_all').on('click', function (e) {
        var allVals = [];
        $(".checkbox:checked").each(function () {
            allVals.push($(this).attr('data-id'));
        });
        if (allVals.length <= 0)
        {
            alert("Please select at least one to delete.");
        } else {
            var y = "Are you sure you want to delete this row?";
            var check = confirm(y);
            if (check === true) {
                //for server side
                var join_selected_values = allVals.join(",");
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url() ?>driver/delete_multiple_drivers",
                    cache: false,
                    data: 'ids=' + join_selected_values,
                    success: function (response)
                    {
                        console.log(response);
                        location.reload();
                        //referesh table
                    }
                });
            }
        }
    });
</script>