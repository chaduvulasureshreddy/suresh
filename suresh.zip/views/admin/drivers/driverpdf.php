<style>
    table {
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }

    th, td {
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even){background-color: #f2f2f2}
</style>

<h4><u>Driver Profile Information:</u></h4>
<!-- general form elements -->
<table class="table table-bordered table-striped">
    <tbody>
        <tr>
            <td>
                <b>School Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($user_data['institutename']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Driver Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($driverInfo['driver_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Aadhar Number:</b>
            </td>
            <td>
                <b><?php echo $driverInfo['aadhar_number']; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Driving License:</b>
            </td>
            <td>
                <b><?php echo $driverInfo['license_number']; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Driver Photo:</b>
            </td>
            <td>
                <?php if (!empty($driverInfo['driver_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $driverInfo['driver_image'])) { ?>
                    <img src="<?php echo base_url() . 'uploads/profile_pics/' . $driverInfo['driver_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                <?php } else { ?>
                    <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                <?php } ?>
            </td>
        </tr>
        <tr>
            <td>
                <b>Mobile Number:</b>
            </td>
            <td>
                <b><?php echo $driverInfo['mobile_number']; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Description:</b>
            </td>
            <td>
                <b>
                    <?php echo $driverInfo['driver_description']; ?>
                </b>
            </td>
        </tr>
    </tbody>
</table>
