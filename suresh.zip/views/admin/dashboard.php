<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            <?php echo ucfirst($user_data['institutename']); ?>
            <small>Dashboard</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#"><?php echo ucfirst($user_data['institutename']); ?></a></li>
            <li class="active">Dashboard</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-blue">
                    <div class="inner">
                        <h3><?php
                            if ($classes) {
                                echo $classes;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Classes</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-cloud"></i>
                    </div>
                    <a href="<?php echo base_url() . 'classdata/manage_classes'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-green">
                    <div class="inner">
                        <h3><?php
                            if ($sections) {
                                echo $sections;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Sections</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-sellsy"></i>
                    </div>
                    <a href="<?php echo base_url() . 'section/manage_sections'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php
                            if ($subjects) {
                                echo $subjects;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Subjects</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-subway"></i>
                    </div>
                    <a href="<?php echo base_url() . 'subject/manage_subjects'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!-- small box -->
                <div class="small-box bg-green-gradient">
                    <div class="inner">
                        <h3><?php
                            if ($students) {
                                echo $students;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Students</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-users"></i>
                    </div>
                    <a href="<?php echo base_url() . 'admin/manage_students?class_id=&section_id='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-aqua">
                    <div class="inner">
                        <h3><?php
                            if ($attendance) {
                                echo $attendance;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Attendance</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-adjust"></i>
                    </div>
                    <a href="<?php echo base_url() . 'attendance/manage_attendance?date=&class_id=&section_id='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-purple">
                    <div class="inner">
                        <h3><?php
                            if ($homeworks) {
                                echo $homeworks;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Homework</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-wordpress"></i>
                    </div>
                    <a href="<?php echo base_url() . 'homework/manage_home_works?date=&class_id=&section_id='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-red-active">
                    <div class="inner">
                        <h3><?php
                            if ($remarks) {
                                echo $remarks;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Student Performance</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-warning"></i>
                    </div>
                    <a href="<?php echo base_url() . 'remark/manage_remarks?date=&class_id=&section_id='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-fuchsia">
                    <div class="inner">
                        <h3><?php
                            if ($pendingfee) {
                                echo 'Rs: ' . $pendingfee . '/-';
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Pending Fee Amount</p>
                    </div>
                    <div class="icon">
                        <!--<i class="fa fa-money"></i>-->
                    </div>
                    <a href="<?php echo base_url() . 'fees/pending_fee_amount'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-purple">
                    <div class="inner">
                        <h3><?php
                            if ($paidfee) {
                                echo 'Rs: ' . $paidfee . '/-';
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Paid Fee Amount</p>
                    </div>
                    <div class="icon">
                        <!--<i class="fa fa-money"></i>-->
                    </div>
                    <a href="<?php echo base_url() . 'fees/paid_fee_amount?start_date=&end_date=&class_id=&section_id='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-blue-gradient">
                    <div class="inner">
                        <h3><?php
                            if ($messages) {
                                echo $messages;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Message To Parents</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-mercury"></i>
                    </div>
                    <a href="<?php echo base_url() . 'messages/manage_messages?date='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-green-active">
                    <div class="inner">
                        <h3><?php
                            if ($students) {
                                echo $students;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Student Records</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-globe"></i>
                    </div>
                    <a href="<?php echo base_url() . 'allinfo/students?class_id=&section_id='; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-blue-active">
                    <div class="inner">
                        <h3><?php
                            if ($drivers) {
                                echo $drivers;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Drivers</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-drupal"></i>
                    </div>
                    <a href="<?php echo base_url() . 'driver/manage_drivers'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
            <div class="col-lg-3 col-xs-6">
                <!--small box--> 
                <div class="small-box bg-aqua-gradient">
                    <div class="inner">
                        <h3><?php
                            if ($busroutes) {
                                echo $busroutes;
                            } else {
                                echo '0';
                            }
                            ?></h3>
                        <p>Bus Routes</p>
                    </div>
                    <div class="icon">
                        <i class="fa fa-bus"></i>
                    </div>
                    <a href="<?php echo base_url() . 'busroute/manage_busroutes'; ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });

</script>