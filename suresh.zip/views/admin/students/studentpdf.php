<style>
    table {
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }

    th, td {
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even){background-color: #f2f2f2}
</style>

<h4><u>Student Profile Information:</u></h4>
<!-- general form elements -->
<table class="table table-bordered table-striped">
    <tbody>
        <tr>
            <td>
                <b>School Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($user_data['institutename']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Admission Number:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['sch_admission_id']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Photo:</b>
            </td>
            <td>
                <?php if (!empty($studentInfo['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $studentInfo['student_image'])) { ?>
                    <img src="<?php echo base_url() . 'uploads/profile_pics/' . $studentInfo['student_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                <?php } else { ?>
                    <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                <?php } ?>
            </td>
        </tr>
        <tr>
            <td>
                <b>Father Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_father_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Mother Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_mother_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Gender:</b>
            </td>
            <td>
                <b>
                    <?php
                    if ($studentInfo['student_gender'] == 'M')
                        echo ucfirst('boy');
                    else
                        echo ucfirst('girl');
                    ?>
                </b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Date of Birth:</b>
            </td>
            <td>
                <b>
                    <?php
                    if (!empty($studentInfo['student_dob']) && $studentInfo['student_dob'] != "0000-00-00") {
                        echo date('dS-F-Y', strtotime($studentInfo['student_dob']));
                    } else {
                        echo "--";
                    }
                    ?>
                </b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Class:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['class_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Section:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['section_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Contact Number:</b>
            </td>
            <td>
                <b><?php echo $studentInfo['student_mobile']; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Blood Group:</b>
            </td>
            <td>
                <b><?php
                    if ($studentInfo['student_blood_group']) {
                        echo ucfirst($studentInfo['student_blood_group']);
                    } else {
                        echo '--';
                    }
                    ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Caste:</b>
            </td>
            <td>
                <b><?php
                    if ($studentInfo['student_caste']) {
                        echo ucfirst($studentInfo['student_caste']);
                    } else {
                        echo '--';
                    }
                    ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Joining Date:</b>
            </td>
            <td>
                <b><?php
                    if (!empty($studentInfo['student_joining_date']) && $studentInfo['student_joining_date'] != "0000-00-00") {
                        echo date('dS-F-Y', strtotime($studentInfo['student_joining_date']));
                    } else {
                        echo "--";
                    }
                    ?>
                </b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Joined Class:</b>
            </td>
            <td>
                <b><?php echo $studentInfo['student_joined_class']; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Tuition Fee Amount:</b>
            </td>
            <td>
                <b><?php echo 'Rs: ' . $studentInfo['student_fee'] . '/-'; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Books Fee Amount:</b>
            </td>
            <td>
                <b><?php echo 'Rs: ' . $studentInfo['books_fee'] . '/-'; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Bus Fee Amount:</b>
            </td>
            <td>
                <b><?php echo 'Rs: ' . $studentInfo['bus_fee'] . '/-'; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Submitted Documents at joining time:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_documents']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Address:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_address']); ?></b>
            </td>
        </tr>
    </tbody>
</table>
