<!-- Content Wrapper. Contains page content -->
<style>
    #dvPreview
    {
        filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=image);
        height: 200px;
        width: 200px;
        display: none;
    }
    label.error {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Students
            <small>Edit Student</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'admin/manage_students?class_id=&section_id=' ?>">Manage Students</a></li>
            <li class="active">Edit Student</li>
        </ol>
    </section>
    <?php //print_r($classes);  exit; ?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="box box-primary">
                    <!--            <div class="box-header with-border">
                                  <h3 class="box-title">Quick Example</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="signupForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_name">Student Name:<span class="text-danger">*</span></label>
                                        <input type="hidden" name="studentId" value="<?php echo $user_details['id']; ?>"/>
                                        <input type="text" minlength="3" class="form-control" name="student_name" id="student_name" value="<?php echo $user_details['student_name']; ?>" placeholder="Student Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="admissionnumber">Admission No:<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="admissionnumber" id="admissionnumber" value="<?php echo $user_details['sch_admission_id']; ?>" readonly="readonly" placeholder="Admission Number" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_father_name">Father Name:<span class="text-danger">*</span></label>
                                        <input type="text" minlength="3" class="form-control" name="student_father_name" id="student_father_name" value="<?php echo $user_details['student_father_name']; ?>" placeholder="Father Name" required>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_mother_name">Mother Name:<span class="text-danger">*</span></label>
                                        <input type="text" minlength="3" class="form-control" name="student_mother_name" id="student_mother_name" value="<?php echo $user_details['student_mother_name']; ?>" placeholder="Mother Name" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_gender">Gender:<span class="text-danger">*</span></label>
                                        <select name="student_gender" id="student_gender" class="form-control" required>
                                            <option value="">Please Select</option>
                                            <option value="M" <?php
                                            if ($user_details['student_gender'] === 'M') {
                                                echo "selected";
                                            }
                                            ?>>Boy</option>
                                            <option value="F" <?php
                                            if ($user_details['student_gender'] === 'F') {
                                                echo "selected";
                                            }
                                            ?>>Girl</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="pno">Contact No:<span class="text-danger">*</span></label>
                                        <input type="text" maxlength="15" title="Enter only numbers" class="form-control" name="student_mobile" id="student_mobile" value="<?php echo $user_details['student_mobile']; ?>" placeholder="Contact Number" required>
                                    </div>
                                </div>
                            </div>

                            <div class="row">                    
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_class">Class:<span class="text-danger">*</span></label>
                                        <select class="form-control" name="student_class_id" id="student_class_id" onchange="toGetSectionsByClass()" required>
                                            <option value="">Select</option>
                                            <?php
                                            if ($classes) {
                                                foreach ($classes as $count_row) :
                                                    ?>
                                                    <option value="<?php echo $count_row['id']; ?>"<?php
                                                    if ($user_details['student_class_id'] == $count_row['id']) {
                                                        echo "selected"; //exit;
                                                    }
                                                    ?>><?php echo $count_row['class_name']; ?></option>
                                                            <?php
                                                        endforeach;
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_class">Section:<span class="text-danger">*</span></label>
                                        <select class="form-control" name="student_section_id" id="student_section_id" required>
                                            <option value="">Select</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="address">Address:<span class="text-danger">*</span></label>
                                        <textarea class="form-control" name="address" id="address" placeholder="Address" required><?php echo $user_details['student_address']; ?></textarea>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="address">Documents:</label>
                                        <textarea class="form-control" name="student_documents" id="student_documents" placeholder="Please enter documents, which are collected from the student on joining time"><?php echo $user_details['student_documents']; ?></textarea>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="fee">Joining Date:</label>
                                            <input type="text" title="Please Enter Student Joining Date" class="form-control" name="student_joining_date" id="datepicker1" value="<?php echo $user_details['student_joining_date']; ?>" placeholder="Student Joining Date" readonly>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_class">Joined Class:</label>
                                        <input type="text" title="Please Enter Student Joining Class" class="form-control" name="student_joined_class" id="student_joined_class" value="<?php echo $user_details['student_joined_class']; ?>" placeholder="Student Joining Class">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="bus_no">Bus Route No:</label>
                                        <select class="form-control" name="student_bus_no" id="student_bus_no">
                                            <option value="">Select bus route</option>
                                            <?php
                                            if ($buses) {
                                                foreach ($buses as $count_row) :
                                                    ?>
                                                    <option value="<?php echo $count_row['id']; ?>"<?php
                                                    if ($user_details['student_bus_no'] == $count_row['id']) {
                                                        echo "selected"; //exit;
                                                    }
                                                    ?>><?php echo $count_row['bus_no']; ?></option>
                                                            <?php
                                                        endforeach;
                                                    }
                                                    ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="fee">Tuition Fee:<span class="text-danger">*</span></label>
                                            <input type="text" title="Please Enter Fee Amount" class="form-control" name="student_fee" id="student_fee" value="<?php echo $user_details['student_fee']; ?>" placeholder="Student Fee" required>
                                        </div>
                                    </div>
                                </div>

                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="fee">Bus Fee:<span class="text-danger">*</span></label>
                                            <input type="text" title="Please Enter Bus Fee Amount" class="form-control" name="bus_fee" id="bus_fee" value="<?php echo $user_details['bus_fee']; ?>" placeholder="Bus Fee" required>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <div class="form-group">
                                            <label for="fee">Books Fee:<span class="text-danger">*</span></label>
                                            <input type="text" title="Please Enter Books Fee Amount" class="form-control" name="books_fee" id="books_fee" value="<?php echo $user_details['books_fee']; ?>" placeholder="Books Fee" required>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Date of Birth:</label>
                                        <input type="text" class="form-control" name="student_dob" id="datepicker" value="<?php echo $user_details['student_dob']; ?>" placeholder="Please Select Date of Birth" readonly>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_blood_group">Blood Group:</label>
                                        <select class="form-control" name="student_blood_group" id="student_blood_group">
                                            <option value="">Please Select</option>
                                            <option value="O+" <?php
                                            if ($user_details['student_blood_group'] === 'O+') {
                                                echo "selected";
                                            }
                                            ?>>O Positive</option>
                                            <option value="O-" <?php
                                            if ($user_details['student_blood_group'] === 'O-') {
                                                echo "selected";
                                            }
                                            ?>>O Negative</option>
                                            <option value="A+" <?php
                                            if ($user_details['student_blood_group'] === 'A+') {
                                                echo "selected";
                                            }
                                            ?>>A Positive</option>
                                            <option value="A-" <?php
                                            if ($user_details['student_blood_group'] === 'A-') {
                                                echo "selected";
                                            }
                                            ?>>A Negative</option>
                                            <option value="B+" <?php
                                            if ($user_details['student_blood_group'] === 'B+') {
                                                echo "selected";
                                            }
                                            ?>>B Positive</option>
                                            <option value="B-" <?php
                                            if ($user_details['student_blood_group'] === 'B-') {
                                                echo "selected";
                                            }
                                            ?>>B Negative</option>
                                            <option value="AB+" <?php
                                            if ($user_details['student_blood_group'] === 'AB+') {
                                                echo "selected";
                                            }
                                            ?>>AB Positive</option>
                                            <option value="AB-" <?php
                                            if ($user_details['student_blood_group'] === 'AB-') {
                                                echo "selected";
                                            }
                                            ?>>AB Negative</option>
                                            <option value="Bo" <?php
                                            if ($user_details['student_blood_group'] === 'Bo') {
                                                echo "selected";
                                            }
                                            ?>>Bombay Blood</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="student_caste">Caste:</label>
                                        <select name="student_caste" id="student_caste" class="form-control">
                                            <option value="">Please Select</option>
                                            <option value="OC" <?php
                                            if ($user_details['student_caste'] === 'OC') {
                                                echo "selected";
                                            }
                                            ?>>OC</option>
                                            <option value="BC" <?php
                                            if ($user_details['student_caste'] === 'BC') {
                                                echo "selected";
                                            }
                                            ?>>BC</option>
                                            <option value="ST" <?php
                                            if ($user_details['student_caste'] === 'ST') {
                                                echo "selected";
                                            }
                                            ?>>ST</option>
                                            <option value="SC" <?php
                                            if ($user_details['student_caste'] === 'SC') {
                                                echo "selected";
                                            }
                                            ?>>SC</option>
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-sm-6">
                                    <label for="Image">Image:</label>
                                    <input type="file" name="profile_pic" id="fileupload">
                                </div>
                                <div class="col-sm-6">
                                    <div id="dvPreview">
                                    </div>
                                    <div id="old_img">
                                        <?php if (!empty($user_details['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $user_details['student_image'])) { ?>
                                            <img src="<?php echo base_url() . 'uploads/profile_pics/' . $user_details['student_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                                        <?php } else { ?>
                                            <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                                        <?php } ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Save</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetSectionsByClass",
            data: {class_id: $('#student_class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_section_id').html(data);
                            $("#student_section_id").val("<?php echo $user_details['student_section_id']; ?>");
                        } else {

                            $('#student_section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
        return false;
    });
    function toGetSectionsByClass() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetSectionsByClass",
            data: {class_id: $('#student_class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_section_id').html(data);
                        } else {
                            $('#student_section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
        return false;
    }
    $(function () {
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, yearRange: "-50:+0", maxDate: 0});
        $("#datepicker1").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, yearRange: "-50:+0", maxDate: 0});
    });
    $(function () {
        $("#fileupload").change(function () {
            $('#old_img').hide();
            $("#dvPreview").html("");
            var regex = /^([a-zA-Z0-9\s_\\.\-:])+(.jpg|.jpeg|.gif|.png|.bmp)$/;
            if (regex.test($(this).val().toLowerCase())) {
                if (typeof (FileReader) != "undefined") {
                    $("#dvPreview").show();
                    $("#dvPreview").append("<img />");
                    var reader = new FileReader();
                    reader.onload = function (e) {
                        $("#dvPreview img").attr("src", e.target.result);
                        $("#dvPreview img").attr("height", '100');
                        $("#dvPreview img").attr("width", '100');
                    }
                    reader.readAsDataURL($(this)[0].files[0]);
                } else {
                    alert("This browser does not support FileReader.");
                }
            } else {
                alert("Please upload a valid image file.");
            }
        });
    });
    $("#signupForm").validate({
        rules: {
            student_name: "required",
            admissionnumber: "required",
            student_father_name: "required",
            student_mother_name: "required",
            student_gender: "required",
            student_mobile: {
                required: true,
                number: true
            },
            address: "required",
            student_class_id: "required",
            student_section_id: "required",
            student_fee: "required",
            bus_fee: "required",
            books_fee: "required"
        },
        messages: {
            student_name: "Please enter student name",
            admissionnumber: "Please enter admission number",
            student_father_name: "Please enter father name",
            student_mother_name: "Please enter mother name",
            student_gender: "Please select student gender",
            student_mobile: {
                required: "Please enter mobile number",
                number: "Please enter numbers only"
            },
            address: "Please enter student address",
            student_class_id: "Please select student class",
            student_section_id: "Please select class section",
            student_fee: "Please enter student fee amount",
            bus_fee: "Please enter bus fee amount",
            books_fee: "Please enter books fee amount"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
</script>
