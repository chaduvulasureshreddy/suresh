<!-- Content Wrapper. Contains page content -->
<style>
    .dataTables_empty{
        text-align: center;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Students
            <small>Manage Students</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Manage Students</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <!--            <div class="box-header">
                                  <h3 class="box-title">Data Table With Full Features</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div style="padding:10px;">
                        <div class="row">
                            <div class="col-sm-1">
                                <div class="form-group">
                                    <label for="student_filters">Filters:</label>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <select class="form-control" name="student_class_id" id="student_class_id" onchange="toGetStudents()" required>
                                        <option value="">Select Class</option>
                                        <?php
                                        if ($classes) {
                                            foreach ($classes as $count_row) {
                                                ?>
                                                <option value="<?php echo $count_row['id']; ?>" <?php
                                                if (isset($_GET['class_id'])) {
                                                    if ($_GET['class_id'] == $count_row['id']) {
                                                        echo "selected";
                                                    }
                                                }
                                                ?>><?php echo $count_row['class_name']; ?></option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <select class="form-control" name="student_section_id" id="student_section_id" onchange="toGetStudentsBySections()" required>
                                        <option value="">Select Section</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <a class="btn btn-primary btn-md" href="<?php echo base_url() . 'admin/manage_students?class_id=&section_id='; ?>">
                                        <i class="fa fa-refresh"></i> Refresh
                                    </a>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <!--<form>-->
                                <div class="form-group">
                                    <a href="<?php echo base_url() . 'admin/uploadstudentImages'; ?>" class="btn btn-primary btn-md">
                                        <i class="fa fa-plus"></i> Import Students Data 
                                    </a>
                                </div>
                                <!--</form>-->
                            </div>
                            <?php if ($students) { ?>
                                <div class="col-sm-2">
                                    <div class="form-group">
                                        <button class="btn btn-primary btn-md" onclick="toExportStudentsData()">
                                            <i class="fa fa-download"></i> Export Students Data </button>
                                    </div>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <!--<input type="checkbox" name="select_all" id="select_all"/>-->
                                    </th>
                                    <th>Id</th>
                                    <th>Image</th>
                                    <th>Admission No.</th>
                                    <th>Student Name</th>
                                    <th>Father Name</th>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($students) {
                                    foreach ($students as $k => $user_row) {
                                        ?>
                                        <tr>
                                            <td><input type="checkbox" class="checkbox" name="selectAll_<?php echo $user_row['id']; ?>" id="selectAll_<?php echo $user_row['id']; ?>" data-id="<?php echo $user_row['id']; ?>"></td>
                                            <td><?php echo ++$k; ?></td>
                                            <?php if (!empty($user_row['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $user_row['student_image'])) { ?>
                                                <td><img src="<?php echo base_url() . 'uploads/profile_pics/' . $user_row['student_image']; ?>" height="50" width="50" class="user-image" alt="No Image"></td>
                                            <?php } else { ?>
                                                <td><img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="50" width="50" class="user-image" alt="No Image"></td>
                                            <?php } ?>
                                            <td><?php echo $user_row['sch_admission_id']; ?></td>
                                            <td><?php echo ucfirst($user_row['student_name']); ?></td>
                                            <td><?php echo ucfirst($user_row['student_father_name']); ?></td>
                                            <td><?php echo $user_row['class_name']; ?></td>
                                            <td><?php echo $user_row['section_name']; ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'admin/view_student/' . $user_row['sch_admission_id'] ?>"><i class="fa fa-eye"></i> View</a>&nbsp;&nbsp;&nbsp;
                                                <a href="<?php echo base_url() . 'admin/edit_student/' . $user_row['sch_admission_id'] ?>"><i class="fa fa-edit"></i> Edit</a>&nbsp;&nbsp;&nbsp;
                                                <a href="<?php echo base_url() . 'admin/delete_student/' . $user_row['sch_admission_id'] ?>" onclick="return confirm('Are you sure you want to delete this ?');"><i class="fa fa-remove"></i> Delete</a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <?php if ($students) { ?>
                        <div style="padding:10px;"><button class="btn btn-md btn-primary" id="delete_all">Delete All</button></div>
                    <?php } ?>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetSectionsByClass",
            data: {class_id: '<?php echo $_GET['class_id']; ?>'},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_section_id').html(data);
                            $('#student_section_id').val(<?php echo $_GET['section_id']; ?>);
                        } else {
                            $('#student_section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
    });
    //alert($('#category_id').val());


    function toGetStudents() {
        var class_id = $('#student_class_id').val();
        if (window.location.href.indexOf("?") > -1) {
            var url = '<?php echo base_url() ?>' + 'admin/manage_students?class_id=' + class_id + '&section_id=';
        } else {
            var url = document.location.href + "?class_id=" + class_id + '&section_id=';
        }
        document.location = url;
    }

    function toExportStudentsData() {

        var class_id = "<?php echo $_GET['class_id']; ?>";
        var section_id = "<?php echo $_GET['section_id']; ?>";
        var url = '<?php echo base_url() ?>' + 'admin/export_students_data?class_id=' + class_id + '&section_id=' + section_id;
        document.location = url;
    }

    function toGetStudentsBySections() {
        var class_id = $('#student_class_id').val();
        var section_id = $('#student_section_id').val();
        if (window.location.href.indexOf("?") > -1) {
            var url = '<?php echo base_url() ?>' + 'admin/manage_students?class_id=' + class_id + '&section_id=' + section_id;
        } else {
            var url = document.location.href + "?class_id=" + class_id + '&section_id=' + section_id;
        }
        document.location = url;
    }

    $("#select_all").change(function () {  //"select all" change
        $(".checkbox").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
    });

//".checkbox" change
    $('.checkbox').change(function () {
        //uncheck "select all", if one of the listed checkbox item is unchecked
        if (false == $(this).prop("checked")) { //if this item is unchecked
            $("#select_all").prop('checked', false); //change "select all" checked status to false
        }
        //check "select all" if all checkbox items are checked
        if ($('.checkbox:checked').length == $('.checkbox').length) {
            $("#select_all").prop('checked', true);
        }
    });

    $('#delete_all').on('click', function (e) {
        var allVals = [];
        $(".checkbox:checked").each(function () {
            allVals.push($(this).attr('data-id'));
        });
        if (allVals.length <= 0)
        {
            alert("Please select at least one to delete.");
        } else {
            var y = "Are you sure you want to delete this row?";
            var check = confirm(y);
            if (check === true) {
                //for server side
                var join_selected_values = allVals.join(",");
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url() ?>admin/delete_multiple_students",
                    cache: false,
                    data: 'ids=' + join_selected_values,
                    success: function (response)
                    {
                        console.log(response);
                        location.reload();
                        //referesh table
                    }
                });
            }
        }
    });
</script>