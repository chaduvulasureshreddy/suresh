<!-- Content Wrapper. Contains page content -->
<style>
    label.error,.errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            View Student
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'admin/manage_students?class_id=&section_id=' ?>">Manage Students</a></li>
            <li class="active">View Student</li>
        </ol>
    </section>
    <?php // echo '<pre>';print_r($studentInfo);?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-11">

            </div>
            <div>
                <div class="col-md-8 col-xs-offset-2">
                    <ul class=" list-unstyled list-inline">
                        <li>
                            <a href="<?php echo base_url() . 'admin/manage_students?class_id=&section_id=' ?>" class="btn btn-sm btn-primary" style="float:left">
                                <i class="fa fa-arrow-left"></i> Back
                            </a>
                        </li>
                        <li class=" pull-right">
                            <button class="btn btn-sm btn-primary" style="float:left" onclick="toDownloadPdf()">
                                <i class="fa fa-download"></i> Download Student Info
                            </button>
                        </li>
                    </ul>
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- /.box-header -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h4><b>Student Profile Information:</b></h4>
                                </div>
                                <div class="col-sm-3">
                                    <div id="old_img">
                                        <div class="form-group">
                                            <?php if (!empty($studentInfo['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $studentInfo['student_image'])) { ?>
                                                <img src="<?php echo base_url() . 'uploads/profile_pics/' . $studentInfo['student_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                                            <?php } else { ?>
                                                <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                                            <?php } ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <input type="hidden" id="student_admission_id" value="<?php echo $studentInfo['sch_admission_id']; ?>" name="student_admission_id">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_admission_id">Admission Number:</label>
                                        <?php echo ucfirst($studentInfo['sch_admission_id']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_name">Student Name:</label>
                                        <?php echo ucfirst($studentInfo['student_name']); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="class_name">Father Name:</label>
                                        <?php echo ucfirst($studentInfo['student_father_name']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="section_name">Mother Name:</label>
                                        <?php echo ucfirst($studentInfo['student_mother_name']); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="class_name">Gender:</label>
                                        <?php
                                        if ($studentInfo['student_gender'] == 'M')
                                            echo ucfirst('boy');
                                        else
                                            echo ucfirst('girl');
                                        ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="section_name">Date of Birth:</label>
                                        <?php
                                        if (!empty($studentInfo['student_dob']) && $studentInfo['student_dob'] != "0000-00-00") {
                                            echo date('dS-F-Y', strtotime($studentInfo['student_dob']));
                                        } else {
                                            echo "--";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="class_name">Class Name:</label>
                                        <?php echo ucfirst($studentInfo['class_name']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="section_name">Section Name:</label>
                                        <?php echo ucfirst($studentInfo['section_name']); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="class_name">Contact Number:</label>
                                        <?php echo $studentInfo['student_mobile']; ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="section_name">Blood Group:</label>
                                        <?php
                                        if ($studentInfo['student_blood_group']) {
                                            echo ucfirst($studentInfo['student_blood_group']);
                                        } else {
                                            echo 'N/A';
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_caste">Caste:</label>
                                        <?php
                                        if ($studentInfo['student_caste']) {
                                            echo ucfirst($studentInfo['student_caste']);
                                        } else {
                                            echo 'N/A';
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_fee_amount">Fee Amount:</label>
                                        <?php echo 'Rs: ' . $studentInfo['student_fee'] . '/-'; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_fee_amount">Books Amount:</label>
                                        <?php echo 'Rs: ' . $studentInfo['books_fee'] . '/-'; ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_fee_amount">Bus Amount:</label>
                                        <?php echo 'Rs: ' . $studentInfo['bus_fee'] . '/-'; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_caste">Joining Date:</label>
                                        <?php
                                        if (!empty($studentInfo['student_joining_date']) && $studentInfo['student_joining_date'] != "0000-00-00") {
                                            echo date('dS-F-Y', strtotime($studentInfo['student_joining_date']));
                                        } else {
                                            echo "--";
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_fee_amount">Joining Class:</label>
                                        <?php echo $studentInfo['student_joined_class']; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_address">Submitted Documents at joining time:</label>
                                        <?php echo ucfirst($studentInfo['student_documents']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_address">Address:</label>
                                        <?php echo ucfirst($studentInfo['student_address']); ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--</div>-->
                        <!--</div>-->
                    </div>
                    <!--/.col (left) -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>
    function toDownloadPdf() {
        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'admin/toDownloadAsPdf?student_admission_id=' + student_id;
        document.location = url;
    }
</script>