<!-- Content Wrapper. Contains page content -->
<style>
    label.error, .errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Students CSV Uploading
            <small>Add Students</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Add Students</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <?php
            if ($this->session->flashdata('alert')) {
                $alert = $this->session->flashdata('alert');
                ?>
                <div class="alert <?php
                if ($alert['type']) {
                    echo 'alert-' . $alert['type'];
                }
                ?> alert-dismissible" id="successMessage">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    <?php
                    if ($alert['message']) {
                        echo $alert['message'];
                    }
                    ?>
                </div>
            <?php } ?>
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <h4 id="qwerty">Images</h4>
                <!-- general form elements -->
                <div class="box box-primary">
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="studentImagesForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="first_name">Student Images:<span class="text-danger">*</span></label>
                                <input type="file" class="" name="studentImages[]" id="studentImages" accept="image/*" multiple required>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="class_save">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->

        <div class="row">

            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <h4>CSV Uploading</h4>
                <!-- general form elements -->
                <div class="box box-primary">
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="studentCSVForm" action="<?php echo base_url() . 'admin/toImportStudentsData'; ?>" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="first_name">Students Data:<span class="text-danger">*</span></label>
                                <input type="file" class="" name="file" id="file" required>
                            </div>
                        </div>
                        <!-- /.box-body -->
                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="class_save">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
    $("#studentImagesForm").validate({
        rules: {
            "studentImages[]": "required"
        },
        messages: {
            "studentImages[]": "Please select at least one image"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    $("#studentCSVForm").validate({
        rules: {
            "file": "required"
        },
        messages: {
            "file": "Please select csv file to upload students data"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });

    function toCheckClassName() {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Classdata/toCheckClassName",
            data: {class_name: $('#class_name').val(), class_id: ''},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#class_exist_message').html('Class already exist with this name');
                            $('#class_save').prop('disabled', true);
                        } else {
                            $('#class_exist_message').html('');
                            $('#class_save').prop('disabled', false);
                        }
                    }
        });
    }
</script>