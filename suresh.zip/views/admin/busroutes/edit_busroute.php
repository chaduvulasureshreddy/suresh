<!-- Content Wrapper. Contains page content -->

<style>
    #dvPreview
    {
        filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(sizingMethod=image);
        height: 200px;
        width: 200px;
        display: none;
    }
    label.error, .errormessage {
        color: red;
    }
</style>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Bus Routes
            <small>Edit Busroute</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Edit BusRoute</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <!--            <div class="box-header with-border">
                                  <h3 class="box-title">Quick Example</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="" id="routeForm" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="route_no">Route Number:<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="route_no" onkeyup="toChkBusRoute()" id="route_no" value="<?php echo $busroute_details['route_no']; ?>" placeholder="Route Number" required>
                                        <input type="hidden" class="form-control" name="id" id="id" value="<?php echo $busroute_details['id']; ?>" required>
                                        <span class="errormessage" id="busroute_exist_message"></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="mobile_number">Status:<span class="text-danger">*</span></label>
                                        <select name="status" class="form-control" id="status" required>
                                            <option value="">Select Status</option>
                                            <option value="A" <?php
                                            if ($busroute_details['status'] == 'A') {
                                                echo "selected";
                                            }
                                            ?>>Active</option>
                                            <option value="I" <?php
                                            if ($busroute_details['status'] == 'I') {
                                                echo "selected";
                                            }
                                            ?>>In Active</option>
                                        </select>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="pno">Covering Areas:<span class="text-danger">*</span></label>
                                        <textarea name="route_name" id="route_name" class="form-control" placeholder="Coverig Area1, Covering Area2, Covering Area3" required><?php echo $busroute_details['route_name']; ?></textarea>
                                        <br><span class="text-info">Please enter covering Areas separate with commas(,)</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="busroute_save">Save</button>
                            <span class="pull-right">Note: <span class="text-danger">*</span> fields are mandatory</span>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>

    function toChkBusRoute() {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Busroute/toCheckBusRoute",
            data: {route_no: $('#route_no').val(), id: $('#id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#busroute_exist_message').html('Busroute already exist with this number');
                            $('#busroute_save').prop('disabled', true);
                        } else {
                            $('#busroute_exist_message').html('');
                            $('#busroute_save').prop('disabled', false);
                        }
                    }
        });
    }

    $("#routeForm").validate({
        rules: {
            route_no: "required",
            route_name: "required",
            status: "required"
        },
        messages: {
            route_no: "Please enter route number",
            route_name: "Please enter covering areas",
            status: "Please select status"

        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
</script>