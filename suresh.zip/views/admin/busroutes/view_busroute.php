<!-- Content Wrapper. Contains page content -->
<style>
    label.error,.errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            View Busroute
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'busroute/manage_busroutes' ?>">Manage Busroutes</a></li>
            <li class="active">View Driver</li>
        </ol>
    </section>
    <?php // echo '<pre>';print_r($busRouteInfo);?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-11">

            </div>
            <div>
                <div class="col-md-8 col-xs-offset-2">
                    <ul class=" list-unstyled list-inline">
                        <li>
                            <a href="<?php echo base_url() . 'busroute/manage_busroutes' ?>" class="btn btn-sm btn-primary" style="float:left">
                                <i class="fa fa-arrow-left"></i> Back
                            </a>
                        </li>
                    </ul>
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- /.box-header -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <h4><b>Bus Route Information:</b></h4>
                                </div>
                            </div>
                            <div class="row">
                                <input type="hidden" id="id" value="<?php echo $busRouteInfo['id']; ?>" name="id">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_name">Route Number:</label>
                                        <?php echo ucfirst($busRouteInfo['route_no']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="id">Status:</label>
                                        <?php
                                        if ($busRouteInfo['status'] == 'A') {
                                            echo "Active";
                                        }else{
                                            echo "Inactive";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-sm-12">
                                    <div class="form-group">
                                        <label for="class_name">Covering Areas:</label>
<?php echo $busRouteInfo['route_name']; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--</div>-->
                        <!--</div>-->
                    </div>
                    <!--/.col (left) -->
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>
    function toDownloadPdf() {
        var driver_id = $('#id').val();
        var url = '<?php echo base_url() ?>' + 'driver/toDownloadAsPdf?id=' + driver_id;
        document.location = url;
    }
</script>