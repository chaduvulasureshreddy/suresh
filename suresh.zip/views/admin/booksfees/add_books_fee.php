<!-- Content Wrapper. Contains page content -->
<style>
    label.error {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Books Fee
            <small>Books Fee Management</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Books Fee Management</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="booksfeeForm" action="<?php echo base_url() . 'booksfees/getStudentbookFeeInfo'; ?>" method="GET" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="student_class">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" onchange="toGetSectionsByClass();" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            echo '<option value="' . $cls['id'] . '">' . $cls['class_name'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_section">Section:<span class="text-danger">*</span></label>
                                <select class="form-control" name="section_id" id="section_id" onchange="toGetStudentsByClassSection();" required>
                                    <option value="">Select</option>
                                </select>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer" style="text-align:center">
                            <button type="submit" class="btn btn-primary">Get Students Books Fee Data</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>
<script>
    function toGetSectionsByClass() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetSectionsByClass",
            data: {class_id: $('#class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#section_id').html(data);
                        } else {
                            $('#section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
        return false;
    }

    function toGetStudentsByClassSection() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetStudentsByClassSection",
            data: {class_id: $('#class_id').val(), section_id: $('#section_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_admission_id').html(data);
                        } else {
                            $('#student_admission_id').html('<option value="">No Students available to select</option>');
                        }
                    }
        });
        return false;
    }
    $("#booksfeeForm").validate({
        rules: {
            class_id: "required",
            section_id: "required"
        },
        messages: {
            class_id: "please select class name",
            section_id: "Please select section name"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
</script>