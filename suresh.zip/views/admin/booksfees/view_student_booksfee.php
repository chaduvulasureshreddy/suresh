<!-- Content Wrapper. Contains page content -->
<style>
    label.error,.errormessage {
        color: red;
    }
    .balance_amount_fee{
        color: red;
        background: yellow;
        font-weight: 700;
        font-size: 18px;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Book Fee Details
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Book Fee Details</li>
        </ol>
    </section>
    <?php // echo '<pre>';print_r($feeInfo);?>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-md-11">
                <ul class=" list-unstyled list-inline">
                    <li>
                        <h4>Student Fee Information:</h4>
                    </li>
                    <li class=" pull-right">
                        <button class="btn btn-sm btn-primary" onclick="toDownloadStudentFee()" style="float:left">
                            <i class="fa fa-download"></i> Download BooksFee Info
                        </button>
                    </li>
                </ul>
            </div>
            <div>
                <div class="col-md-7">
                    <!-- general form elements -->
                    <div class="box box-primary">
                        <!-- /.box-header -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="student_admission_id">Student Admission Number:</label>
                                        <?php echo ucfirst($feeInfo['student_admission_id']); ?>
                                    </div>
                                </div>
                                <input type="hidden" name="student_admission_id" id="student_admission_id" value="<?php echo $feeInfo['student_admission_id']; ?>"/>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="class_name">Class:</label>
                                        <?php echo ucfirst($feeInfo['class_name']); ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="section_name">Section:</label>
                                        <?php echo ucfirst($feeInfo['section_name']); ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="total_amount">Total Amount:</label>
                                        <?php echo 'Rs: ' . $feeInfo['total_books_amount'] . '/-'; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="paid_amount">Paid Amount:</label>
                                        <?php echo 'Rs: ' . $feeInfo['paid_books_amount'] . '/-'; ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="balance_amount">Balance Amount:</label>
                                        <span class="balance_amount_fee"><?php echo 'Rs: ' . $feeInfo['balance_books_amount'] . '/-'; ?></span>
                                    </div>
                                </div>
                            </div>
                            <div class="row">

                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="concession_amount">Concession Amount: </label>
                                        <?php
                                        if ($feeInfo['concession_books_amount']) {
                                            echo 'Rs: ' . $feeInfo['concession_books_amount'] . '/-';
                                        } else {
                                            echo "N/A";
                                        }
                                        ?>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label for="balance_amount">Last Day for Next Payment: </label>
                                        <?php
                                        if ($feeInfo['last_date_to_pay_books'] && $feeInfo['last_date_to_pay_books'] !== '0000-00-00') {
                                            echo $feeInfo['last_date_to_pay_books'];
                                        } else {
                                            echo " N/A";
                                        }
                                        ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--</div>-->
                        <!--</div>-->
                    </div>
                    <!--/.col (left) -->
                </div>
                <div class="col-md-4">
                    <div class="box box-primary">
                        <!-- /.box-header -->
                        <div class="panel-body">
                            <div class="row">
                                <div class="col-sm-12">
                                    <div id="old_img">
                                        <div class="form-group">
                                            <label for="balance_amount">Student Image: </label>
                                            <?php if (!empty($feeInfo['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $feeInfo['student_image'])) { ?>
                                                <img src="<?php echo base_url() . 'uploads/profile_pics/' . $feeInfo['student_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                                            <?php } else { ?>
                                                <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                                            <?php } ?>
                                        </div>
                                        <div class="form-group">
                                            <label for="student_name">Student Name:</label>
                                            <b>&nbsp;&nbsp;&nbsp;<?php echo ucfirst($feeInfo['student_name']); ?></b>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-sm-6">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-11">
                <h4>Previous Books paid Fee Information:</h4>
                <div class="box box-primary">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>Id</th>
                                <th>Admission Number</th>
                                <th>Student Name</th>
                                <th>Receipt Number</th>
                                <th>Fee Type</th>
                                <th>Paid Amount</th>
                                <th>Paid Date</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            if ($previousfeeInfo) {
                                foreach ($previousfeeInfo as $k => $pr_row) {
                                    ?>
                                    <tr>
                                        <td><?php echo ++$k; ?></td>
                                        <td><?php echo ucfirst($pr_row['student_admission_id']); ?></td>
                                        <td><?php echo ucfirst($feeInfo['student_name']); ?></td>
                                        <td><?php echo ucfirst($pr_row['booksfee_receipt_no']); ?></td>
                                        <td><?php echo ucfirst($pr_row['fee_type']); ?></td>
                                        <td><?php echo 'Rs: ' . $pr_row['paid_books_amount'] . ' /-'; ?></td>
                                        <td><?php echo date('dS-F-Y', strtotime($pr_row['paid_date'])); ?></td>
                                    </tr>
                                    <?php
                                }
                            } else {
                                ?>
                                <tr><td colspan="6" style="text-align:center"><b>No Data Found</b></td></tr>
                            <?php }
                            ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>
<script>
    function toDownloadStudentFee() {
        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'booksfees/downloadStudentFeeInfo?student_admission_id=' + student_id;
        document.location = url;
    }
</script>