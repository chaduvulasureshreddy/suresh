<!-- Content Wrapper. Contains page content -->
<style>
    label.error,.errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Books Fee Form
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Books Fee Form</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <?php
        if ($this->session->flashdata('alert')) {
            $alert = $this->session->flashdata('alert');
            ?>
            <div class="alert <?php
            if ($alert['type']) {
                echo 'alert-' . $alert['type'];
            }
            ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <?php
                if ($alert['message']) {
                    echo $alert['message'];
                }
                ?>
            </div>
        <?php } ?>
        <div class="row"><!-- col-xs-offset-3 -->
            <div class="col-md-6 col-xs-offset-3">
                <h4>Books Fee payment:</h4>
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" id="booksfeeForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="balance_fee">Student Admission Number:</label>
                                <input type="text" class="form-control"  name="student_admission_number" placeholder="Student Admission Number" value="<?php echo $feeInfo['student_admission_id']; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Student Name:</label>
                                <input type="text" class="form-control" id="student_name" name="student_name" placeholder="Student Name" value="<?php echo $feeInfo['student_name']; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Receipt Number:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="booksfee_receipt_no" name="booksfee_receipt_no" placeholder="Fee Receipt Number" value="">
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Fee Date:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="datepicker" name="paid_date" placeholder="Please Select Fee Date" readonly>
                            </div>
                            <div class="form-group">
                                <label for="about">Fee Type:<span class="text-danger">*</span></label>
                                <select class="form-control" name="fee_type" id="fee_type">
                                    <option value="">Select Fee Type</option>
                                    <option value="TotalAmount">Total Amount</option>
                                    <option value="Term1">Term1</option>
                                    <option value="Term2">Term2</option>
                                    <option value="Term3">Term3</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Balance Fee Amount:</label>
                                <input type="text" class="form-control" name="balance_books_amount" value="<?php echo $feeInfo['balance_books_amount']; ?>" id="balance_books_amount" placeholder="Balance Books Fee" readonly>
                            </div>
                            <div class="form-group">
                                <label for="paid_fee">Concession Amount:</label>
                                <input type="text" class="form-control" name="concession_books_amount" id="concession_books_amount" value="0" placeholder="Concession amount if any">
                            </div>
                            <div class="form-group">
                                <label for="paid_fee">Paying Fee Amount:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="paid_books_amount" id="paid_books_amount" value="0" placeholder="Paying Books Fee Amount" required>
                            </div>
                            <div class="form-group">
                                <label for="last_date_to_pay">Last Date to pay balance book fee amount (if any):</label>
                                <input type="text" class="form-control" id="datepicker1" name="last_date_to_pay_books" placeholder="Please Select Last Date to pay balance fee amount (if any)" readonly>
                            </div>
                            <input type="hidden" class="form-control" name="class_id" id="class_id" value="<?php echo $feeInfo['class_id']; ?>">
                            <input type="hidden" class="form-control" name="section_id" id="section_id" value="<?php echo $feeInfo['section_id']; ?>">
                            <input type="hidden" class="form-control" name="student_admission_id" id="student_admission_id" value="<?php echo $feeInfo['student_admission_id']; ?>">
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary" id="fee_save_button">Submit</button>
                                <span id="err-msg" class="errormessage"></span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->

</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>
<script>
    $("#booksfeeForm").validate({
        rules: {
            paid_books_amount: "required",
            paid_date: "required",
            booksfee_receipt_no: "required",
            fee_type: "required"

        },
        messages: {
            paid_books_amount: "Please enter fee amount",
            fee_type: "Please select fee type",
            paid_date: "Please select fee date",
            booksfee_receipt_no: "Please enter fee receipt number"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    $(function () {
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, maxDate: 0});
    });
    $(function () {
        $("#datepicker1").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true});
    });
    $(document).ready(function () {
        console.log(<?php echo $feeInfo['balance_books_amount'] ?>);
        var balance = "<?php echo $feeInfo['balance_books_amount'] ?>";
        if (balance === '0') {
            $('#fee_save_button').prop('disabled', true);
            $('#err-msg').html('Total Books Fee Already Paid');
        } else {
            $('#fee_save_button').prop('disabled', false);
            $('#err-msg').html('');
        }
    });
</script>