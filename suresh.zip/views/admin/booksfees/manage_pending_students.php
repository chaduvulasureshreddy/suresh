<!-- Content Wrapper. Contains page content -->
<style>
    .dataTables_empty{
        text-align: center;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            BooksFee
            <small>BooksFee Management</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Students Info</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div style="padding:10px;">
                        <div class="col-sm-8">
                            <div class="form-group">
                                <!--<label>To Export Classes By CSV:</label>-->
                            </div>
                        </div>
                        <?php if ($students) { ?>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <button class="btn btn-md btn-primary" onclick="toExportPendingFeesData()">
                                        <i class="fa fa-download"></i> Export Pending Fee Amounts By Class
                                    </button>
                                </div>
                            </div>
                        <?php } ?>
                    </div>
                    <div class="box-body">
                        <table class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Admission No.</th>
                                    <th>Name</th>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Total Amt</th>
                                    <th>Paid Amt</th>
                                    <th>Bal. Amt</th>
                                    <th>Cons Amt</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
//                                echo '<pre>';
//                                print_r($students);
//                                exit;
                                if ($students) {
                                    foreach ($students as $k => $student_row) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$k; ?></td>
                                            <td><?php echo ucfirst($student_row['student_admission_id']); ?></td>
                                            <td><?php echo ucfirst($student_row['student_name']); ?></td>
                                            <td><?php echo ucfirst($student_row['class_name']); ?></td>
                                            <td><?php echo ucfirst($student_row['section_name']); ?></td>
                                            <td><?php
                                                if ($student_row['total_books_amount']) {
                                                    echo 'Rs: ' . $student_row['total_books_amount'] . ' /-';
                                                } else {
                                                    echo "--";
                                                }
                                                ?></td>
                                            <td><?php
                                                if ($student_row['paid_books_amount']) {
                                                    echo 'Rs: ' . $student_row['paid_books_amount'] . ' /-';
                                                } else {
                                                    echo "--";
                                                }
                                                ?></td>
                                            <td><?php
                                                if ($student_row['balance_books_amount']) {
                                                    echo 'Rs: ' . $student_row['balance_books_amount'] . ' /-';
                                                } else {
                                                    echo "--";
                                                }
                                                ?></td>
                                            <td><?php
                                                if ($student_row['concession_books_amount']) {
                                                    echo 'Rs: ' . $student_row['concession_books_amount'] . ' /-';
                                                } else {
                                                    echo "--";
                                                }
                                                ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'booksfees/getStudentBooksFeeInfo/' . $student_row['student_admission_id']; ?>"><i class="fa fa-plus"></i> Pay Fee</a>&nbsp;
                                                <a href="<?php echo base_url() . 'booksfees/viewStudentBooksFeeInfo/' . $student_row['student_admission_id']; ?>"><i class="fa fa-eye"></i> View Fee</a>&nbsp;
                                                <a href="javascript:void(0);" onclick="toDownloadFeeInfo('<?php echo $student_row['student_admission_id']; ?>')"><i class="fa fa-download"></i> Download Fee</a>&nbsp;
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                } else {
                                    ?>
                                    <tr><td colspan="10" style="text-align:center"><b>No Students Data Found</b></td></tr>
                                <?php }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>
    function toExportPendingFeesData() {
        var class_id = "<?php echo $_GET['class_id']; ?>";
        var section_id = "<?php echo $_GET['section_id']; ?>";
        var url = '<?php echo base_url() ?>' + 'booksfees/exportPendingfeesdataByClass?class_id=' + class_id + '&section_id=' + section_id + '&pending=1';
        document.location = url;
    }
    function toDownloadFeeInfo(student_id) {
        var url = '<?php echo base_url() ?>' + 'booksfees/downloadStudentFeeInfo?student_admission_id=' + student_id;
        document.location = url;
    }
</script>