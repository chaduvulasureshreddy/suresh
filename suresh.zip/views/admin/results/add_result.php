<!-- Content Wrapper. Contains page content -->
<style>
    label.error {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Results
            <small>Add Exam Result</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Add Exam Result</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="homeworkForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="class">Exam Type:<span class="text-danger">*</span></label>
                                <select class="form-control" name="exam_type_id" id="exam_type_id" required>
                                    <option value="">Select exam type</option>
                                    <?php
                                    if ($exams) {
                                        foreach ($exams as $exam) {
                                            echo '<option value="' . $exam['id'] . '">' . $exam['exam_name'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email">Exam Date:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="exam_date" id="datepicker" value="" placeholder="Please Select  Exam date" readonly required>
                            </div>
                            <div class="form-group">
                                <label for="class">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" onchange="toGetSectionsByClass()" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            echo '<option value="' . $cls['id'] . '">' . $cls['class_name'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_class">Section:<span class="text-danger">*</span></label>
                                <select class="form-control" name="section_id" id="section_id" required>
                                    <option value="">Select Section</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_class">Subjects:<span class="text-danger">*</span></label>
                                <select class="form-control" name="subject_id" id="subject_id" required>
                                    <option value="">Select Subject</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="email">Exam Code:</label>
                                <input type="text" class="form-control" name="common_id" id="common_id" onchange="toCheckCommanId()" placeholder="Examination Code">
                            </div>
                            <!--                            <div class="form-group">
                                                            <label for="home_work_name">Notes:<span class="text-danger">*</span></label>
                                                            <textarea class="form-control" id="notes" name="notes" style="height:200px" required></textarea>
                                                        </div>-->
                            <div class="box-body">
                                <div class="form-group">
                                    <label for="csv">Exams Data:<span class="text-danger">*</span></label>
                                    <input type="file" class="" name="file" id="file" required>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Add Results</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>
<script>
    $(function () {
        var currentTime = new Date();
        var startDateTo = new Date(currentTime.getFullYear(), currentTime.getMonth() + 2, 0);
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, maxDate: startDateTo, minDate: 0});
    });
    function toGetSectionsByClass() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Homework/toGetSectionsByClass",
            data: {class_id: $('#class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#section_id').html(data);
                        } else {
                            $('#section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Homework/toGetSubjectsByClass",
            data: {class_id: $('#class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#subject_id').html(data);
                        } else {
                            $('#subject_id').html('<option value="">No subject available to select</option>');
                        }
                    }
        });
        return false;
    }
    $("#homeworkForm").validate({
        rules: {
            class_id: "required",
            section_id: "required",
            home_work_date: "required",
            home_work_name: "required"
        },
        messages: {
            class_id: "please select class name",
            section_id: "Please select section name",
            home_work_date: "Please select home work date",
            home_work_name: "please enter home work data"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
</script>