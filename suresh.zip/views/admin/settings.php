<!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        Settings
        <!--<small>Change Password</small>-->
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Settings</a></li>
        <!--<li class="active">Change Password</li>-->
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="row">
        <!-- left column -->
        <div class="col-md-6 col-xs-offset-3">
          <!-- general form elements -->
          <div class="box box-primary">
<!--            <div class="box-header with-border">
              <h3 class="box-title">Quick Example</h3>
            </div>-->
            <?php
                if($this->session->flashdata('alert')){
                    $alert = $this->session->flashdata('alert');
            ?>
                <div class="alert <?php if($alert['type']){ echo 'alert-'.$alert['type']; } ?> alert-dismissible">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                    <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                    <?php if($alert['message']){ echo $alert['message']; } ?>
                </div>
            <?php } ?>
            <!-- /.box-header -->
            <!-- form start -->
            <form role="form" action="" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label for="password">Comission</label>
                  <input type="number" step="0.01" class="form-control" name="comission" id="comission" value="<?php echo $settings_list[0]['value']; ?>" placeholder="Comission" required>
                </div>
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
          <!-- /.box -->

        </div>
        <!--/.col (left) -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>