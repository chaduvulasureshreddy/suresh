<!-- Content Wrapper. Contains page content -->
<style>
    label.error, .errormessage {
        color: red;
    }
    .btn-group, .btn-group-vertical {
        display: inline-block;
        position: relative;
        vertical-align: middle;
        width: 100%;
    }
    .open > .dropdown-menu {
        display: block;
        width: 100%;
    }
.multiselect-container.dropdown-menu {
  max-height: 200px;
  overflow: auto;
}

</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Remark
            <small>Add Remark</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Add Remark</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="remarkForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="email">Remark Date:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="remark_date" id="datepicker" value="" placeholder="Please Select  Remark date" readonly required>
                            </div>
                            <div class="form-group">
                                <label for="class">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" onchange="toGetSectionsByClass();" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            echo '<option value="' . $cls['id'] . '">' . $cls['class_name'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_section">Section:<span class="text-danger">*</span></label>
                                <select class="form-control" name="section_id" id="section_id" onchange="toGetStudentsByClassSection();" required>
                                    <option value="">Select Section</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="class">Students:<span class="text-danger">*</span></label>
                                <br>
                                <select class="form-control" name="student_admission_id[]" id="student_admission_id" required multiple>
                                </select>
                                <br>
                                <!--<span class="text-aqua"> Press ctrl to select multiple students</span><br>-->
                                <span class="errormessage" id="studenterrormessage"></span>
                            </div>
                            <div class="form-group">
                                <label for="remark_name">Remark:<span class="text-danger">*</span></label>
                                <textarea class="form-control" id="home_work_name" name="remark_name" style="height:120px" required></textarea>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="save-remark">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>
<script>
    $(function () {
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, maxDate: 0});
    });
    function toGetSectionsByClass() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Homework/toGetSectionsByClass",
            data: {class_id: $('#class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#section_id').html(data);
                        } else {
                            $('#section_id').html('<option value="">No section available to select</option>');
                        }
                        $('#student_admission_id').html('');
                    }
        });
        return false;
    }

    function toGetStudentsByClassSection() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetStudentsByClassSection",
            data: {class_id: $('#class_id').val(), section_id: $('#section_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_admission_id').html(data);
                            $('#student_admission_id').multiselect('rebuild');
                            $('#student_admission_id').multiselect({
                                includeSelectAllOption: true
                            });
                            $('#save-remark').prop('disabled', false);
                            $('#studenterrormessage').html('');
                        } else {
                            $('#student_admission_id').html();
                            $('#studenterrormessage').html('No Students available to select!.. Please try with another class');
                            $('#save-remark').prop('disabled', true);
                        }
                    }
        });
        return false;
    }
    $("#remarkForm").validate({
        rules: {
            class_id: "required",
            section_id: "required",
            remark_date: "required",
            remark_name: "required",
            student_admission_id: "required"
        },
        messages: {
            class_id: "please select class name",
            section_id: "Please select section name",
            remark_date: "Please select remark date",
            remark_name: "please enter remark data",
            student_admission_id: "Please select at least one student"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    $(document).ready(function () {
        $('#student_admission_id').multiselect();
    });
    $("#save-remark").click(function () {
        var student_ids = $('#student_admission_id').val();
        if (student_ids === null || student_ids === '') {
            $('#studenterrormessage').html('Please select at least one student');
            return;
        } else {
            $('#studenterrormessage').html('');
        }
    });
</script>
