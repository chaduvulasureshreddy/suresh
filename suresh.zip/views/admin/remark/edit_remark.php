<!-- Content Wrapper. Contains page content -->
<style>
    label.error {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Remark
            <small>Edit Remark</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'remark/manage_remarks?date=&class_id=&section_id=' ?>">Manage Remarks</a></li>
            <li class="active">Add Remark</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="remarkForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="email">Remark Date:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="remark_date" id="datepicker" value="<?php echo $remarks['remark_date']; ?>" placeholder="Please Select  Remark date" readonly required>
                            </div>
                            <div class="form-group">
                                <label for="class">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" onchange="toGetSectionsByClass();" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) :
                                            ?>
                                            <option value="<?php echo $cls['id']; ?>" <?php if ($remarks['class_id'] === $cls['id']) {
                                        echo "selected";
                                    } ?>><?php echo $cls['class_name']; ?></option>
    <?php endforeach;
} ?>

                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_section">Section:<span class="text-danger">*</span></label>
                                <select class="form-control" name="section_id" id="section_id" onchange="toGetStudentsByClassSection();" required>
                                    <option value="">Select</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="class">Students:<span class="text-danger">*</span></label>
                                <select class="form-control" name="student_admission_id" id="student_admission_id" required>
                                    <option value="">Select Student</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="remark_name">Remark:<span class="text-danger">*</span></label>
                                <textarea class="form-control" id="home_work_name" name="remark_name" style="height:120px" required><?php echo $remarks['remark_name']; ?></textarea>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetSectionsByClass",
            data: {class_id: "<?php echo $remarks['class_id']; ?>"},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#section_id').html(data);
                            $("#section_id").val("<?php echo $remarks['section_id']; ?>");
                        } else {

                            $('#section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetStudentsByClassSection",
            data: {class_id: "<?php echo $remarks['class_id']; ?>", section_id: "<?php echo $remarks['section_id']; ?>"},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_admission_id').html(data);
                            $('#student_admission_id').val("<?php echo $remarks['student_admission_id']; ?>");
                        } else {
                            $('#student_admission_id').html('<option value="">No Students available to select</option>');
                        }
                    }
        });
        return false;
    });
    $(function () {
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, maxDate: 0});
    });
    function toGetSectionsByClass() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Homework/toGetSectionsByClass",
            data: {class_id: $('#class_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#section_id').html(data);
                        } else {
                            $('#section_id').html('<option value="">No section available to select</option>');
                        }
                        $('#student_admission_id').html('<option value="">Select Student</option>');
                    }
        });
        return false;
    }

    function toGetStudentsByClassSection() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetStudentsByClassSection",
            data: {class_id: $('#class_id').val(), section_id: $('#section_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_admission_id').html(data);
                        } else {
                            $('#student_admission_id').html('<option value="">No Students available to select</option>');
                        }
                    }
        });
        return false;
    }
    $("#remarkForm").validate({
        rules: {
            class_id: "required",
            section_id: "required",
            remark_date: "required",
            remark_name: "required",
            student_admission_id: "required"
        },
        messages: {
            class_id: "please select class name",
            section_id: "Please select section name",
            remark_date: "Please select remark date",
            remark_name: "please enter remark data",
            student_admission_id: "Please select student"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
</script>
