<style>
    table {
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }

    th, td {
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even){background-color: #f2f2f2}
</style>
<!--<ul style=" list-style: none;">
    <li>
<?php //if (!empty($user_data['profile_pic'])) { ?>
                                <img src="<?php //echo $user_data['profile_pic']; ?>" height="30" width="30" class="user-image" alt="No Image">
<?php //} else { ?>
                                <img src="<?php //echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
<?php //} ?>
    </li>
    <li style="float: left;">
<?php //echo $user_data['institutename']; ?>
    </li>
</ul>
<hr>-->
<h4><u>Student Fee Information:</u></h4>
<table class="table table-bordered table-striped">
    <tbody>
        <tr>
            <td>
                <b>School Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($user_data['institutename']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Admission Number:</b>
            </td>
            <td>
                <b><?php echo ucfirst($feeInfo['student_admission_id']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($feeInfo['student_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Photo:</b>
            </td>
            <td>
                <?php if (!empty($feeInfo['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $feeInfo['student_image'])) { ?>
                    <img src="<?php echo base_url() . 'uploads/profile_pics/' . $feeInfo['student_image']; ?>" height="100" width="100" class="user-image" alt="No Image">
                <?php } else { ?>
                    <img src="<?php echo base_url() . 'uploads/noimage.jpg'; ?>"  height="100" width="100" class="user-image" alt="No Image">
                <?php } ?>
            </td>
        </tr>
        <tr>
            <td>
                <b>Class:</b>
            </td>
            <td>
                <b><?php echo ucfirst($feeInfo['class_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Section:</b>
            </td>
            <td>
                <b><?php echo ucfirst($feeInfo['section_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Total Amount:</b>
            </td>
            <td>
                <b><?php echo 'Rs: ' . $feeInfo['total_amount'] . '/-'; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Paid Amount:</b>
            </td>
            <td>
                <b><?php echo 'Rs: ' . $feeInfo['paid_amount'] . '/-'; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Balance Amount:</b>
            </td>
            <td>
                <b><?php echo 'Rs: ' . $feeInfo['balance_amount'] . '/-'; ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Concession Amount:</b>
            </td>
            <td>
                <b>
                    <?php
                    if ($feeInfo['concession_amount']) {
                        echo 'Rs: ' . $feeInfo['concession_amount'] . '/-';
                    } else {
                        echo "N/A";
                    }
                    ?>
                </b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Last Day for Next Payment:</b>
            </td>
            <td>
                <b><?php
                    if ($feeInfo['last_date_to_pay'] && $feeInfo['last_date_to_pay'] !== '0000-00-00') {
                        echo date('dS-F-Y', strtotime($feeInfo['last_date_to_pay']));
                    } else {
                        echo " N/A";
                    }
                    ?></b>
            </td>
        </tr>
    </tbody>
</table>
<h4><u>Previous paid Fee Information:</u></h4>
<table class="table table-bordered table-striped">
    <thead>
        <tr>
            <th>Id</th>
            <th>Admission Number</th>
            <th>Student Name</th>
            <th>Receipt Number</th>
            <th>Fee Type</th>
            <th>Paid Amount</th>
            <th>Paid Date</th>
        </tr>
    </thead>
    <tbody>
        <?php
        if ($previousfeeInfo) {
            foreach ($previousfeeInfo as $k => $pr_row) {
                ?>
                <tr>
                    <td><?php echo ++$k; ?></td>
                    <td><?php echo ucfirst($pr_row['student_admission_id']); ?></td>
                    <td><?php echo ucfirst($feeInfo['student_name']); ?></td>
                    <td><?php echo ucfirst($pr_row['fee_receipt_no']); ?></td>
                    <td><?php echo ucfirst($pr_row['fee_type']); ?></td>
                    <td><?php echo 'Rs: ' . $pr_row['term_paid_amt'] . ' /-'; ?></td>
                    <td><?php echo date('dS-F-Y', strtotime($pr_row['term_paid_date'])); ?></td>
                </tr>
                <?php
            }
        } else {
            ?>
            <tr><td colspan="6" style="text-align:center"><b>No Data Found</b></td></tr>
        <?php }
        ?>
    </tbody>
</table>
