<!-- Content Wrapper. Contains page content -->
<style>
    label.error,.errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Fee Form
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Fee Form</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <?php
        if ($this->session->flashdata('alert')) {
            $alert = $this->session->flashdata('alert');
            ?>
            <div class="alert <?php
            if ($alert['type']) {
                echo 'alert-' . $alert['type'];
            }
            ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <?php
                if ($alert['message']) {
                    echo $alert['message'];
                }
                ?>
            </div>
        <?php } ?>
        <div class="row"><!-- col-xs-offset-3 -->
            <div class="col-md-6 col-xs-offset-3">
                <h4>Fee payment:</h4>
                <div class="box box-primary">
                    <!-- form start -->
                    <form role="form" id="feeForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="balance_fee">Student Admission Number:</label>
                                <input type="text" class="form-control"  name="student_admission_number" placeholder="Student Admission Number" value="<?php echo $feeInfo['student_admission_id']; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Student Name:</label>
                                <input type="text" class="form-control" id="student_name" name="student_name" placeholder="Student Name" value="<?php echo $feeInfo['student_name']; ?>" readonly>
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Receipt Number:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="fee_receipt_no" name="fee_receipt_no" placeholder="Fee Receipt Number" value="">
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Fee Date:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" id="datepicker" name="term_paid_date" placeholder="Please Select Fee Date" readonly>
                            </div>
                            <div class="form-group">
                                <label for="about">Fee Type:<span class="text-danger">*</span></label>
                                <select class="form-control" name="fee_type" id="fee_type">
                                    <option value="">Select Fee Type</option>
                                    <option value="Quarterly">Quarterly</option>
                                    <option value="Half-yearly">Half-yearly</option>
                                    <option value="Annaully">Annually</option>
                                    <option value="Term1">Term1</option>
                                    <option value="Term2">Term2</option>
                                    <option value="Term3">Term3</option>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="balance_fee">Balance Fee Amount:</label>
                                <input type="text" class="form-control" name="balance_fee" value="<?php echo $feeInfo['balance_amount']; ?>" id="balance_fee" placeholder="Balance Fee" readonly>
                            </div>
                            <div class="form-group">
                                <label for="paid_fee">Concession Amount:</label>
                                <input type="text" class="form-control" name="concession_amount" id="concession_amount" value="0" placeholder="Concession amount if any">
                            </div>
                            <div class="form-group">
                                <label for="paid_fee">Paying Fee Amount:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="paid_fee" id="paid_fee" value="0" placeholder="Paying fee amount">
                            </div>
                            <div class="form-group">
                                <label for="last_date_to_pay">Last Date to pay balance fee amount (if any):</label>
                                <input type="text" class="form-control" id="datepicker1" name="last_date_to_pay" placeholder="Please Select Last Date to pay balance fee amount (if any)" readonly>
                            </div>
                            <input type="hidden" class="form-control" name="class_id" id="class_id" value="<?php echo $feeInfo['class_id']; ?>">
                            <input type="hidden" class="form-control" name="section_id" id="section_id" value="<?php echo $feeInfo['section_id']; ?>">
                            <input type="hidden" class="form-control" name="student_admission_id" id="student_admission_id" value="<?php echo $feeInfo['student_admission_id']; ?>">
                            <!-- /.box-body -->
                            <div class="box-footer">
                                <button type="submit" class="btn btn-primary" id="fee_save_button">Submit</button>
                                <span id="err-msg" class="errormessage"></span>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
    <!-- /.content -->

</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>
<script>
    $("#feeForm").validate({
        rules: {
            paid_fee: "required",
            fee_type: "required",
            term_paid_date: "required",
            fee_receipt_no: "required"

        },
        messages: {
            paid_fee: "Please enter fee amount",
            fee_type: "Please select fee type",
            term_paid_date: "Please select fee date",
            fee_receipt_no: "Please enter fee receipt number",
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    $(function () {
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, maxDate: 0});
    });
    $(function () {
        $("#datepicker1").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true});
    });
    $(document).ready(function () {
        console.log(<?php echo $feeInfo['balance_amount'] ?>);
        var balance = "<?php echo $feeInfo['balance_amount'] ?>";
        if (balance === '0') {
            $('#fee_save_button').prop('disabled', true);
            $('#err-msg').html('Total Fee Already Paid');
        } else {
            $('#fee_save_button').prop('disabled', false);
            $('#err-msg').html('');
        }
    });
</script>