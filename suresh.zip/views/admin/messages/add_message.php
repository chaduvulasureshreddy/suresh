<!-- Content Wrapper. Contains page content -->
<style>
    label.error, .errormessage {
        color: red;
    }
    .btn-group, .btn-group-vertical {
        display: inline-block;
        position: relative;
        vertical-align: middle;
        width: 100%;
    }
    .open > .dropdown-menu {
        display: block;
        width: 100%;
    }
.multiselect-container.dropdown-menu {
  max-height: 180px;
  overflow: auto;
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Message
            <small>Send Message</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Add Message</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="messageForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="message_date">Message Date:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="message_date" id="datepicker" value="" placeholder="Please select  message date" readonly required>
                            </div>
                            <!--                            <div class="form-group">
                                                            <label for="message_subject">Subject:<span class="text-danger">*</span></label>
                                                            <input type="text" class="form-control" name="message_subject" id="message_subject" value="" placeholder="Please enter subject" required>
                                                        </div>-->
                            <div class="form-group">
                                <label for="class">Class:</label>
                                <select class="form-control" name="class_id[]" id="class_id" multiple>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            echo '<option value="' . $cls['id'] . '">' . $cls['class_name'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="message">Message:<span class="text-danger">*</span></label>
                                <textarea class="form-control" id="message" name="message" style="height:120px" required></textarea>
                            </div>
                            <span class="text-info">
                                <b><div id="charNum">1000/1000 Characters</div></b>
                                <!--<b>Note: Every 160 characters, treated as one MESSAGE.</b>-->
                                <b>Note: Every 160 Characters of message treated as a message.</b>
                            </span>
                        </div>

                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="save-message">Send Message</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(function () {
//        var currentTime = new Date();
//        var startDateTo = new Date(currentTime.getFullYear(), currentTime.getMonth() + 1, 0);
        $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', maxDate: 0, minDate: 0}); //changeMonth: true, changeYear: true, 
    });

    $("#messageForm").validate({
        rules: {
            message_date: "required",
//            message_subject: "required",
            message: "required"
        },
        messages: {
            message_date: "Please select remark date",
//            message_subject: "Please enter message subject",
            message: "please enter message data"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    $('#message').keyup(function () {
        var len = $(this).val().length;
        $('#charNum').html(1000 - len + '/1000 Characters');
        if (len === 161) {
            alert("Your Message Length Just Exceed 160 characters.. Treating as second message");
        }
        if (len >= 1000) {
            var output = $(this).val().substring(0, 1000);
            $(this).val(output);

        } else {

        }
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
        $('#class_id').multiselect({
            includeSelectAllOption: true
        });
    });
    $("#save-message").click(function () {
        var class_ids = $('#class_id').val();
        if (class_ids === null || class_ids === '') {
            $('#studenterrormessage').html('Please select at least one Class');
            return;
        } else {
            $('#studenterrormessage').html('');
        }
    });
</script>
