<!-- Content Wrapper. Contains page content -->
<style>
    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        text-align: left;
        padding: 8px;
    }

    tr:nth-child(even){background-color: #f2f2f2}
    table, td, th {    
        border: 1px solid #ddd;
        text-align: left;
    }

    table {
        border-collapse: collapse;
        width: 100%;
    }

    th, td {
        padding: 15px;
    }
    th {
        background-color: #3c8dbc;
        color: white;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h4>Attendance Management</h4>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=' ?>">Manage Attendance</a></li>
            <li class="active">Update Attendance</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content1">
        <div class="row"><!-- col-xs-offset-3 -->
            <div class="col-md-8 col-xs-offset-2">
                <h4>Class Info:</h4>
                <!-- general form elements -->
                <div class="box box-primary">
                    <!-- /.box-header -->
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="class_name">Attendance Date:</label>
                                    <?php echo ucfirst($attendanceDate); ?>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="student_admission_id">Class Name:</label>
                                    <?php echo ucfirst($className['class_name']); ?>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <label for="student_name">Section Name:</label>
                                    <?php echo ucfirst($sectionName['section_name']); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/.col (left) -->
            </div>
        </div>
    </section>
    <section class="content">
        <h4>Edit Attendance</h4>
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <!--            <div class="box-header">
                                  <h3 class="box-title">Data Table With Full Features</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <form method="POST" action="<?php echo base_url() . 'attendance/update_attendance'; ?>">
                            <input type="hidden" name="total_count" value="<?php echo count($students); ?>">
                            <input type="hidden" name="class_id" value="<?php echo $_GET['class_id']; ?>">
                            <input type="hidden" name="section_id" value="<?php echo $_GET['section_id']; ?>">
                            <input type="hidden" name="attendance_date" value="<?php echo $_GET['attendance_date']; ?>">
                            <input type="hidden" name="attendance_post_id" value="<?php echo $_GET['attendance_id']; ?>">
                            <table class="table" id="example11" style="border: 1px solid gainsboro">
                                <thead>
                                    <tr>
                                        <th>Id</th>
                                        <th>Admission No.</th>
                                        <th>Student Name</th>
                                        <th>Class</th>
                                        <th>Section</th>
                                        <th>Attendance</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    if ($students) {
                                        foreach ($students as $k => $user_row) {
                                            ?>
                                            <tr>
                                                <td><?php echo ++$k; ?></td>
                                                <td><?php echo $user_row['sch_admission_id']; ?></td>
                                                <td><?php echo ucfirst($user_row['student_name']); ?></td>
                                                <td><?php echo $user_row['class_name']; ?></td>
                                                <td><?php echo $user_row['section_name']; ?></td>
                                                <td>
                                                    <input type="radio" name="status_<?php echo $k; ?>" value="P" id="status_<?php echo $k; ?>" <?php
                                                    if ($user_row['status'] === 'P') {
                                                        echo "checked";
                                                    }
                                                    ?>> Present
                                                    <input type="radio" name="status_<?php echo $k; ?>" value="F" id="status_<?php echo $k; ?>" <?php
                                                    if ($user_row['status'] === 'F') {
                                                        echo "checked";
                                                    }
                                                    ?>> Fullday Absent
                                                    <input type="radio" name="status_<?php echo $k; ?>" value="M" id="status_<?php echo $k; ?>" <?php
                                                    if ($user_row['status'] === 'M') {
                                                        echo "checked";
                                                    }
                                                    ?>> Absent in morning session
                                                    <input type="radio" name="status_<?php echo $k; ?>" value="E" id="status_<?php echo $k; ?>" <?php
                                                    if ($user_row['status'] === 'E') {
                                                        echo "checked";
                                                    }
                                                    ?>> Absent in afternoon session
                                                    <input type="hidden" name="student_admission_id_<?php echo $k; ?>" value="<?php echo $user_row['sch_admission_id']; ?>" >
                                                </td>
                                            </tr>
                                            <?php
                                        }
                                    } else {
                                        ?>
                                        <tr><td colspan="6" style="text-align:center"><b>No Students Data Found</b></td></tr>
                                    <?php }
                                    ?>
                                </tbody>
                            </table>
                            <?php if ($students) { ?>
                                <div style="padding:10px;" class="pull-right">
                                    <a class="btn btn-md btn-primary" href="<?php echo base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=' ?>">Back</a>
                                    <button class="btn btn-md btn-primary" id="delete_all">Update Attendance</button>
                                </div>
                            <?php } ?>
                        </form>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>