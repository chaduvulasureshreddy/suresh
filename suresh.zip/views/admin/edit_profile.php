<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Profile
            <small>Edit Profile</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Settings</a></li>
            <li class="active">Edit Profile</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="first_name">First Name</label>
                                <input type="text" class="form-control" name="first_name" id="first_name" value="<?php echo $user_data['first_name']; ?>" placeholder="First Name" required>
                            </div>
                            <div class="form-group">
                                <label for="last_name">Last Name</label>
                                <input type="text" class="form-control" name="last_name" id="first_name" value="<?php echo $user_data['last_name']; ?>" placeholder="Last Name" required>
                            </div>
                            <div class="form-group">
                                <label for="email">Email</label>
                                <input type="text" class="form-control" name="email" id="email" value="<?php echo $user_data['email']; ?>" placeholder="Email" readonly>
                            </div>
                            <div class="form-group">
                                <label for="email">Username</label>
                                <input type="text" class="form-control" name="username" id="username" value="<?php echo $user_data['user_name']; ?>" placeholder="Username" readonly>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-6">
                                    <label for="email">Profile Pic</label>
                                    <input type="file" name="profile_pic" id="profile_pic">
                                </div>
                                <?php if (!empty($user_data['profile_pic'])) { ?>
                                    <img src="<?php echo base_url() . 'uploads/profile_pics/' . $user_data['profile_pic']; ?>" class="img-photo"/>
                                <?php } ?>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>