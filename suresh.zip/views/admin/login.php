<div class="login-box">
    <div class="login-logo">
        <a href="javascript:void(0);"><b>School Admin</b></a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body">
        <p class="login-box-msg">Login to access School Dashboard</p>

        <?php
        if ($this->session->flashdata('alert')) {
            $alert = $this->session->flashdata('alert');
            ?>
            <div class="alert <?php if ($alert['type']) {
            echo 'alert-' . $alert['type'];
        } ?> alert-dismissible">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
            <?php if ($alert['message']) {
                echo $alert['message'];
            } ?>
            </div>
        <?php } ?>

        <form action="" method="post">
            <div class="form-group has-feedback">
                <input type="textbox" class="form-control" name="email" placeholder="Email" required>
                <span class="fa fa-envelope form-control-feedback"></span>

            </div>
            <div class="form-group has-feedback">
                <input type="password" class="form-control" name="password" placeholder="Password" required>
                <span class="fa fa-lock form-control-feedback"></span>
            </div>
            <div class="row">
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block btn-flat">Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>


        <!--    <a href="#">I forgot my password</a><br>
            <a href="register.html" class="text-center">Register a new membership</a>-->

    </div>
    <!-- /.login-box-body -->
</div>
<script>
    /*$(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });*/
</script>
<!-- /.login-box -->
