<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <subject class="content-header">
        <h1>
            Subjects
            <small>Manage Subjects</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Manage Subjects</li>
        </ol>
    </subject>

    <!-- Main content -->
    <subject class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <!--            <div class="box-header">
                                  <h3 class="box-title">Data Table With Full Features</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div style="padding:10px;">
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>To Import Subjects By CSV:</label>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <button class="btn btn-md btn-primary">
                                    <i class="fa fa-plus"></i> Import Subjects
                                </button>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <label>To Export Subjects By CSV:</label>
                            </div>
                        </div>
                        <div class="col-sm-3">
                            <div class="form-group">
                                <button class="btn btn-md btn-primary" onclick="toExportSubjectsData()">
                                    <i class="fa fa-download"></i> Export Subjects
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <input type="checkbox" name="select_all" id="select_all"/>
                                    </th>
                                    <th>Id</th>
                                    <th>Class Name</th>
                                    <th>Subject Name</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($subjects) {
                                    foreach ($subjects as $k => $subject_row) {
                                        ?>
                                        <tr>
                                            <td><input type="checkbox" class="checkbox" name="selectAll_<?php echo $subject_row['id']; ?>" id="selectAll_<?php echo $subject_row['id']; ?>" data-id="<?php echo $subject_row['id']; ?>"></td>
                                            <td><?php echo ++$k; ?></td>
                                            <td><?php echo ucfirst($subject_row['class_name']); ?></td>
                                            <td><?php echo ucfirst($subject_row['subject_name']); ?></td>
                                            <td><?php
                                                if ($subject_row['subject_status'] == 'A') {
                                                    echo 'Active';
                                                } elseif ($subject_row['subject_status'] == 'I') {
                                                    echo 'Inactive';
                                                }
                                                ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'subject/edit_subject/' . $subject_row['id'] ?>"><i class="fa fa-edit"></i>Edit</a>&nbsp;
                                                <a href="<?php echo base_url() . 'subject/delete_subject/' . $subject_row['id'] ?>" onclick="return confirm('Are you sure you want to delete this ?');"><i class="fa fa-remove"></i>Delete</a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <?php if ($subjects) { ?>
                        <div style="padding:10px;"><button class="btn btn-md btn-primary" id="delete_all">Delete All</button></div>
                    <?php } ?>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </subject>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>
    $("#select_all").change(function () {  //"select all" change
        $(".checkbox").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked subject_status
    });

    function toExportSubjectsData() {
        var url = '<?php echo base_url() ?>' + 'subject/export_subjects_data';
        document.location = url;
    }

//".checkbox" change
    $('.checkbox').change(function () {
        //uncheck "select all", if one of the listed checkbox item is unchecked
        if (false == $(this).prop("checked")) { //if this item is unchecked
            $("#select_all").prop('checked', false); //change "select all" checked subject_status to false
        }
        //check "select all" if all checkbox items are checked
        if ($('.checkbox:checked').length == $('.checkbox').length) {
            $("#select_all").prop('checked', true);
        }
    });

    $('#delete_all').on('click', function (e) {
        var allVals = [];
        $(".checkbox:checked").each(function () {
            allVals.push($(this).attr('data-id'));
        });
        if (allVals.length <= 0)
        {
            alert("Please select at least one to delete.");
        } else {
            var y = "Are you sure you want to delete this row?";
            var check = confirm(y);
            if (check === true) {
                //for server side
                var join_selected_values = allVals.join(",");
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url() ?>subject/delete_multiple_subjects",
                    cache: false,
                    data: 'ids=' + join_selected_values,
                    success: function (response)
                    {
                        if (response === 'exist') {
                            location.reload();
                        } else if (response === 'success') {
                            location.reload();
                        } else if (response === 'fail') {
                            location.reload();
                        }
                    }
                });
            }
        }
    });
</script>