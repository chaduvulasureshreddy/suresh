<!-- Content Wrapper. Contains page content -->
<style>
    label.error, .errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Subject
            <small>Edit Subject</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'subject/manage_subjects' ?>">Manage Subjects</a></li>
            <li class="active">Edit Subject</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="subjectForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="category">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            ?>
                                            <option value="<?php echo $cls['id']; ?>" <?php if ($cls['id'] == $subjects['class_id']) { ?> selected="selected" <?php } ?>><?php echo $cls['class_name']; ?> </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="first_name">Section Name:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="subject_name" id="subject_name" placeholder="Subject Name" onkeyup="toCheckSubjectName()" value="<?php echo $subjects['subject_name']; ?>" required>
                                <input type="hidden" class="form-control" name="class_section_id" id="class_section_id" value="<?php echo $subjects['class_id']; ?>" required>
                                <input type="hidden" class="form-control" name="subject_id" id="subject_id" value="<?php echo $subjects['id']; ?>" required>
                                <span class="errormessage" id="subject_exist_message"></span>
                            </div>
                            <div class="form-group">
                                <label for="about">Status:</label>
                                <select class="form-control" name="subject_status" id="status">
                                    <option value="A" <?php
                                    if ($subjects['subject_status'] == "A") {
                                        echo "selected";
                                    }
                                    ?>>Active</option>
                                    <option value="I" <?php
                                    if ($subjects['subject_status'] == "I") {
                                        echo "selected";
                                    }
                                    ?>>In Active</option>

                                </select>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="subject_save">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
</script>

<script>
    $("#subjectForm").validate({
        rules: {
            class_id: "required",
            subject_name: "required"
        },
        messages: {
            class_id: "please select class",
            subject_name: "Please enter subject name"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    function toCheckSubjectName() {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Subject/toCheckSubjectName",
            data: {subject_name: $('#subject_name').val(), class_id: $('#class_section_id').val(), section_id: $('#subject_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#subject_exist_message').html('Subject already exist for this class');
                            $('#subject_save').prop('disabled', true);
                        } else {
                            $('#subject_exist_message').html('');
                            $('#subject_save').prop('disabled', false);
                        }
                    }
        });
    }
</script>