<style>
    table {
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;
    }

    th, td {
        text-align: left;
        padding: 8px;
        text-align: left;
    }

    tr:nth-child(even){background-color: #f2f2f2}
</style>

<h4><u>Student Remarks Information:</u></h4>
<!-- general form elements -->
<table class="table table-bordered table-striped">
    <tbody>
        <tr>
            <td>
                <b>School Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($user_data['institutename']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Admission Number:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['sch_admission_id']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Class:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['class_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Section:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['section_name']); ?></b>
            </td>
        </tr>
    </tbody>
</table>

<?php
if (!empty($remarks)) {
    foreach ($remarks as $mon => $monremarks):
        ?>
        <h4><u><?php echo $mon . ' Remarks Information:' ?></u></h4>
        <table>
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Remark Date</th>
                    <th>Remark</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($monremarks as $key => $remark): ?>
                    <tr>
                        <td><?php echo ++$key; ?></td>
                        <td><?php echo date('dS-F-Y', strtotime($remark['remark_date'])); ?></td>
                        <td><?php echo $remark['remark_name']; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    endforeach;
} else {
    ?>
    <br>
    <table>
        <thead>
            <tr>
                <th>S.No</th>
                <th>Remark Date</th>
                <th>Remark</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="3" style="color: red; background: yellow; text-align: center">No Information Found Please try with another dates</td>
            </tr>
        </tbody>
    </table>
<?php }
?>
