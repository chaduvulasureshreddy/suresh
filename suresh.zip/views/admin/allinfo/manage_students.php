<!-- Content Wrapper. Contains page content -->
<style>
    .dataTables_empty{
        text-align: center;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Students
            <small>Manage Students</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Manage Students</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <!--            <div class="box-header">
                                  <h3 class="box-title">Data Table With Full Features</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div style="padding:10px;">
                        <div class="row">
                            <div class="col-sm-1">
                                <div class="form-group">
                                    <label for="student_filters">Filters:</label>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <select class="form-control" name="student_class_id" id="student_class_id" onchange="toGetStudents()" required>
                                        <option value="">Select Class</option>
                                        <?php
                                        if ($classes) {
                                            foreach ($classes as $count_row) {
                                                ?>
                                                <option value="<?php echo $count_row['id']; ?>" <?php
                                                if (isset($_GET['class_id'])) {
                                                    if ($_GET['class_id'] == $count_row['id']) {
                                                        echo "selected";
                                                    }
                                                }
                                                ?>><?php echo $count_row['class_name']; ?></option>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="form-group">
                                    <select class="form-control" name="student_section_id" id="student_section_id" onchange="toGetStudentsBySections()" required>
                                        <option value="">Select Section</option>
                                    </select>
                                </div>
                            </div>
                            <div class="col-sm-2">
                                <div class="form-group">
                                    <a class="btn btn-primary btn-md" href="<?php echo base_url() . 'allinfo/students?class_id=&section_id='; ?>">
                                        <i class="fa fa-refresh"></i> Refresh
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Admission No.</th>
                                    <th>Student Name</th>
                                    <th>Class</th>
                                    <th>Section</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($students) {
                                    foreach ($students as $k => $user_row) {
                                        ?>
                                        <tr>
                                            <td><?php echo ++$k; ?></td>
                                            <td><?php echo $user_row['sch_admission_id']; ?></td>
                                            <td><?php echo ucfirst($user_row['student_name']); ?></td>
                                            <td><?php echo ucfirst($user_row['class_name']); ?></td>
                                            <td><?php echo ucfirst($user_row['section_name']); ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'allinfo/view_student_info/' . $user_row['sch_admission_id'] ?>"><i class="fa fa-eye"></i> View All Information</a>
                                            </td>
                                        </tr>
                                        <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>

<script>

    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toGetSectionsByClass",
            data: {class_id: '<?php echo $_GET['class_id']; ?>'},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#student_section_id').html(data);
                            $('#student_section_id').val(<?php echo $_GET['section_id']; ?>);
                        } else {
                            $('#student_section_id').html('<option value="">No section available to select</option>');
                        }
                    }
        });
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });
    //alert($('#category_id').val());


    function toGetStudents() {
        var class_id = $('#student_class_id').val();
        if (window.location.href.indexOf("?") > -1) {
            var url = '<?php echo base_url() ?>' + 'allinfo/students?class_id=' + class_id + '&section_id=';
        } else {
            var url = document.location.href + "?class_id=" + class_id + '&section_id=';
        }
        document.location = url;
    }

    function toExportStudentsData() {

        var class_id = "<?php echo $_GET['class_id']; ?>";
        var section_id = "<?php echo $_GET['section_id']; ?>";
        var url = '<?php echo base_url() ?>' + 'admin/export_students_data?class_id=' + class_id + '&section_id=' + section_id;
        document.location = url;
    }

    function toGetStudentsBySections() {
        var class_id = $('#student_class_id').val();
        var section_id = $('#student_section_id').val();
        if (window.location.href.indexOf("?") > -1) {
            var url = '<?php echo base_url() ?>' + 'allinfo/students?class_id=' + class_id + '&section_id=' + section_id;
        } else {
            var url = document.location.href + "?class_id=" + class_id + '&section_id=' + section_id;
        }
        document.location = url;
    }

</script>