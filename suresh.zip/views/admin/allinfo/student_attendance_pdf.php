<style>
    table {
        border-collapse: collapse;
        width: 100%;
        border: 1px solid black;

    }

    th, td {
        text-align: left;
        padding: 8px;
        text-align: left;
    }

    tr:nth-child(even){background-color: #f2f2f2}
</style>

<h4><u>Student Attendance Information:</u></h4>
<!-- general form elements -->
<table class="table table-bordered table-striped">
    <tbody>
        <tr>
            <td>
                <b>School Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($user_data['institutename']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Admission Number:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['sch_admission_id']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Student Name:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['student_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Class:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['class_name']); ?></b>
            </td>
        </tr>
        <tr>
            <td>
                <b>Section:</b>
            </td>
            <td>
                <b><?php echo ucfirst($studentInfo['section_name']); ?></b>
            </td>
        </tr>
    </tbody>
</table>

<?php
if (!empty($attendance)) {
    foreach ($attendance as $mon => $monAttendance):
        ?>
        <h4><u><?php echo $mon . ' Attendance Information:' ?></u></h4>
        <table>
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Date</th>
                    <th>Present</th>
                    <th>Absent In Mrng</th>
                    <th>Absent In Aftn</th>
                    <th>Absent</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($monAttendance as $key => $attend): ?>
                    <tr>

                        <?php if ($attend['status'] == 'P') { ?>
                            <td><?php echo ++$key; ?></td>
                            <td><?php echo date('dS-F-Y', strtotime($attend['date'])); ?></td>
                            <td>P</td>
                            <td>--</td>
                            <td>--</td>
                            <td>--</td>
                        <?php } else if ($attend['status'] == 'M') { ?>
                            <td><?php echo ++$key; ?></td>
                            <td><?php echo date('dS-F-Y', strtotime($attend['date'])); ?></td>
                            <td>--</td>
                            <td>A</td>
                            <td>--</td>
                            <td>--</td>
                        <?php } else if ($attend['status'] == 'E') { ?>
                            <td><?php echo ++$key; ?></td>
                            <td><?php echo date('dS-F-Y', strtotime($attend['date'])); ?></td>
                            <td>--</td>
                            <td>--</td>
                            <td>A</td>
                            <td>--</td>
                        <?php } else if ($attend['status'] == 'F') { ?>
                            <td><?php echo ++$key; ?></td>
                            <td><?php echo date('dS-F-Y', strtotime($attend['date'])); ?></td>
                            <td>--</td>
                            <td>--</td>
                            <td>--</td>
                            <td>A</td>
                        <?php } ?>
                    </tr>
                <?php endforeach; ?>

            </tbody>
        </table>
        <?php
    endforeach;
} else {
    ?>
    <br>
    <table>
        <thead>
            <tr style="border: 1px solid black;">
                <th>S.No</th>
                <th>Date</th>
                <th>Present</th>
                <th>Absent In Mrng</th>
                <th>Absent In Aftn</th>
                <th>Absent</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td colspan="6" style="color: red; background: yellow; text-align: center">No Information Found Please try with another dates</td>
            </tr>
        </tbody>
    </table>
<?php } ?>
<br>
<span style="font-weight: 700px; color: black; background: yellow">
    <b>Note:  Present - Full Day Present, Absent - Full Day Absent <br>
        Absent In Mrng - Absent in morning session, Absent In Aftn - Absent in Afternoon session
    </b>
</span>
