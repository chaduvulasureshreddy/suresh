<div class="content-wrapper">
    <section class="content-header">
        <h1>
            View All Information of Student
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'allinfo/students?class_id=&section_id=' ?>">All Info</a></li>
            <li class="active">View Student</li>
        </ol>
    </section>
    <!-- Main content -->
    <input type="hidden" id="student_admission_id" value="<?php echo $studentInfo['sch_admission_id']; ?>" name="student_admission_id">
    <section class="content">
        <div class="col-md-10 col-xs-offset-1">
            <ul class=" list-unstyled list-inline">
                <li>
                    <a href="<?php echo base_url() . 'allinfo/students?class_id=&section_id=' ?>" class="btn btn-sm btn-primary" style="float:left">
                        <i class="fa fa-arrow-left"></i> Back
                    </a>
                </li>
                <li class=" pull-right">
                    <button class="btn btn-sm btn-primary" style="float:left" onclick="toDownloadPdf()">
                        <i class="fa fa-download"></i> Download Student Info
                    </button>
                </li>
            </ul>
            <div class="box box-primary">
                <div class=" panel-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Student Name:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <?php echo ucfirst($studentInfo['student_name']); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Student Admission Number:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <?php echo ucfirst($studentInfo['sch_admission_id']); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Class:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <?php echo ucfirst($studentInfo['class_name']); ?>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Section:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <?php echo ucfirst($studentInfo['section_name']); ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="content">
        <div class="col-md-10 col-xs-offset-1">
            <div class="box box-primary">
                <div class="panel-body">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Select Start Date(Year And Month):<span class="text-danger">*</span></label>
                                <input name="startDate" id="datepicker" class="form-control" placeholder="Select Start Date" readonly required />
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Select End Date(Year And Month):<span class="text-danger">*</span></label>
                                <input name="endDate" id="datepicker1" class="form-control" placeholder="Select End Date" readonly required />
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Attendance Info:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button name="attendance" id="attendance" class="btn btn-primary btn-sm" onclick="toGetAttendanceInfo()">GET Attendance</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Remarks Info:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button name="remarks" id="remarks" class="btn btn-primary btn-sm" onclick="toGetRemarksInfo()">GET Remarks</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Homework Info:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button name="homework" id="homework" class="btn btn-primary btn-sm" onclick="toGetHomeworkInfo()">GET Homeworks</button>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="col-sm-6">
                                <label>Fee Info:</label>
                            </div>
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <button name="fee" id="fee" class="btn btn-primary btn-sm" onclick="toGetFeeInfo()">GET Fee Information</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>
<script>

    $(window).bind('setup', function () {
        $('#loading_icon').show();
    });
    $(window).bind('loaded', function () {
        $('#loading_icon').show();
    });
    $(document).ready(function () {
        $(window).trigger('setup');
        $(window).trigger('loaded');
        $('#loading_icon').hide();
    });

    function toDownloadPdf() {
        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'admin/toDownloadAsPdf?student_admission_id=' + student_id;
        document.location = url;
    }

    $(function () {
        $("#datepicker").datepicker({
            dateFormat: 'yy-mm-dd',
            changeMonth: true,
            changeYear: true,
            onSelect: function (dateStr)
            {
                $("#datepicker1").val(dateStr);
                $("#datepicker1").datepicker("option", {minDate: new Date(dateStr)})
            }
        });
        $("#datepicker1").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true});
    });
    /* for attendance Info */
    function toGetAttendanceInfo() {
        var startDate = $("#datepicker").val();
        var endDate = $("#datepicker1").val();
        if (startDate === '' && endDate === '') {
            alert('Please select start date and end date');
            return;
        }
        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'allinfo/toDownloadAttendanceInfo?student_admission_id=' + student_id + '&startDate=' + startDate + '&endDate=' + endDate;
        document.location = url;
    }

    /* for remarks info */

    function toGetRemarksInfo() {
        var startDate = $("#datepicker").val();
        var endDate = $("#datepicker1").val();
        if (startDate === '' && endDate === '') {
            alert('Please select start date and end date');
            return;
        }
        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'allinfo/toDownloadRemarksInfo?student_admission_id=' + student_id + '&startDate=' + startDate + '&endDate=' + endDate;
        document.location = url;
    }

    /* for fee info */

    function toGetFeeInfo() {

        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'fees/downloadStudentFeeInfo?student_admission_id=' + student_id;
        document.location = url;
    }

    /* for homework info */

    function toGetHomeworkInfo() {
        var startDate = $("#datepicker").val();
        var endDate = $("#datepicker1").val();
        if (startDate === '' && endDate === '') {
            alert('Please select start date and end date');
            return;
        }
        var student_id = $('#student_admission_id').val();
        var url = '<?php echo base_url() ?>' + 'allinfo/toDownloadHomeworkInfo?student_admission_id=' + student_id + '&startDate=' + startDate + '&endDate=' + endDate;
        document.location = url;
    }
</script>