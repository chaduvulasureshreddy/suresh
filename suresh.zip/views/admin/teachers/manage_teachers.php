<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Sections
            <small>Manage Sections</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Dashboard</a></li>
            <li class="active">Manage Sections</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <div class="col-xs-12">
                <div class="box">
                    <!--            <div class="box-header">
                                  <h3 class="box-title">Data Table With Full Features</h3>
                                </div>-->
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <!--<h4><i class="icon fa fa-info"></i> Alert!</h4>-->
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <div class="box-body">
                        <table id="example1" class="table table-bordered table-striped">
                            <thead>
                                <tr>
                                    <th>
                                        <!--<input type="checkbox" name="select_all" id="select_all"/>-->
                                    </th>
                                    <th>Id</th>
                                    <th>Category</th>
                                    <th>Name</th>
                                    <th>Status</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                if ($sections) {
                                    foreach ($sections as $k => $section_row) {
                                        ?>
                                        <tr>
                                            <td><input type="checkbox" class="checkbox" name="selectAll_<?php echo $section_row['id']; ?>" id="selectAll_<?php echo $section_row['id']; ?>" data-id="<?php echo $section_row['id']; ?>"></td>
                                            <td><?php echo ++$k; ?></td>
                                            <td><?php echo ucfirst($section_row['class_name']); ?></td>
                                            <td><?php echo ucfirst($section_row['section_name']); ?></td>
                                            <td><?php
                                                if ($section_row['status'] == 'A') {
                                                    echo 'Active';
                                                } elseif ($section_row['status'] == 'I') {
                                                    echo 'Inactive';
                                                }
                                                ?></td>
                                            <td>
                                                <a href="<?php echo base_url() . 'section/edit_section/' . $section_row['id'] ?>"><i class="fa fa-edit"></i></a>&nbsp;
                                                <a href="<?php echo base_url() . 'section/delete_section/' . $section_row['id'] ?>" onclick="return confirm('Are you sure you want to delete this ?');"><i class="fa fa-remove"></i></a>
                                            </td>
                                        </tr>
                                    <?php
                                    }
                                }
                                ?>

                            </tbody>
                        </table>
                    </div>
                    <?php if ($sections) { ?>
                        <div style="padding:10px;"><button class="btn btn-md btn-primary" id="delete_all">Delete All</button></div>
<?php } ?>
                    <!-- /.box-body -->
                </div>
                <!-- /.box -->
            </div>
            <!-- /.col -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $("#select_all").change(function () {  //"select all" change
        $(".checkbox").prop('checked', $(this).prop("checked")); //change all ".checkbox" checked status
    });

//".checkbox" change
    $('.checkbox').change(function () {
        //uncheck "select all", if one of the listed checkbox item is unchecked
        if (false == $(this).prop("checked")) { //if this item is unchecked
            $("#select_all").prop('checked', false); //change "select all" checked status to false
        }
        //check "select all" if all checkbox items are checked
        if ($('.checkbox:checked').length == $('.checkbox').length) {
            $("#select_all").prop('checked', true);
        }
    });

    $('#delete_all').on('click', function (e) {
        var allVals = [];
        $(".checkbox:checked").each(function () {
            allVals.push($(this).attr('data-id'));
        });
        if (allVals.length <= 0)
        {
            alert("Please select at least one to delete.");
        } else {
            var y = "Are you sure you want to delete this row?";
            var check = confirm(y);
            if (check === true) {
                //for server side
                var join_selected_values = allVals.join(",");
                $.ajax({
                    type: "POST",
                    url: "<?php echo base_url() ?>section/delete_multiple_sections",
                    cache: false,
                    data: 'ids=' + join_selected_values,
                    success: function (response)
                    {
                        if (response === 'exist') {
                            location.reload();
                        } else if (response === 'success') {
                            location.reload();
                        } else if (response === 'fail') {
                            location.reload();
                        }
                    }
                });
            }
        }
    });
</script>