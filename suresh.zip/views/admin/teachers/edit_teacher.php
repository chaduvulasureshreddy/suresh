<!-- Content Wrapper. Contains page content -->
<style>
    label.error, .errormessage {
        color: red;
    }
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Section
            <small>Edit Section</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="#">Dashboard</a></li>
            <li class="active">Edit Section</li>
        </ol>
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6 col-xs-offset-3">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php
                            if ($alert['message']) {
                                echo $alert['message'];
                            }
                            ?>
                        </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="sectionForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="category">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            ?>
                                            <option value="<?php echo $cls['id']; ?>" <?php if ($cls['id'] == $sections['class_id']) { ?> selected="selected" <?php } ?>><?php echo $cls['class_name']; ?> </option>
                                            <?php
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="first_name">Section Name:<span class="text-danger">*</span></label>
                                <input type="text" class="form-control" name="section_name" id="section_name" placeholder="Section Name" onchange="toCheckSectionName()" value="<?php echo $sections['section_name']; ?>" required>
                                <input type="hidden" class="form-control" name="class_section_id" id="class_section_id" value="<?php echo $sections['class_id']; ?>" required>
                                <input type="hidden" class="form-control" name="section_id" id="section_id" value="<?php echo $sections['id']; ?>" required>
                                <span class="errormessage" id="section_exist_message"></span>
                            </div>
                            <div class="form-group">
                                <label for="about">Status:</label>
                                <select class="form-control" name="status" id="status">
                                    <option value="A" <?php
                                    if ($sections['status'] == "A") {
                                        echo "selected";
                                    }
                                    ?>>Active</option>
                                    <option value="I" <?php
                                    if ($sections['status'] == "I") {
                                        echo "selected";
                                    }
                                    ?>>In Active</option>

                                </select>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary" id="section_save">Submit</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
    $("#sectionForm").validate({
        rules: {
            class_id: "required",
            section_name: "required"
        },
        messages: {
            class_id: "please select class",
            section_name: "Please enter section name"
        },
        submitHandler: function (form) {
            $('#loading_icon').show();
            form.submit();
        }
    });
    function toCheckSectionName() {
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Admin/toCheckSectionName",
            data: {section_name: $('#section_name').val(), class_id: $('#class_section_id').val(), section_id: $('#section_id').val()},
            cache: false,
            success:
                    function (data) {
                        if (data !== 'fail') {
                            $('#section_exist_message').html('Section already exist for this class');
                            $('#section_save').prop('disabled', true);
                        } else {
                            $('#section_exist_message').html('');
                            $('#section_save').prop('disabled', false);
                        }
                    }
        });
    }
</script>