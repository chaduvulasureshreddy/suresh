<!-- Content Wrapper. Contains page content -->
<style>
label.error, .errormessage {
    color: red;
}
</style>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <h1>
            Hall Tickets
            <small>Add Hall Ticket</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
            <li><a href="<?php echo base_url() . 'dashboard' ?>">Dashboard</a></li>
            <li class="active">Add Class</li>
        </ol>
    </section>
    <!-- Main content -->
    <section class="content">
        <div class="row">
            <!-- left column -->
            <div class="col-md-8 col-xs-offset-2">
                <!-- general form elements -->
                <div class="box box-primary">
                    <?php
                    if ($this->session->flashdata('alert')) {
                        $alert = $this->session->flashdata('alert');
                        ?>
                        <div class="alert <?php
                        if ($alert['type']) {
                            echo 'alert-' . $alert['type'];
                        }
                        ?> alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <?php
                        if ($alert['message']) {
                            echo $alert['message'];
                        }
                        ?>
                    </div>
                    <?php } ?>
                    <!-- /.box-header -->
                    <!-- form start -->
                    <form role="form" id="hallticketForm" action="" method="POST" enctype="multipart/form-data">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="class">Class:<span class="text-danger">*</span></label>
                                <select class="form-control" name="class_id" id="class_id" onchange="toGetSectionsByClass()" required>
                                    <option value="">Select Class</option>
                                    <?php
                                    if ($classes) {
                                        foreach ($classes as $cls) {
                                            echo '<option value="' . $cls['id'] . '">' . $cls['class_name'] . '</option>';
                                        }
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label for="student_class">Section:<span class="text-danger">*</span></label>
                                <select class="form-control" name="section_id" id="section_id" required>
                                    <option value="">Select Section</option>
                                </select>
                            </div>
                            <div class="input-group control-group after-add-more">
                                <div class="form-group col-sm-3">
                                    <label for="subject">Subject Name:<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="subject_name[]" value="" placeholder="Subject Name">
                                </div>
                                <div class="form-group col-sm-3">
                                    <label for="date">Date:<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control datepicker" name="exam_date[]" value="" placeholder="Select Date" readonly required>
                                </div>
                                <div class="form-group col-sm-3">
                                    <label for="time">Time:<span class="text-danger">*</span></label>
                                    <input type="text" class="form-control" name="exam_time[]" value="" placeholder="09:00 AM" required>
                                </div>
                                <div class="form-group col-sm-2">
                                    <label for="add">Add:</label>
                                    <button class="btn btn-success add-more" type="button"><i class="glyphicon glyphicon-plus"></i> Add</button>
                                </div>
                            </div>
                            <div class="copy hide">
                                <div class="input-group control-group" style="margin-top:10px">
                                    <div class="form-group col-sm-3">
                                        <label for="subject">Subject Name:<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="subject_name[]" value="" placeholder="Subject Name" required>
                                    </div>
                                    <div class="form-group col-sm-3">
                                        <label for="date">Date:<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control datepicker" name="exam_date[]" value="" placeholder="Select Date" readonly required>
                                    </div>
                                    <div class="form-group col-sm-3">
                                        <label for="time">Time:<span class="text-danger">*</span></label>
                                        <input type="text" class="form-control" name="exam_time[]" value="" placeholder="09:00 AM" required>
                                    </div>
                                    <div class="form-group col-sm-2">
                                        <label for="remove">Remove:</label>
                                        <button class="btn btn-danger remove" type="button"><i class="glyphicon glyphicon-remove"></i> Remove</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- /.box-body -->

                        <div class="box-footer">
                            <button type="submit" class="btn btn-primary">Add Hallticket</button>
                        </div>
                    </form>
                </div>
                <!-- /.box -->

            </div>
            <!--/.col (left) -->
        </div>
        <!-- /.row -->
    </section>
    <!-- /.content -->
</div>
<script>
$(function () {
    var currentTime = new Date();
    var startDateTo = new Date(currentTime.getFullYear(), currentTime.getMonth() + 2, 0);
    $("#datepicker").datepicker({dateFormat: 'yy-mm-dd', changeMonth: true, changeYear: true, maxDate: startDateTo, minDate: 0});
});
$(window).bind('setup', function () {
    $('#loading_icon').show();
});
$(window).bind('loaded', function () {
    $('#loading_icon').show();
});
$(document).ready(function () {
    $(".add-more").click(function(){ 
        var html = $(".copy").html();
        $(".after-add-more").after(html);
    });
    $("body").on("click",".remove",function(){ 
        $(this).parents(".control-group").remove();
    });
    $(window).trigger('setup');
    $(window).trigger('loaded');
    $('#loading_icon').hide();
    $(document).on("focus", ".datepicker", function(){
        $(this).datepicker();
    });
});
$("#hallticketForm").validate({
    rules: {
        "subject_name[]": {
      required: true
    },
        "exam_date[]":"required",
        "exam_time[]":"required"
    },
    messages: {
        "subject_name[]": "Please enter subject name",
        "exam_date[]":"Please select subject date",
        "exam_time[]":"Please enter exam time"
    },
    submitHandler: function (form) {
        $('#loading_icon').show();
        form.submit();
    }
});
$(".copy").each(function () {
    $(this).rules('add', {
        required: true
    });
});
// $("input[class*=form-control]").rules("add", "required");


function toGetSectionsByClass() {
        //alert($('#category_id').val());
        $.ajax({
            type: "POST",
            url: '<?php echo base_url(); ?>' + "Homework/toGetSectionsByClass",
            data: {class_id: $('#class_id').val()},
            cache: false,
            success:
            function (data) {
                if (data !== 'fail') {
                    $('#section_id').html(data);
                } else {
                    $('#section_id').html('<option value="">No section available to select</option>');
                }
            }
        });
        return false;
    }

    
    </script>
