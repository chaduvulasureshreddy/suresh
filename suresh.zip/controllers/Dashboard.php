<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model(array('dashboard_model'));
        $this->load->library('session');
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    public function index() {

        $data['user_data'] = $this->session->userdata();
        $data['students'] = $this->dashboard_model->get_students($data['user_data']['user_id']);
        $data['classes'] = $this->dashboard_model->get_classes($data['user_data']['user_id']);
        $data['sections'] = $this->dashboard_model->get_sections($data['user_data']['user_id']);
        $data['homeworks'] = $this->dashboard_model->get_homeworks($data['user_data']['user_id']);
        $data['remarks'] = $this->dashboard_model->get_remarks($data['user_data']['user_id']);
        $data['attendance'] = $this->dashboard_model->get_attendance($data['user_data']['user_id']);
        $data['messages'] = $this->dashboard_model->get_messages($data['user_data']['user_id']);
        $data['subjects'] = $this->dashboard_model->get_subjects($data['user_data']['user_id']);
        $pendingFee = $this->dashboard_model->get_fee_pedning_details($data['user_data']['user_id']);
        $data['pendingfee'] = $this->moneyFormatIndia($pendingFee[0]['balance_amount']);
        $paidFee = $this->dashboard_model->get_fee_paid_details($data['user_data']['user_id']);
        $data['paidfee'] = $this->moneyFormatIndia($paidFee[0]['paid_amount']);
        $data['drivers'] = $this->dashboard_model->get_drivers($data['user_data']['user_id']);
        $data['busroutes'] = $this->dashboard_model->get_busroutes($data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/dashboard');
        $this->load->view('admin/layouts/footer');
    }

    function moneyFormatIndia($num) {
        $explrestunits = "";
        if (strlen($num) > 3) {
            $lastthree = substr($num, strlen($num) - 3, strlen($num));
            $restunits = substr($num, 0, strlen($num) - 3); // extracts the last three digits
            $restunits = (strlen($restunits) % 2 == 1) ? "0" . $restunits : $restunits; // explodes the remaining digits in 2's formats, adds a zero in the beginning to maintain the 2's grouping.
            $expunit = str_split($restunits, 2);
            for ($i = 0; $i < sizeof($expunit); $i++) {
                // creates each of the 2's group and adds a comma to the end
                if ($i == 0) {
                    $explrestunits .= (int) $expunit[$i] . ","; // if is first value , convert into integer
                } else {
                    $explrestunits .= $expunit[$i] . ",";
                }
            }
            $thecash = $explrestunits . $lastthree;
        } else {
            $thecash = $num;
        }
        return $thecash; // writes the final format where $currency is the currency symbol.
    }

}
