<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Examtypes extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('examtypes_model'));
        $this->load->library('session');
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Examtypes
     */
    public function manage_examtypes() {
        $data['user_data'] = $this->session->userdata();
        $data['examtypes'] = $this->examtypes_model->get_examtypes('', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/examtypes/manage_examtypes');
        $this->load->view('admin/layouts/footer');
    }

    /* to export examtype data to csv */

    public function export_examtypes_data() {
        $data['user_data'] = $this->session->userdata();
        $examtypes = $this->examtypes_model->export_examtypes_data($data['user_data']['user_id']);
        $class_headings[] = array('S.No', 'Exam Type Name');
        foreach ($examtypes as $key => $examtype):
            $classNew['S.No'] = ++$key;
            $classNew['exam_name'] = ucfirst($examtype['exam_name']);
            array_push($class_headings, $classNew);
        endforeach;
        $fileName = 'Examtypes' . rand() . '.csv';
        array_to_csv($class_headings, $fileName);
    }

    /**
     * Add Exam Type
     */
    public function add_examtype() {
        $data['user_data'] = $this->session->userdata();
        if ($_POST) {
            $exam_name = trim($this->input->post('exam_name'));
            $examTypeName = $this->examtypes_model->toCheckExamTypeName($exam_name, '', 'student_exam_types', $data['user_data']['user_id']);
            if (!empty($examTypeName) && isset($examTypeName)) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Exam Type is already exist with Name!.. Please try with another name'));
                redirect(base_url() . 'examtypes/add_examtype');
            }
            $save_examtype_data = array(
                'exam_name' => $exam_name,
                'userid' => $data['user_data']['user_id'],
                'exam_status' => $this->input->post('exam_status')
            );
            $save_class = $this->global_model->save_data('student_exam_types', $save_examtype_data);
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Exam Type added Successfully'));
            redirect(base_url() . 'examtypes/manage_examtypes');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/examtypes/add_examtype', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Exam Type
     * @param type $id
     */
    public function delete_examtype($id = 0) {
        if ($id != '0') {
            $students = $this->examtypes_model->toCheckExamTypesWithExams($id);
            if ($students > 0) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Exam Type!..Having Exam data with this Exam Type.'));
                redirect(base_url() . 'examtypes/manage_examtypes');
            }
            $delete_examtype = $this->global_model->update_by('student_exam_types', array('id' => $id), array('exam_status' => 'D'));
            if ($delete_examtype) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Exam Type deleted Successfully'));
            }
            redirect(base_url() . 'examtypes/manage_examtypes');
        }
    }

    public function delete_multiple_examtypes() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $c_id):
                $students = $this->examtypes_model->toCheckExamTypesWithExams($c_id);
                if ($students > 0) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Exam Type!..Having Students data with this examtype, Please delete students under this examtype before delete the examtype!.'));
                    echo "exist";
                    exit;
                }
            endforeach;
            foreach ($ids as $c_id):
                $delete_examtype = $this->global_model->update_by('student_exam_types', array('id' => $c_id), array('exam_status' => 'D'));
            endforeach;
            if ($delete_examtype) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Examtypes deleted successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Exam Type
     * @param type $id
     */
    public function edit_examtype($id = 0) {
        $data['user_data'] = $this->session->userdata();
        if ($id != '0') {
            $data['examtype_details'] = $this->examtypes_model->get_examtypes(array('id' => $id), $data['user_data']['user_id']);
            if ($data['examtype_details']) {
                $data['examtype_details'] = $data['examtype_details'][0];
            } else {
                $data['examtype_details'] = array();
            }
            if ($_POST) {
                $exam_name = trim($this->input->post('exam_name'));
                $examTypeName = $this->examtypes_model->toCheckExamTypeName($exam_name, $id, 'student_exam_types', $data['user_data']['user_id']);
                if (!empty($examTypeName) && isset($examTypeName)) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Exam Type is already exist with Name!.. Please try with another name'));
                    redirect(base_url() . 'examtypes/edit_examtype/' . $id);
                }
                $save_examtype_data = array(
                    'exam_name' => $exam_name,
                    'userid' => $data['user_data']['user_id'],
                    'exam_status' => $this->input->post('exam_status')
                );
                $save_class = $this->global_model->update_by('student_exam_types', array('id' => $id), $save_examtype_data);
                if ($save_class) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Exam Type updated Successfully'));
                }

                redirect(base_url() . 'examtypes/manage_examtypes');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/examtypes/edit_examtype', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /*
     * To Check Exam Type Name
     */

    public function toCheckExamTypeName() {

        $data['user_data'] = $this->session->userdata();
        $exam_name = trim($this->input->post('exam_name'));
        $examtype_id = $this->input->post('examtype_id');
        if (!empty($exam_name)) {
            $result = $this->examtypes_model->toCheckExamTypeName($exam_name, $examtype_id, 'student_exam_types', $data['user_data']['user_id']);
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
