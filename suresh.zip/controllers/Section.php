<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Section extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('section_model', 'admin_model'));
        $this->load->library('session');
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Sections
     */
    public function manage_sections() {
        $data['user_data'] = $this->session->userdata();
        $data['sections'] = $this->section_model->get_sections('', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/sections/manage_sections');
        $this->load->view('admin/layouts/footer');
    }

    /* to export sections data */

    public function export_sections_data() {
        $data['user_data'] = $this->session->userdata();
        $sections = $this->section_model->export_sections_data($data['user_data']['user_id']);
        $section_headings[] = array('S.No', 'Class Name', 'Section Name');
        foreach ($sections as $key => $section):
            $sectionNew['S.No'] = ++$key;
            $sectionNew['class_name'] = ucfirst($section['class_name']);
            $sectionNew['section_name'] = ucfirst($section['section_name']);
            array_push($section_headings, $sectionNew);
        endforeach;
        $fileName = 'Sections' . rand() . '.csv';
        array_to_csv($section_headings, $fileName);
    }

    /**
     * Add Section
     */
    public function add_section() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->global_model->get_all_classes('student_classes', $data['user_data']['user_id']);
        if ($_POST) {
            $class_id = $this->input->post('class_id');
            $section_name = trim($this->input->post('section_name'));
            $sectionName = $this->admin_model->toCheckSectionName($section_name, $class_id, '', 'student_class_sections', $data['user_data']['user_id']);
            if (!empty($sectionName) && isset($sectionName)) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Section is already exist with this name!.. please try with another name'));
                redirect(base_url() . 'section/add_section');
            }
            $save_section_data = array(
                'userid' => $data['user_data']['user_id'],
                'class_id' => $class_id,
                'section_name' => $section_name,
                'status' => $this->input->post('status')
            );
            $this->global_model->save_data('student_class_sections', $save_section_data);
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section added Successfully'));
            redirect(base_url() . 'section/manage_sections');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/sections/add_section', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Section
     * @param type $id
     */
    public function delete_section($id = 0) {
        if ($id != '0') {
            $students = $this->section_model->toCheckStudentsWithThisSection($id);
            if ($students > 0) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Section!..Having Students data with this section, Please delete students under this section before delete the section!.'));
                redirect(base_url() . 'section/manage_sections');
            }
            $delete_user = $this->global_model->update_by('student_class_sections', array('id' => $id), array('status' => 'D'));
            if ($delete_user) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section deleted Successfully'));
            }
            redirect(base_url() . 'section/manage_sections');
        }
    }

    public function delete_multiple_sections() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $sec_id):
                $students = $this->section_model->toCheckStudentsWithThisSection($sec_id);
                if ($students > 0) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Section!..Having Students data with this section, Please delete students under this section before delete the section!.'));
                    echo "exist";
                    exit;
                }
            endforeach;
            foreach ($ids as $sec_id):
                $delete_student = $this->global_model->update_by('student_class_sections', array('id' => $sec_id), array('status' => 'D'));
            endforeach;
            if ($delete_student) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section deleted Successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Section
     * @param type $id
     */
    public function edit_section($id = 0) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->global_model->get_all_classes('student_classes',$data['user_data']['user_id']);
        if ($id != '0') {
            $data['sections'] = $this->section_model->get_sections(array('ss.id' => $id), $data['user_data']['user_id']);
            if ($data['sections']) {
                $data['sections'] = $data['sections'][0];
            } else {
                $data['sections'] = array();
            }

            if ($_POST) {
                $class_id = $this->input->post('class_id');
                $section_name = trim($this->input->post('section_name'));
                $sectionName = $this->admin_model->toCheckSectionName($section_name, $class_id, $id, 'student_class_sections', $data['user_data']['user_id']);
                if (!empty($sectionName) && isset($sectionName)) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Section is already exist with this name!.. please try with another name'));
                    redirect(base_url() . 'section/edit_section/' . $id);
                }
                $save_section_data = array(
                    'class_id' => $class_id,
                    'section_name' => $section_name,
                    'status' => $this->input->post('status')
                );
                $save_section = $this->global_model->update_by('student_class_sections', array('id' => $id), $save_section_data);
                if ($save_section) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section updated Successfully'));
                }

                redirect(base_url() . 'section/manage_sections');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/sections/edit_section', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
