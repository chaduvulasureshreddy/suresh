<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Classdata extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('classdata_model'));
        $this->load->library('session');
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Classes
     */
    public function manage_classes() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->classdata_model->get_classes('', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/classes/manage_classes');
        $this->load->view('admin/layouts/footer');
    }

    /* to export class data to csv */

    public function export_classes_data() {
        $data['user_data'] = $this->session->userdata();
        $classes = $this->classdata_model->export_classes_data($data['user_data']['user_id']);
        $class_headings[] = array('S.No', 'Class Name');
        foreach ($classes as $key => $class):
            $classNew['S.No'] = ++$key;
            $classNew['class_name'] = ucfirst($class['class_name']);
            array_push($class_headings, $classNew);
        endforeach;
        $fileName = 'Classes' . rand() . '.csv';
        array_to_csv($class_headings, $fileName);
    }

    /**
     * Add Class
     */
    public function add_class() {
        $data['user_data'] = $this->session->userdata();
        if ($_POST) {
            $class_name = trim($this->input->post('class_name'));
            $className = $this->classdata_model->toCheckClassName($class_name, '', 'student_classes', $data['user_data']['user_id']);
            if (!empty($className) && isset($className)) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Class is already exist with Name!.. Please try with another name'));
                redirect(base_url() . 'classdata/add_class');
            }
            $save_class_data = array(
                'class_name' => $class_name,
                'userid' => $data['user_data']['user_id'],
                'status' => $this->input->post('status')
            );
            $save_class = $this->global_model->save_data('student_classes', $save_class_data);
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Class added Successfully'));
            redirect(base_url() . 'classdata/manage_classes');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/classes/add_class', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Class
     * @param type $id
     */
    public function delete_class($id = 0) {
        if ($id != '0') {
            $students = $this->classdata_model->toCheckStudentsWithThisClass($id);
            if ($students > 0) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Class!..Having Students data with this Class, Please delete students under this Class before delete the Class!.'));
                redirect(base_url() . 'classdata/manage_classes');
            }
            $delete_class = $this->global_model->update_by('student_classes', array('id' => $id), array('status' => 'D'));
            if ($delete_class) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Class deleted Successfully'));
            }
            redirect(base_url() . 'classdata/manage_classes');
        }
    }

    public function delete_multiple_classes() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $c_id):
                $students = $this->classdata_model->toCheckStudentsWithThisClass($c_id);
                if ($students > 0) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Class!..Having Students data with this class, Please delete students under this class before delete the class!.'));
                    echo "exist";
                    exit;
                }
            endforeach;
            foreach ($ids as $c_id):
                $delete_student = $this->global_model->update_by('student_classes', array('id' => $c_id), array('status' => 'D'));
            endforeach;
            if ($delete_student) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Classes deleted successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Class
     * @param type $id
     */
    public function edit_class($id = 0) {
        $data['user_data'] = $this->session->userdata();
        if ($id != '0') {
            $data['class_details'] = $this->classdata_model->get_classes(array('id' => $id), $data['user_data']['user_id']);
            if ($data['class_details']) {
                $data['class_details'] = $data['class_details'][0];
            } else {
                $data['class_details'] = array();
            }
            if ($_POST) {
                $class_name = trim($this->input->post('class_name'));
                $className = $this->classdata_model->toCheckClassName($class_name, $id, 'student_classes', $data['user_data']['user_id']);
                if (!empty($className) && isset($className)) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Class is already exist with Name!.. Please try with another name'));
                    redirect(base_url() . 'classdata/edit_class/' . $id);
                }
                $save_class_data = array(
                    'class_name' => $class_name,
                    'userid' => $data['user_data']['user_id'],
                    'status' => $this->input->post('status')
                );
                $save_class = $this->global_model->update_by('student_classes', array('id' => $id), $save_class_data);
                if ($save_class) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Class updated Successfully'));
                }

                redirect(base_url() . 'classdata/manage_classes');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/classes/edit_class', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /*
     * To Check Class Name
     */

    public function toCheckClassName() {

        $data['user_data'] = $this->session->userdata();
        $class_name = trim($this->input->post('class_name'));
        $class_id = $this->input->post('class_id');
        if (!empty($class_name)) {
            $result = $this->classdata_model->toCheckClassName($class_name, $class_id, 'student_classes', $data['user_data']['user_id']);
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
