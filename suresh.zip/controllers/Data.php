<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Data extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     *      http://example.com/index.php/welcome
     *  - or -
     *      http://example.com/index.php/welcome/index
     *  - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function index() {
        $this->load->view('welcome_message');
    }

    public function userRegistration() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {
            /* if (isset($_FILES) && !empty($_FILES)) {
              $profile_pic = $_FILES['image'];
              $img = $profile_pic;
              if (count($profile_pic) > 0) {
              $img_name = rand() . '.png';
              $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/shop_images/' . $img_name;
              $filename = $_FILES['image']['tmp_name'];
              move_uploaded_file($filename, $location);
              $saved_location_file_name = base_url() . 'uploads/shop_images/' . $img_name;
              }
              } */

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/shop_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/shop_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            $data_to_store = array(
                
                'institutename' => (isset($_POST['institutename']) && $_POST['institutename'] != '') ? $_POST['institutename'] : '',
                'mobile' => (isset($_POST['mobile']) && $_POST['mobile'] != '') ? $_POST['mobile'] : '',
               'landphone' => (isset($_POST['landphone']) && $_POST['landphone'] != '') ? $_POST['landphone'] : '',

                'register_as' => (isset($_POST['register_as']) && $_POST['register_as'] != '') ? $_POST['register_as'] : '',
                 'city' => (isset($_POST['city']) && $_POST['city'] != '') ? $_POST['city'] : '',
                  'address' => (isset($_POST['address']) && $_POST['address'] != '') ? $_POST['address'] : '',
                   'email' => (isset($_POST['email']) && $_POST['email'] != '') ? $_POST['email'] : '',
                    'password' => md5($_POST['password']),
                        "status" => 'A',

               
                'image' => $saved_location_file_name,
            );
            $result = $this->data_model->chkUser($_POST['email']);
            if (!empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'User already exists with this Email.Please try Again...';
                $data['content'] = json_encode($data);
            } else {
                $id = $this->data_model->addRecords($data_to_store, 'schools');
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Registration Successfully Completed';
                    $data['userid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }


    function login() {
        $_POST = json_decode(file_get_contents("php://input"), TRUE);

        // print_r($this->input->post());exit;
        // print_r(md5($_POST['password']));exit;      

        if (!empty($_POST['email']) && !empty($_POST['password'])) {
            $user = $this->data_model->checkUserLogin($_POST['email'], md5($_POST['password']));
            // echo $user['status'];exit;

            if (!empty($user)) {
                if ($user['status'] == 'A') {
                    $response = array('status' => 'success', 'content' => array('user_info' => $user));
                } else {
                    $response = array('status' => 'verify', 'content' => array('user_info' => $user,
                            'message' => 'Activate your account using verification code send to your registered mail..!'));
                }
            } else {
                $response = array('status' => 'fail', 'content' => 'Invalid User Id or Password');
            }
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }

    public function editProfile() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        
      // print_r($this->input->post());exit;

        if (!empty($_POST['user_id'])) {
            $userId = $_POST['user_id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/shop_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/shop_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
                
            }else {
                $saved_location_file_name = '';
            }
             

            $userAry = array(
                'institutename' => $_POST['institutename'],
                'mobile' => $_POST['mobile'],
                'landphone' => $_POST['landphone'],
                'register_as' => $_POST['register_as'],
                'city' => $_POST['city'],
                
                'address' => $_POST['address'],
                'image' => $saved_location_file_name,
                //"updated_date" => date('Y-m-d')
            );
            $where = array('id' => $userId);
            $id = $this->data_model->updateRecord($userAry, $where, 'schools');
            if ($id) {
                $userInfo = $this->data_model->getUserdetails($userId);
                $response = array('status' => 'success', 'content' => array('user_info' => $userInfo));
            } else {
                $response = array('status' => 'fail', 'content' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }

       public function galleryinsert(){
       

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
           
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                'image' => $saved_location_file_name,
                'image_tag' => (isset($_POST['image_tag']) && $_POST['image_tag'] != '') ? $_POST['image_tag'] : '',
                'image_description' => (isset($_POST['image_description']) && $_POST['image_description'] != '') ? $_POST['image_description'] : '',
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
             $id = $this->data_model->addRecords($data_to_store, 'gallery');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id; 
                    
                    
                    if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file = base_url() . 'uploads/brand_images/' . $img_name;
                        
                         $data_to_store = array(
                'galleryId' => $data['brandid'],
                'imagename' => $saved_location_file
              );
              
                           $this->data_model->addRecords($data_to_store, 'images');

                    }
                   
                }
            }
                    
                    
                    
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
     public function galleryaddmore(){
       

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];
if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file = base_url() . 'uploads/brand_images/' . $img_name;
                        
                         $data_to_store = array(
                'galleryId' => $_POST['galleryId'],
                'imagename' => $saved_location_file
              );
              
                           $this->data_model->addRecords($data_to_store, 'images');

                    }
                   
                }
            
                
                $data['auth'] = 'success';
                $data['message'] = 'data inserted successfully';
                $data['content'] = json_encode($data);
            } 
            
           
                
            
                    }
                    }
                    else  {
                $data['auth'] = 'fail';
                $data['message'] = 'error please provide valid data';
                $data['content'] = json_encode($data);
            } 
        $this->load->view('blank', $data);
    }

    public function galleryEdit() {

         $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
            
            
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                'image_tag' => $_POST['image_tag'],
                 'image_description' => $_POST['image_description'],

                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
                $id = $this->data_model->updateRecord($brandAry, $where, 'gallery');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'gallery');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);

    }
   

    public function getgallery() {


         $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getallgallery($userid, 'gallery');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'gallery_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'gallery_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);

    }
    public function getgallerydetails() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $galleryId = $_POST['galleryId'];
        
        // echo $_POST['type'];exit;
        if (!empty($galleryId)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getallgalleryDetails($galleryId, 'images');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'gallery_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'gallery_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removegallerydetails() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      //$branddata = $this->data_model->getBranddetails($brandid,'gallery');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removemultipleBrandRecords($brandid, 'images');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    public function removegallery() {

       $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'gallery');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'gallery');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    
    
    public function insertfaculty() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                'image' => $saved_location_file_name,
                'faculty_name' => (isset($_POST['faculty_name']) && $_POST['faculty_name'] != '') ? $_POST['faculty_name'] : '',
                'faculty_gender' => (isset($_POST['faculty_gender']) && $_POST['faculty_gender'] != '') ? $_POST['faculty_gender'] : '',
                'faculty_experience' => (isset($_POST['faculty_experience']) && $_POST['faculty_experience'] != '') ? $_POST['faculty_experience'] : '',
                'faculty_qualification' => (isset($_POST['faculty_qualification']) && $_POST['faculty_qualification'] != '') ? $_POST['faculty_qualification'] : '',
                        'subject_teaching' => (isset($_POST['subject_teaching']) && $_POST['subject_teaching'] != '') ? $_POST['subject_teaching'] : '',

              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
             $id = $this->data_model->addRecords($data_to_store, 'faculty');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }

    public function facultyEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
            
            
            
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                'faculty_name' => $_POST['faculty_name'],
                  'faculty_gender' => $_POST['faculty_gender'],
                'subject_teaching' => $_POST['subject_teaching'],
                'faculty_experience' => $_POST['faculty_experience'],
                'faculty_qualification' => $_POST['faculty_qualification'],
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
                $id = $this->data_model->updateRecord($brandAry, $where, 'faculty');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'faculty');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }

    public function getfaculty() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getfacultybyuserid($userid, 'faculty');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'faculty_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'faculty_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removefaculty() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'faculty');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'faculty');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }


    public function hostelinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'image_description' => (isset($_POST['image_description']) && $_POST['image_description'] != '') ? $_POST['image_description'] : '',
               'image_tag' => (isset($_POST['image_tag']) && $_POST['image_tag'] != '') ? $_POST['image_tag'] : '',

              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
             $id = $this->data_model->addRecords($data_to_store, 'hostel');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }

    public function hostelEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
            
            
            
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                 'image_description' => $_POST['image_description'],
                'image_tag' => $_POST['image_tag'],
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
                $id = $this->data_model->updateRecord($brandAry, $where, 'hostel');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'hostel');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }

    public function gethostel() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid, 'hostel');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'hostel_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'hostel_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    
    public function removehostel() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'hostel');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'hostel');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    public function resultsinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
               'year' => (isset($_POST['year']) && $_POST['year'] != '') ? $_POST['year'] : '',
               'pass' => (isset($_POST['pass']) && $_POST['pass'] != '') ? $_POST['pass'] : '',
               'totalstudents' => (isset($_POST['totalstudents']) && $_POST['totalstudents'] != '') ? $_POST['totalstudents'] : '',
               'Grade_A2' => (isset($_POST['Grade_A2']) && $_POST['Grade_A2'] != '') ? $_POST['Grade_A2'] : '',
               'Grade_B2' => (isset($_POST['Grade_B2']) && $_POST['Grade_B2'] != '') ? $_POST['Grade_B2'] : '',
               'Grade_C2' => (isset($_POST['Grade_C2']) && $_POST['Grade_C2'] != '') ? $_POST['Grade_C2'] : '',
               'Grade_D2' => (isset($_POST['Grade_D2']) && $_POST['Grade_D2'] != '') ? $_POST['Grade_D2'] : '',
               'Grade_A1' => (isset($_POST['Grade_A1']) && $_POST['Grade_A1'] != '') ? $_POST['Grade_A1'] : '',
               'Grade_B1' => (isset($_POST['Grade_B1']) && $_POST['Grade_B1'] != '') ? $_POST['Grade_B1'] : '',
               'Grade_C1' => (isset($_POST['Grade_C1']) && $_POST['Grade_C1'] != '') ? $_POST['Grade_C1'] : '',
               'Grade_D1' => (isset($_POST['Grade_D1']) && $_POST['Grade_D1'] != '') ? $_POST['Grade_D1'] : '',
               

              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
             $id = $this->data_model->addRecords($data_to_store, 'results');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }

    public function resultsEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
            
            
            
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                 'year' => $_POST['year'],
                'pass' => $_POST['pass'],
                'totalstudents' => $_POST['totalstudents'],
                'Grade_A1' => $_POST['Grade_A1'],
                'Grade_B1' => $_POST['Grade_B1'],
                'Grade_C1' => $_POST['Grade_C1'],
                'Grade_D1' => $_POST['Grade_D1'],
                'Grade_A2' => $_POST['Grade_A2'],
                'Grade_B2' => $_POST['Grade_B2'],
                'Grade_C2' => $_POST['Grade_C2'],
                'Grade_D2' => $_POST['Grade_D2'],

                //'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
              
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
                $id = $this->data_model->updateRecord($brandAry, $where, 'results');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'results');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }

    public function getresults() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getallgallery($userid, 'results');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'results_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'results_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removeresults() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'results');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'results');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    public function principlemessageinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'principle_name' => (isset($_POST['principle_name']) && $_POST['principle_name'] != '') ? $_POST['principle_name'] : '',
  'principle_qualification' => (isset($_POST['principle_qualification']) && $_POST['principle_qualification'] != '') ? $_POST['principle_qualification'] : '',
                 'gender' => (isset($_POST['gender']) && $_POST['gender'] != '') ? $_POST['gender'] : '',
                   'principle_Experience' => (isset($_POST['principle_Experience']) && $_POST['principle_Experience'] != '') ? $_POST['principle_Experience'] : '',


              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
             $id = $this->data_model->addRecords($data_to_store, 'principlemessage
');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }

    public function principlemessageEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                 'principle_name' => $_POST['principle_name'],
                'principle_qualification' => $_POST['principle_qualification'],
                'gender' => $_POST['gender'],
                'principle_Experience' => $_POST['principle_Experience'],
               
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'principlemessage');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'principlemessage');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }

    public function getprinciplemessage() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getSingleDataofUser($userid, 'principlemessage');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'hostel_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'hostel_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removeprinciplemessage() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'principlemessage');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'principlemessage');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    public function websiteinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     //'image' => $saved_location_file_name,
               'websiteLink' => (isset($_POST['websiteLink']) && $_POST['websiteLink'] != '') ? $_POST['websiteLink'] : '',
  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store, 'website');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function websiteEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                 'websiteLink' => $_POST['websiteLink'],
                
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'website');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'website');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    public function getwebsite() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model-> getSingleBrandofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid,'website');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'website_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'website_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removewebsite() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'website');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'website');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }

    
    public function youtubeinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     //'image' => $saved_location_file_name,
               'youtubeLink' => (isset($_POST['youtubeLink']) && $_POST['youtubeLink'] != '') ? $_POST['youtubeLink'] : '',
         'youtube_title' => (isset($_POST['youtube_title']) && $_POST['youtube_title'] != '') ? $_POST['youtube_title'] : '',

  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store,'youtube');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function youtubeEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                
               
                  'youtubeLink' => $_POST['youtubeLink'],
                   'youtube_title' => $_POST['youtube_title'],

                
                //'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'youtube');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'youtube');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    public function getyoutube() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid,'youtube');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'youtube_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'youtube_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removeyoutube() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'youtube');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'youtube');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    public function aboutUsinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'institute_description ' => (isset($_POST['institute_description']) && $_POST['institute_description'] != '') ? $_POST['institute_description'] : '',
                'institutename' => (isset($_POST['institutename']) && $_POST['institutename'] != '') ? $_POST['institutename'] : '',
  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store,'aboutUs');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function aboutUsEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                
               
                    'institutename' => $_POST['institutename'],
                  'institute_description' => $_POST['institute_description'],
                
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'aboutUs');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'aboutUs');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    public function getaboutUs() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getaboutUs($userid,'aboutUs');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'aboutUs_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'aboutUse_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function facilitiesinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'image_description' => (isset($_POST['image_description']) && $_POST['image_description'] != '') ? $_POST['image_description'] : '',
               'image_tag' => (isset($_POST['image_tag']) && $_POST['image_tag'] != '') ? $_POST['image_tag'] : '',
  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
       $id = $this->data_model->addRecords($data_to_store,'facilities');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function facilitiesEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
                
                
                  'image_description' => $_POST['image_description'],
                  'image_tag' => $_POST['image_tag'],
                
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'facilities');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'facilities');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    
    public function getfacilities() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getallgallery($userid,'facilities');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'facilities_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'facilities_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function removefacilities() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'facilities');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'facilities');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    public function institutemessage() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
               'message' => (isset($_POST['message']) && $_POST['message'] != '') ? $_POST['message'] : '',                
                "updated_date" => date('Y-m-d')
  
              );
            
           /* $result = $this->data_model->tocheckUserId($_POST['userid'],'institutemessage');
            if ($result) {
            
            $messagearray = array(
                'message' => $_POST['message']

                );
            $where = array('userid' => $_POST['userid']);
           
                 $id = $this->data_model->updateRecord($messagearray, $where, 'institutemessage');
               
            } else {*/
                
           $id = $this->data_model->addRecords($data_to_store,'institutemessage');
      //}
       if ($id > 0) {
                
                 $users = $this->data_model->getAllBrandsofUser($_POST['userid'],'devicetokens');

                  if(!empty($users) && isset($users))
                  {
                      foreach($users as $user){
                        if(!empty($user['device_token']) && isset($user['device_token'])){
                          $message = array('lastname'=>'Principal Message','message'=>$_POST['message'],'device_token'=>$user['device_token']);
                       //     $message = array('message'=>$_POST['message'],'device_token'=>$user['device_token']);

                          $this->android($message);
                        } 
                      }
                  }
                
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }

        }
        $this->load->view('blank', $data);
    }
    
    
    
    public function getdevicetoken() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        
        
       // print_r($_POST);exit;
        if (isset($_POST) && count($_POST) > 0) {

           
             $iddevice = $this->data_model->tocheckdevicetoken($_POST['device_token'],'devicetokens');
             if(!$iddevice)
             {
             
             //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
               'device_token' => (isset($_POST['device_token']) && $_POST['device_token'] != '') ? $_POST['device_token'] : '',                
  
              );
            

                
           $id = $this->data_model->addRecords($data_to_store,'devicetokens');
             
             
                
           
                
                if ($id > 0) {
                
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
            }
            else
            {
            
            $data['auth'] = 'fail';
                    $data['message'] = 'already_exsts';
                    $data['content'] = json_encode($data);
            }
        $this->load->view('blank', $data);
    }
    
    function android($message='') {
//echo '<pre>';print_r($message);exit;
   //echo $rids.'---'.$message;
   error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
   $key = 'AIzaSyD7M6ux_kkJdMBvkHT9axN9wuTsDQVheXo'; //Dev Server
   // Set POST variables
   $url = 'https://fcm.googleapis.com/fcm/send';

   $fields = array(
       'to' => $message['device_token'],
       'notification' => array("title" => $message['lastname'], "body"=>$message['message'])
   );
   
   /*  $fields = array (
            
            'data' => $message['message'],
            'registration_ids' => array (
                    $message['device_token']
            )
    );*/
       
 // echo '<pre>';print_r($fields);
   $headers = array(
       'Authorization: key=' . $key,
       'Content-Type: application/json'
   );
   //echo '<pre>';print_r($headers);exit;
   // Open connection
   $ch = curl_init();

   // Set the url, number of POST vars, POST data
   curl_setopt($ch, CURLOPT_URL, $url);

   curl_setopt($ch, CURLOPT_POST, true);
   curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0); 

   // Disabling SSL Certificate support temporarly
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
   curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4 );
   curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

   // Execute post
   $result = curl_exec($ch);
//print_r($result);exit;
   if ($result === FALSE) {
       die('Curl failed: ' . curl_error($ch));
   }

    // Close connection
    curl_close($ch);
//    print_r($result);exit;
    return $result;
    //exit;
}
    
    

      public function institutemessageEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
   
        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
               //echo $_POST['type']; exit;
                
                $brandAry = array(
                'message' => $_POST['message'],
                "updated_date" => date('Y-m-d')

                );
           
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
           
                 $id = $this->data_model->updateRecord($brandAry, $where, 'institutemessage');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'institutemessage');
                
                

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    public function removeinstitutemessage() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'institutemessage');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'institutemessage');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    public function getinstitutemessage() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        if (!empty($_POST['message_date']) && isset($_POST['message_date'])) {
            $message_date = $_POST['message_date'];
        } else {
            $message_date = '';
        }
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllmessagesofUser($userid,$message_date,'institutemessage');
                                 // $allBrands = $this->data_model->getSingleDataofUser($userid,'institutemessage');

            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'institutemessage_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'institutemessage_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function managementinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'mngmt_description' => (isset($_POST['mngmt_description']) && $_POST['mngmt_description'] != '') ? $_POST['mngmt_description'] : '',
               'chairmanname' => (isset($_POST['chairmanname']) && $_POST['chairmanname'] != '') ? $_POST['chairmanname'] : '',
               
  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store,'management');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    
      public function getmanagement() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid,'management');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'aboutUs_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'aboutUse_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }

    
    public function managementEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
               
                  'mngmt_description' => $_POST['mngmt_description'],
                   'chairmanname' => $_POST['chairmanname'],

                
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'management');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'management');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    
    
    public function Placementsinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'companyName' => (isset($_POST['companyName']) && $_POST['companyName'] != '') ? $_POST['companyName'] : '',
               'location' => (isset($_POST['location']) && $_POST['location'] != '') ? $_POST['location'] : '',
               'studentName' => (isset($_POST['studentName']) && $_POST['studentName'] != '') ? $_POST['studentName'] : '',
               'salaryPackage' => (isset($_POST['salaryPackage']) && $_POST['salaryPackage'] != '') ? $_POST['salaryPackage'] : '',
 
               
  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store,'Placements');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function insertcoursesOffered() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                    // 'image' => $saved_location_file_name,
               'seats' => (isset($_POST['seats']) && $_POST['seats'] != '') ? $_POST['seats'] : '',
               'coursename' => (isset($_POST['coursename']) && $_POST['coursename'] != '') ? $_POST['coursename'] : '',
               
               
               
  
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store,'coursesOffered');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function interResultsinsert() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
            
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                     'image' => $saved_location_file_name,
               'studentname' => (isset($_POST['studentname']) && $_POST['studentname'] != '') ? $_POST['studentname'] : '',
               'HTno' => (isset($_POST['HTno']) && $_POST['HTno'] != '') ? $_POST['HTno'] : '',
           'ExamName' => (isset($_POST['ExamName']) && $_POST['ExamName'] != '') ? $_POST['ExamName'] : '',
                      'rank' => (isset($_POST['rank']) && $_POST['rank'] != '') ? $_POST['rank'] : '',


               
               
  
              );
           
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
           $id = $this->data_model->addRecords($data_to_store,'interResults
');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    public function interResultsEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }

               
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
               
                  'studentname' => $_POST['studentname'],
                   'ExamName' => $_POST['ExamName'],
                  'HTno' => $_POST['HTno'],
                   'rank' => $_POST['rank'],


                   
                   
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'interResults');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'interResults');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    public function removeinterResults() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'interResults');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'interResults');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    public function getinterResults() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getresultsArray('interResults');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'interResults_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'interResults_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    
    
    
    
    public function getresultsbyexamname() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $ExamName = $_POST['ExamName'];
        
        // echo $_POST['type'];exit;
        if (!empty($ExamName)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getresultsbyexamname($ExamName,'interResults');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'interResults_examdetails' => $allBrands);
            } else {
                $response = array('status' => 'success', 'interResults_examdetails' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    
     public function coursesOfferedEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }

               
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
               
                  'seats' => $_POST['seats'],
                   'coursename' => $_POST['coursename'],
                   
                //'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'coursesOffered');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'coursesOffered');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    public function PlacementsEdit() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $saved_location_file_name = '';

    //echo $_POST['type']; exit;
        // print_r($_POST);exit;
        //echo '<pre>';print_r($this->input->post());exit;

        if (!empty($_POST['id'])) {
            $brandId = $_POST['id'];
            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            }
 
            
                       
                //echo $_POST['type']; exit;
                
                $brandAry = array(
               
                  'companyName' => $_POST['companyName'],
                   'location' => $_POST['location'],
                   'studentName' => $_POST['studentName'],
                   'salaryPackage' => $_POST['salaryPackage'],
                
                'image' => $saved_location_file_name,
              //  "status" => 'A',
              //  "updated_date" => date('Y-m-d')
             );
            
            
            $where = array('id' => $brandId);
           // $id = $this->data_model->updateRecord($brandAry, $where, 'brands');
            
               $id = $this->data_model->updateRecord($brandAry, $where, 'Placements');
            
            if ($id) {
                $brandInfo = $this->data_model->getBranddetails($brandId,'Placements');

                // $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
                
                $response = array('status' => 'success', 'message' => 'Data Updated Successfully..!');
            } else {
                $response = array('status' => 'fail', 'message' => 'Something went wrong..!');
            }
        } else {
            $response = array('status' => 'fail', 'message' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
     public function removePlacements() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'Placements');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'Placements');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    public function removecoursesOffered() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {

            // $brandInfoImage = $this->data_model->getBranddetails($brandid);
            // echo array('brand_info' => $brandInfoImage); exit;
      $branddata = $this->data_model->getBranddetails($brandid,'coursesOffered');
          //  $brandInfo = $this->data_model->removeBrandRecords($brandid,'brands');
          
            
              
          $brandInfo = $this->data_model->removeBrandRecords($brandid, 'coursesOffered');
          
               //  echo $brandInfo;exit;

      
            if ($brandInfo) {
                $response = array('status' => 'success', 'message' => 'Data Deleted successfully');
            } else {
                $response = array('status' => 'success', 'message' => 'Failed to delete data');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');

            $data['content'] = json_encode($response);
        }
        $this->load->view('blank', $data);
    }
    
    
    
    public function getcourcesoffered() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid,'coursesOffered');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'coursesOffered_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'coursesOffered_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    
    
   
public function getPlacements() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid,'Placements');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'Placements_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'Placements_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    public function jobsinsert(){
       

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }
           
                //echo $_POST['type']; exit;
                  $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                //'jobTitle' => $saved_location_file_name,
                'jobTitle' => (isset($_POST['jobTitle']) && $_POST['jobTitle'] != '') ? $_POST['jobTitle'] : '',
                'qualifications' => (isset($_POST['qualifications']) && $_POST['qualifications'] != '') ? $_POST['qualifications'] : '',
                'salary	' => (isset($_POST['salary']) && $_POST['salary'] != '') ? $_POST['salary'] : '',
                'Location' => (isset($_POST['Location']) && $_POST['Location'] != '') ? $_POST['Location'] : '',
                 'address' => (isset($_POST['address']) && $_POST['address'] != '') ? $_POST['address'] : '',
                'contactNumber' => (isset($_POST['contactNumber']) && $_POST['contactNumber'] != '') ? $_POST['contactNumber'] : '',
              );
            
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
            
                
                   $id = $this->data_model->addRecords($data_to_store, 'jobs');
            
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    
    public function getjobsdata() {


        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        
        // echo $_POST['type'];exit;
        if (!empty($userid)) {
          //  $allBrands = $this->data_model->getAllBrandsofUser($userid);
          
                 $allBrands = $this->data_model->getAllBrandsofUser($userid,'jobs');
            
            
            if (!empty($allBrands)) {
                $response = array('status' => 'success', 'jobs_info' => $allBrands);
            } else {
                $response = array('status' => 'success', 'jobs_info' => 'No Data Found');
            }
            $data['content'] = json_encode($response);
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
    

    public function getUserData() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $userid = $_POST['userid'];
        if (!empty($userid)) {
            $userInfo = $this->data_model->getUserdetails($userid);
            if (!empty($userInfo)) {
                $response = array('status' => 'success', 'content' => $userInfo);
            } else {
                $response = array('status' => 'success', 'content' => 'No Data Found');
            }
            $data['content'] = json_encode(array('response' => $response));
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }

    public function getBrandData() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $brandid = $_POST['id'];
        if (!empty($brandid)) {
            $brandInfo = $this->data_model->getBranddetails($brandid);
            if (!empty($brandInfo)) {
                $response = array('status' => 'success', 'content' => array('brand_info' => $brandInfo));
            } else {
                $response = array('status' => 'success', 'content' => array('brand_info' => 'No Data Found'));
            }
            $data['content'] = json_encode(array('response' => $response));
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $this->load->view('blank', $data);
    }
   
   


   
    public function getAllUsers() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $type = $_POST['type'];
        if (!empty($type)) {
            $allUsers = $this->data_model->getAllUsers($type);
            if (!empty($allUsers)) {
                $response = array('status' => 'success', 'content' => array('users_info' => $allUsers));
            } else {
                $response = array('status' => 'success', 'content' => array('users_info' => 'No Data Found'));
            }
            $data['content'] = json_encode(array('response' => $response));
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter type..!');
        }
        $this->load->view('blank', $data);
    }

    function getAllUsersFromCity() {
        $_POST = json_decode(file_get_contents("php://input"), TRUE);

        if (!empty($_POST['city']) && !empty($_POST['type'])) {
            $allUsers = $this->data_model->getAllUsersFromCity($_POST['city'], $_POST['type']);
            if (!empty($allUsers)) {
                $response = array('status' => 'success', 'content' => array('user_info' => $allUsers));
            } else {
                $response = array('status' => 'fail', 'content' => 'Invalid City or Type');
            }
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }

    function getAllCities() {
        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $allCities = $this->data_model->getAllCities();
        if (!empty($allCities)) {
            $response = array('status' => 'success', 'content' => array('user_info' => $allCities));
        } else {
            $response = array('status' => 'fail', 'content' => 'No cities found');
        }

        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }
    
    
    function getBusinessTypes() {
        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $allBusiness = $this->data_model->getBusinessTypes();
        if (!empty($allBusiness)) {
            $response = array('status' => 'success', 'content' => $allBusiness);
        } else {
            $response = array('status' => 'fail', 'content' => 'No business data found');
        }

        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    
    function getSpecialization() {
        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        $allSpecilization = $this->data_model-> getSpecialization();
        if (!empty($allSpecilization)) {
            $response = array('status' => 'success', 'content' => $allSpecilization);
        } else {
            $response = array('status' => 'fail', 'content' => 'No Specilization data found');
        }

        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
   
    
    function forgetPassword(){
        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if(!empty($_POST['email']) && !empty($_POST['username']) && !empty($_POST['mobile'])){
            $userData = $this->data_model->forgetPassword($_POST['mobile'], $_POST['username'], $_POST['email']);
            if(!empty($userData)){
                $response = array('status' => 'success', 'content' => array('user_info' => $userData['id']));
            }else{
                $response = array('status' => 'fail', 'content' => 'No Data found');
            }
        }else{
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }
    
    function changePassword(){
        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        //echo 'dadas';
        //print_r($_POST1);exit;
        if(!empty($_POST['userId']) && !empty($_POST['password'])){
            $pwdAry = array(
                'password' => md5($_POST['password'])
            );
            $where = array('id' => $_POST['userId']);
            $id = $this->data_model->updateRecord($pwdAry, $where, 'schools');
            if(!empty($id)){
                $response = array('status' => 'success', 'content' => 'success');
            }else{
                $response = array('status' => 'fail', 'content' => 'Failed to update.. please try again!..');
            }
        }else{
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }
    
    function Updatefoldertitle(){
        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        //echo 'dadas';
        //print_r($_POST1);exit;
        if(!empty($_POST['id']) && !empty($_POST['image_tag'])){
            $pwdAry = array(
                'image_tag' => ($_POST['image_tag'])
            );
            $where = array('id' => $_POST['id']);
            $id = $this->data_model->updateRecord($pwdAry, $where, 'gallery');
            if(!empty($id)){
                $response = array('status' => 'success', 'content' => 'success');
            }else{
                $response = array('status' => 'fail', 'content' => 'Failed to update.. please try again!..');
            }
        }else{
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode(array('response' => $response));
        $this->load->view('blank', $data);
    }
    
     public function somthingspecial() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {
           
          // echo $_POST['eventName']; exit;
         // print_r($_POST); exit;

            $data_to_store = array(
                'eventName' => (isset($_POST['eventName']) && $_POST['eventName'] != '') ? $_POST['eventName'] : '',
                'to_name' => (isset($_POST['to_name']) && $_POST['to_name'] != '') ? $_POST['to_name'] : '',
                'name_on_cake' => (isset($_POST['name_on_cake']) && $_POST['name_on_cake'] != '') ? $_POST['name_on_cake'] : '',
                'to_moblie' => (isset($_POST['to_moblie']) && $_POST['to_moblie'] != '') ? $_POST['to_moblie'] : '',
                'type' => (isset($_POST['type']) && $_POST['type'] != '') ? $_POST['type'] : '',
                'variety' => (isset($_POST['variety']) && $_POST['variety'] != '') ? $_POST['variety'] : '',
                'address' => (isset($_POST['address']) && $_POST['address'] != '') ? $_POST['address'] : '',
                'from_name' => (isset($_POST['from_name']) && $_POST['from_name'] != '') ? $_POST['from_name'] : '',
                'from_mobile' => (isset($_POST['from_mobile']) && $_POST['from_mobile'] != '') ? $_POST['from_mobile'] : '',
                'relation' => (isset($_POST['relation']) && $_POST['relation'] != '') ? $_POST['relation'] : '',
                'package' => (isset($_POST['package']) && $_POST['package'] != '') ? $_POST['package'] : '',
                'city' => (isset($_POST['city']) && $_POST['city'] != '') ? $_POST['city'] : '',
                "updated_date" => date('Y-m-d')
            );
            
            $message = "";
    //foreach ($_POST as $key => $value)
    //$message .= "Field ".htmlspecialchars($key)." is ".htmlspecialchars($value)."<br>";
/*  $message .= "eventName: ".htmlspecialchars($key)."\n"." to_name: ".htmlspecialchars($value)."\n"." name_on_cake: ".htmlspecialchars($value)."\n"." to_moblie: ".htmlspecialchars($value)."\n"." type: ".htmlspecialchars($value)."\n"." variety: ".htmlspecialchars($value)."\n"." address: ".htmlspecialchars($value)."\n"." from_name: ".htmlspecialchars($value)."\n"." from_mobile: ".htmlspecialchars($value)."\n"." relation: ".htmlspecialchars($value)."<br>";*/
   
        
         $message .= "eventName: ". $_POST['eventName']."\n";
     $message .= "to_name: ". $_POST['to_name']."\n";
     $message .= "name_on_cake: ". $_POST['name_on_cake']."\n";
      $message .= "to_moblie: ". $_POST['to_moblie']."\n";
     $message .= "type: ". $_POST['type']."\n";
     $message .= "variety: ". $_POST['variety']."\n";
     $message .= "address: ". $_POST['address']."\n";
     $message .= "from_name: ". $_POST['from_name']."\n";
      $message .= "from_mobile: ". $_POST['from_mobile']."\n";
     $message .= "relation: ". $_POST['relation']."\n";
     $message .= "package: ". $_POST['package']."\n";
     $message .= "city: ". $_POST['city']."\n";
    

    $result = mail('amelglobalitsolutions@gmail.com', 'SomethingSpecial', $message );
            
            if(!$result) {
             $response = array('status' => 'fail', 'content' => 'Please try after some time');
           
        } else {
            $response = array('status' => 'success', 'content' => 'Data Submitted  Successfully');
        }

        $data['content'] = json_encode(array('response' => $response));
            
            
        }
        $this->load->view('blank', $data);
    }

    function getstatusdetails() {
        $_POST = json_decode(file_get_contents("php://input"), TRUE);

        // print_r($this->input->post());exit;
        // print_r(md5($_POST['password']));exit;      

        if (!empty($_POST['name']) && !empty($_POST['mobile'])) {
            $user = $this->data_model-> getMudradetails($_POST['name'], $_POST['mobile']);
            // echo $user['status'];exit;

            if (!empty($user)) {
                if ($user['status'] == 'active') {
                    $response = array('status' => 'success', 'content' => $user);
                } else {
                    $response = array('status' => 'success', 'content' => 'Not Activcated');
                }
            } else {
                $response = array('status' => 'fail', 'content' => 'Invalid name or mobile');
            }
        } else {
            $response = array('status' => 'fail', 'content' => 'Please enter required data..!');
        }
        $data['content'] = json_encode($response);
        $this->load->view('blank', $data);
    }
    
    public function aboutus() {

        $_POST = json_decode(file_get_contents("php://input"), TRUE);
        if (isset($_POST) && count($_POST) > 0) {
            /* if (isset($_FILES) && !empty($_FILES)) {
              $profile_pic = $_FILES['image'];
              $img = $profile_pic;
              if (count($profile_pic) > 0) {
              $img_name = rand() . '.png';
              $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/shop_images/' . $img_name;
              $filename = $_FILES['image']['tmp_name'];
              move_uploaded_file($filename, $location);
              $saved_location_file_name = base_url() . 'uploads/shop_images/' . $img_name;
              }
              } */

            if (isset($_POST['image']) && !empty($_POST['image'])) {

                $files = $_POST['image'];

                if (count($files) > 0) {
                    foreach ($files as $file) {
                        $img_name = rand() . '.png';
                        $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/shop_images/' . $img_name;
                        $base64ImageString = str_replace(' ', '+', $file);

                        //Decode the image
                        $decodedImage = base64_decode($base64ImageString);
                        //Write to disk
                        file_put_contents($location, $decodedImage);

                        $saved_location_file_name = base_url() . 'uploads/shop_images/' . $img_name;
                    }
                    /*                     * *                      
                      $img_name = rand() . '.png';
                      $location = $_SERVER['DOCUMENT_ROOT'] . '/uploads/brand_images/' . $img_name;
                      $filename = $_FILES['image']['tmp_name'];
                      move_uploaded_file($filename, $location);
                      $saved_location_file_name = base_url() . 'uploads/brand_images/' . $img_name;

                     * * */
                }
            } else {
                $saved_location_file_name = '';
            }

            $data_to_store = array(
                'userid' => (isset($_POST['userid']) && $_POST['userid'] != '') ? $_POST['userid'] : '',
                'about_us' => (isset($_POST['about_us']) && $_POST['about_us'] != '') ? $_POST['about_us'] : '',
                'image' => $saved_location_file_name,
               
                "updated_date" => date('Y-m-d')
            );
            $result = $this->data_model->chkUserId($_POST['userid']);
            if (empty($result)) {
                $data['auth'] = 'fail';
                $data['message'] = 'user Not Exist';
                $data['content'] = json_encode($data);
            } else {
              
                 $id = $this->data_model->addRecords($data_to_store, 'aboutus');
                
                if ($id > 0) {
                    $data['auth'] = 'success';
                    $data['message'] = 'Data inserted Successfully..';
                    $data['brandid'] = $id;
                    $data['content'] = json_encode($data);
                } else {
                    $data['auth'] = 'fail';
                    $data['message'] = 'Unable to insert the data';
                    $data['content'] = json_encode($data);
                }
            }
        }
        $this->load->view('blank', $data);
    }
    
   
    
    
    
    

}
      
    