<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Remark extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('remark_model', 'admin_model', 'homework_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Remarks
     */
    public function manage_remarks() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['remarks'] = $this->remark_model->manage_remarks($data['user_data']['user_id'], $class_id, $section_id, $date);
        //echo $this->db->last_query();exit;
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/remark/manage_remarks');
        $this->load->view('admin/layouts/footer');
    }

    /* to export remarks data as csv */

    public function export_remarks_data() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $data['user_data'] = $this->session->userdata();
        $remarks = $this->remark_model->export_remarks_data($data['user_data']['user_id'], $class_id, $section_id, $date);
        $remark_headings[] = array('S.No', 'student Admission Number', 'Student Name', 'Class Name', 'Section Name', 'Remark Date', 'Remark Name');
        foreach ($remarks as $key => $remark):
            $remarkNew['S.No'] = ++$key;
            $remarkNew['student_admission_id'] = ucfirst($remark['student_admission_id']);
            $remarkNew['student_name'] = ucfirst($remark['student_name']);
            $remarkNew['class_name'] = ucfirst($remark['class_name']);
            $remarkNew['section_name'] = ucfirst($remark['section_name']);
            $remarkNew['remark_date'] = date('dS-F-Y', strtotime($remark['remark_date']));
            $remarkNew['remark_name'] = ucfirst($remark['remark_name']);
            array_push($remark_headings, $remarkNew);
        endforeach;
        $fileName = 'remarks' . rand() . '.csv';
        array_to_csv($remark_headings, $fileName);
    }

    /**
     * Add Remark
     */
    public function add_remark() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = array();
        $classes = $this->homework_model->getClasses($data['user_data']['user_id']);
        if (!empty($classes) && isset($classes)) {
            foreach ($classes as $cls):
                $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                if ($studentCount) {
                    $data['classes'][] = $cls;
                }
            endforeach;
        }
        if ($_POST) {
            $students = $this->input->post('student_admission_id');
            if (empty($students) && !isset($students)) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Please select at least one student to add remark'));
                redirect(base_url() . 'remark/add_remark');
            }
            foreach ($students as $student):
                $save_remark_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'student_admission_id' => $student,
                    'class_id' => $this->input->post('class_id'),
                    'section_id' => $this->input->post('section_id'),
                    'remark_name' => $this->input->post('remark_name'),
                    'remark_date' => $this->input->post('remark_date')
                );
                $this->global_model->save_data('student_remarks', $save_remark_data);
            endforeach;
            foreach ($students as $stnd):
                $studentData = $this->admin_model->getdetailsById("sch_admission_id", $stnd, "student_profile_info");
                if (!empty($studentData['student_mobile']) && (strlen($studentData['student_mobile']) == '10')) {
                    $r_date = date('dS-F-Y', strtotime($save_remark_data['remark_date']));
                    $r_message = 'Remark - ' . $r_date . "\r\n" . $save_remark_data['remark_name'] . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];
                    $this->sendsms->send_sms($studentData['student_mobile'], $r_message);
                }
            endforeach;
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Remark added Successfully'));
            redirect(base_url() . 'remark/manage_remarks?date=&class_id=&section_id=');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/remark/add_remark', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Remark
     * @param type $id
     */
    public function delete_remark($id = 0) {
        if ($id != '0') {
            // $delete_user = $this->section_model->delete_by('users', array('user_id' => $id));
            $delete_remark = $this->global_model->update_by('student_remarks', array('id' => $id), array('remark_status' => 'D'));
            if ($delete_remark) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Remark deleted Successfully'));
            }
            redirect(base_url() . 'remark/manage_remarks?date=&class_id=&section_id=');
        }
    }

    public function delete_multiple_remarks() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $r_id):
                $delete_remark = $this->global_model->update_by('student_remarks', array('id' => $r_id), array('remark_status' => 'D'));
            endforeach;
            if ($delete_remark) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Remarks deleted successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Remark
     * @param type $id
     */
    public function edit_remark($id = 0) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = array();
        $classes = $this->homework_model->getClasses($data['user_data']['user_id']);
        if (!empty($classes) && isset($classes)) {
            foreach ($classes as $cls):
                $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                if ($studentCount) {
                    $data['classes'][] = $cls;
                }
            endforeach;
        }
        if ($id != '0') {
            $data['remarks'] = $this->remark_model->edit_remark(array('ss.id' => $id));
            if ($data['remarks']) {
                $data['remarks'] = $data['remarks'][0];
            } else {
                $data['remarks'] = array();
            }
            //echo $this->db->last_query();exit;
            if ($_POST) {
                $save_remark_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'student_admission_id' => $this->input->post('student_admission_id'),
                    'class_id' => $this->input->post('class_id'),
                    'section_id' => $this->input->post('section_id'),
                    'remark_name' => $this->input->post('remark_name'),
                    'remark_date' => $this->input->post('remark_date')
                );
                $save_remark = $this->global_model->update_by('student_remarks', array('id' => $id), $save_remark_data);
                if ($save_remark) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Remark updated Successfully'));
                }

                redirect(base_url() . 'remark/manage_remarks?date=&class_id=&section_id=');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/remark/edit_remark', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
