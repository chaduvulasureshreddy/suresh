<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Fees extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('fees_model', 'admin_model', 'section_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Fees
     */
    public function getStudentFeeInfo($admission_id) {
        $data['user_data'] = $this->session->userdata();
        $data['feeInfo'] = $this->fees_model->getStudentFeeInfoByAdmission($admission_id, $data['user_data']['user_id']);
        $data['previousfeeInfo'] = $this->fees_model->getStudentPreviousFeeInfoByAdmission($admission_id);
        if ($_POST) {
            //echo '<pre>';print_r($_POST);exit;
            $b_amount = $this->input->post('balance_fee');
            $p_amount = $this->input->post('paid_fee') + $this->input->post('concession_amount');
            $paid_amount = $this->input->post('paid_fee');
            $admission_id = $this->input->post('student_admission_id');
            if ($p_amount > $b_amount) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Paying amount greater than balance amount!.. Please enter valid amount'));
                redirect(base_url() . 'fees/getStudentFeeInfo/' . $admission_id);
            }
            if ($paid_amount === '0') {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Please enter valid amount!..'));
                redirect(base_url() . 'fees/getStudentFeeInfo/' . $admission_id);
            }
            $fee_id = $data['feeInfo']['id'];
            $class_id = $this->input->post('class_id');
            $section_id = $this->input->post('section_id');
            $paid_amount = $data['feeInfo']['paid_amount'] + $this->input->post('paid_fee');
            $total_amount = $data['feeInfo']['total_amount'];
            $concession_amount = $data['feeInfo']['concession_amount'] + $this->input->post('concession_amount');
            $balance_amount = $total_amount - $paid_amount - $concession_amount;
            $save_fee_data = array(
                'paid_amount' => $paid_amount,
                'balance_amount' => $balance_amount,
                'concession_amount' => $concession_amount,
                'last_date_to_pay' => $this->input->post('last_date_to_pay')
            );
            $this->global_model->update_by('student_fee', array('student_admission_id' => $admission_id), $save_fee_data);

            $save_fee_term_data = array(
                'fee_id' => $fee_id,
                'fee_receipt_no' => $this->input->post('fee_receipt_no'),
                'term_paid_amt' => $this->input->post('paid_fee'),
                'term_paid_date' => $this->input->post('term_paid_date'),
                'fee_type' => $this->input->post('fee_type'),
                'userid' => $data['user_data']['user_id'],
                'student_admission_id' => $admission_id
            );
            $save_id = $this->global_model->save_data('student_fee_term', $save_fee_term_data);
            if ($save_id) {
                $paid_date = date('dS-F-Y', strtotime($this->input->post('term_paid_date')));
                $fee_receipt_no = trim($this->input->post('fee_receipt_no'));
                if ($balance_amount) {
                    $message = "Dear parent, you have paid fee amount " . $this->input->post('paid_fee') . 'Rs/- and receipt number is ' . $fee_receipt_no . ' for student ' . $data['feeInfo']['student_name'] . " on " . $paid_date . " And Due Amount is " . $balance_amount . " Rs/-" . "\r\n" . "FROM" . "\r\n" . $data['user_data']['institutename'];
                } else {
                    $message = "Dear parent, you have paid fee amount " . $this->input->post('paid_fee') . 'Rs/- and receipt number is ' . $fee_receipt_no . ' for student ' . $data['feeInfo']['student_name'] . " on " . $paid_date . " And You Have No Due Amount all fees amount cleared " . "\r\n" . "FROM" . "\r\n" . $data['user_data']['institutename'];
                }

                if (!empty($data['feeInfo']['student_mobile']) && (strlen($data['feeInfo']['student_mobile']) == '10'))
                    $this->sendsms->send_sms($data['feeInfo']['student_mobile'], $message);
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Fee Data Added Succesfully!..'));
                redirect(base_url() . 'fees/getStudentsData?class_id=' . $class_id . '&section_id=' . $section_id . '&student_name=');
            } else {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. Please try again'));
                redirect(base_url() . 'fees/getStudentsData?class_id=' . $class_id . '&section_id=' . $section_id . '&student_name=');
            }
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/student_fee');
        $this->load->view('admin/layouts/footer');
    }

    public function viewStudentFeeInfo($admission_id) {
        $data['user_data'] = $this->session->userdata();
        $data['feeInfo'] = $this->fees_model->getStudentFeeInfoByAdmission($admission_id, $data['user_data']['user_id']);
        $data['previousfeeInfo'] = $this->fees_model->getStudentPreviousFeeInfoByAdmission($admission_id);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/view_student_fee');
        $this->load->view('admin/layouts/footer');
    }

    public function downloadStudentFeeInfo() {
        $admission_number = trim($_GET['student_admission_id']);
        $data['user_data'] = $this->session->userdata();
        $data['feeInfo'] = $this->fees_model->getStudentFeeInfoByAdmission($admission_number, $data['user_data']['user_id']);
        $data['previousfeeInfo'] = $this->fees_model->getStudentPreviousFeeInfoByAdmission($admission_number);
        $html = $this->load->view('admin/fees/download_student_fee', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['feeInfo']['student_name']) . "_feeInfo.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

    public function getStudentsData() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['student_name'])) {
            $student_name = $_GET['student_name'];
        } else {
            $student_name = '';
        }
        if (isset($_GET['admissionnumber']) && !empty($_GET['admissionnumber'])) {
            $data['students'] = $this->fees_model->toGetStudentsByAdmissionId($_GET['admissionnumber'], $data['user_data']['user_id']);
        } else {
            $data['students'] = $this->fees_model->toGetStudentsByClassSectionName($class_id, $section_id, $data['user_data']['user_id'], $student_name);
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/manage_students');
        $this->load->view('admin/layouts/footer');
    }

    public function getStudentsPendingData() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $data['students'] = $this->fees_model->getStudentsPendingData($class_id, $section_id, $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/manage_pending_students');
        $this->load->view('admin/layouts/footer');
    }

    public function getStudentFeesData() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $data['students'] = $this->fees_model->toGetStudentsByClassSectionName($class_id, $section_id, $data['user_data']['user_id'], '');
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/manage_fee_students');
        $this->load->view('admin/layouts/footer');
    }

    public function add_fee() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/add_fee');
        $this->load->view('admin/layouts/footer');
    }

    public function search_student() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/search_student');
        $this->load->view('admin/layouts/footer');
    }

    public function pending_fee() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/pending_fee');
        $this->load->view('admin/layouts/footer');
    }

    public function pending_fee_amount() {
        $data['user_data'] = $this->session->userdata();
        $sections = $this->section_model->get_sections('', $data['user_data']['user_id']);
        if (isset($sections) && !empty($sections)) {
            foreach ($sections as $key => $secs):
                $res = $this->fees_model->toGetPendingFeesByClassAndSection($secs['class_id'], $secs['id']);
                $sections[$key]['balance_amount'] = $res[0]['balance_amount'];
                $sections[$key]['paid_amount'] = $res[0]['paid_amount'];
                $sections[$key]['total_amount'] = $res[0]['total_amount'];
                $sections[$key]['concession_amount'] = $res[0]['concession_amount'];
            endforeach;
            $data['feeamounts'] = $sections;
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/fees/pending_fee_amount');
            $this->load->view('admin/layouts/footer');
        } else {
            echo 'fail';
            exit;
        }
    }

    public function paid_fee_amount() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = '';
        }
        if (!empty($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            $end_date = '';
        }
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $data['students'] = $this->fees_model->paid_fee_amount($data['user_data']['user_id'], $class_id, $section_id, $start_date, $end_date);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/fees/paid_fee_amount');
        $this->load->view('admin/layouts/footer');
    }

    /* to export pending fee amounts as csv */

    public function export_pendingfees_data() {
        $data['user_data'] = $this->session->userdata();
        $sections = $this->section_model->get_sections('', $data['user_data']['user_id']);
        $feeamount_headings[] = array('S.No', 'Class Name', 'Section Name', 'Total Amount', 'Paid Amount', 'Pending Amount', 'Concession Amount');
        if (isset($sections) && !empty($sections)) {
            foreach ($sections as $key => $secs):
                $res = $this->fees_model->export_pendingfees_data($secs['class_id'], $secs['id']);
                $sections[$key]['balance_amount'] = $res[0]['balance_amount'];
                $sections[$key]['paid_amount'] = $res[0]['paid_amount'];
                $sections[$key]['total_amount'] = $res[0]['total_amount'];
                $sections[$key]['concession_amount'] = $res[0]['concession_amount'];
            endforeach;
            $feeamounts = $sections;
            foreach ($feeamounts as $key => $fee):
                $feeNew['S.No'] = ++$key;
                $feeNew['class_name'] = ucfirst($fee['class_name']);
                $feeNew['section_name'] = ucfirst($fee['section_name']);
                if ($fee['total_amount']) {
                    $feeNew['total_amount'] = ucfirst('Rs: ' . $fee['total_amount'] . ' /-');
                } else {
                    $feeNew['total_amount'] = '--';
                }
                if ($fee['paid_amount']) {
                    $feeNew['paid_amount'] = ucfirst('Rs: ' . $fee['paid_amount'] . ' /-');
                } else {
                    $feeNew['paid_amount'] = '--';
                }
                if ($fee['balance_amount']) {
                    $feeNew['balance_amount'] = ucfirst('Rs: ' . $fee['balance_amount'] . ' /-');
                } else {
                    $feeNew['balance_amount'] = '--';
                }
                if ($fee['concession_amount']) {
                    $feeNew['concession_amount'] = ucfirst('Rs: ' . $fee['concession_amount'] . ' /-');
                } else {
                    $feeNew['concession_amount'] = '--';
                }
                array_push($feeamount_headings, $feeNew);
            endforeach;
            $fileName = 'TotalPendingFeeAmounts' . rand() . '.csv';
            array_to_csv($feeamount_headings, $fileName);
        } else {
            $feeNew['S.No'] = 'No Data Found';
            array_push($feeamount_headings, $feeNew);
            $fileName = 'TotalPendingFeeAmounts' . rand() . '.csv';
            array_to_csv($feeamount_headings, $fileName);
        }
    }

    public function exportPendingfeesdataByClass() {
        $data['user_data'] = $this->session->userdata();
        $students = $this->fees_model->exportPendingfeesdataByClass($_GET['class_id'], $_GET['section_id'], $data['user_data']['user_id'], $_GET['pending']);
        $student_headings[] = array('S.No', 'Student Admission number', 'Student Name', 'Class Name', 'Section Name', 'Total Amount', 'Paid Amount', 'Pending Amount', 'Concession Amount');
        if (!empty($students)) {
            foreach ($students as $key => $student):
                $studentNew['S.No'] = ++$key;
                $studentNew['student_admission_id'] = ucfirst($student['student_admission_id']);
                $studentNew['student_name'] = ucfirst($student['student_name']);
                $studentNew['class_name'] = ucfirst($student['class_name']);
                $studentNew['section_name'] = ucfirst($student['section_name']);
                if ($student['total_amount']) {
                    $studentNew['total_amount'] = ucfirst('Rs: ' . $student['total_amount'] . ' /-');
                } else {
                    $studentNew['total_amount'] = '--';
                }
                if ($student['paid_amount']) {
                    $studentNew['paid_amount'] = ucfirst('Rs: ' . $student['paid_amount'] . ' /-');
                } else {
                    $studentNew['paid_amount'] = '--';
                }
                if ($student['balance_amount']) {
                    $studentNew['balance_amount'] = ucfirst('Rs: ' . $student['balance_amount'] . ' /-');
                } else {
                    $studentNew['balance_amount'] = '--';
                }
                if ($student['concession_amount']) {
                    $studentNew['concession_amount'] = ucfirst('Rs: ' . $student['concession_amount'] . ' /-');
                } else {
                    $studentNew['concession_amount'] = '--';
                }
                array_push($student_headings, $studentNew);
            endforeach;
        } else {
            $studentNew['S.No'] = 'No Data Found';
            array_push($student_headings, $studentNew);
        }
        $fileName = 'PendingFeeAmountsByClass' . rand() . '.csv';
        array_to_csv($student_headings, $fileName);
    }

    /* export paid fee amount */

    public function export_paid_fee_amount() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['start_date'])) {
            $start_date = $_GET['start_date'];
        } else {
            $start_date = '';
        }
        if (!empty($_GET['end_date'])) {
            $end_date = $_GET['end_date'];
        } else {
            $end_date = '';
        }
        $students = $this->fees_model->paid_fee_amount($data['user_data']['user_id'], $class_id, $section_id, $start_date, $end_date);
        $student_headings[] = array('S.No', 'Student Admission number', 'Student Name', 'Father Name', 'Class Name', 'Section Name', 'Paid Amount', 'Paid Date');
        if (!empty($students)) {
            foreach ($students as $key => $student):
                $studentNew['S.No'] = ++$key;
                $studentNew['student_admission_id'] = ucfirst($student['student_admission_id']);
                $studentNew['student_name'] = ucfirst($student['student_name']);
                $studentNew['student_father_name'] = ucfirst($student['student_father_name']);
                $studentNew['class_name'] = ucfirst($student['class_name']);
                $studentNew['section_name'] = ucfirst($student['section_name']);
                $studentNew['term_paid_amt'] = 'Rs: ' . $student['term_paid_amt'] . ' /-';
                $studentNew['term_paid_date'] = date('dS-F-Y', strtotime($student['term_paid_date']));
                array_push($student_headings, $studentNew);
            endforeach;
        } else {
            $studentNew['S.No'] = 'No Data Found';
            array_push($student_headings, $studentNew);
        }
        $fileName = 'PaidFeeAmountsByDate' . rand() . '.csv';
        array_to_csv($student_headings, $fileName);
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
