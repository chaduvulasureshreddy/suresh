<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Homework extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('homework_model', 'admin_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Homework
     */
    public function manage_home_works() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['homeworks'] = $this->homework_model->manage_home_works($data['user_data']['user_id'], $class_id, $section_id, $date);
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/homework/manage_home_works');
        $this->load->view('admin/layouts/footer');
    }

    /* to export homeworks data To CSV */

    public function export_homework_data() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $data['user_data'] = $this->session->userdata();
        $homeworks = $this->homework_model->export_homework_data($data['user_data']['user_id'], $class_id, $section_id, $date);
        $homework_headings[] = array('S.No', 'Class Name', 'Section Name', 'Homework Date', 'Subject', 'Homework');
        foreach ($homeworks as $key => $homework):
            $homeworkNew['S.No'] = ++$key;
            $homeworkNew['class_name'] = ucfirst($homework['class_name']);
            $homeworkNew['section_name'] = ucfirst($homework['section_name']);
            $homeworkNew['home_work_date'] = date('dS-F-Y', strtotime($homework['home_work_date']));
            $homeworkNew['home_work_subject'] = ucfirst($homework['home_work_subject']);
            $homeworkNew['home_work_name'] = ucfirst($homework['home_work_name']);
            array_push($homework_headings, $homeworkNew);
        endforeach;
        $fileName = 'homworks' . rand() . '.csv';
        array_to_csv($homework_headings, $fileName);
    }

    /**
     * Add Homework
     */
    /* public function add_home_work() {
      $data['user_data'] = $this->session->userdata();
      $data['classes'] = array();
      $classes = $this->homework_model->getClasses();
      if (!empty($classes) && isset($classes)) {
      foreach ($classes as $cls):
      $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
      if ($studentCount) {
      $data['classes'][] = $cls;
      }
      endforeach;
      }
      if ($_POST) {
      $class_id = $this->input->post('class_id');
      $section_id = $this->input->post('section_id');
      $save_homework_data = array(
      'userid' => $data['user_data']['user_id'],
      'class_id' => $class_id,
      'section_id' => $section_id,
      'home_work_subject' => $this->input->post('home_work_subject'),
      'home_work_name' => $this->input->post('home_work_name'),
      'home_work_date' => $this->input->post('home_work_date')
      );
      $this->global_model->save_data('student_home_work', $save_homework_data);

      $result = $this->admin_model->getStudentsInfo($data['user_data']['user_id'], $class_id, $section_id);
      $rand = time();
      $fileName = 'homeworks_' . $rand . '.csv';

      file_put_contents(FCPATH . "uploads/csv/homeworks/" . $fileName, array_to_csv($result));
      $my_file = $fileName;
      $my_path = FCPATH . "uploads/csv/homeworks/";
      $my_name = $data['user_data']['institutename'];
      $my_mail = $data['user_data']['email'];
      $my_replyto = $data['user_data']['email'];
      $my_subject = $this->input->post('home_work_subject');
      $my_message = $this->input->post('home_work_name');
      $this->mail_attachment($my_file, $my_path, "ali12riyaz@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);

      $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Homwork added successfully'));
      redirect(base_url() . 'homework/manage_home_works?date=&class_id=&section_id=');
      }
      $this->load->view('admin/layouts/header', $data);
      $this->load->view('admin/layouts/sidebar', $data);
      $this->load->view('admin/homework/add_home_work', $data);
      $this->load->view('admin/layouts/footer');
      } */
    public function add_home_work() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = array();
        $classes = $this->homework_model->getClasses($data['user_data']['user_id']);
        if (!empty($classes) && isset($classes)) {
            foreach ($classes as $cls):
                $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                if ($studentCount) {
                    $data['classes'][] = $cls;
                }
            endforeach;
        }
        if ($_POST) {
            $class_id = $this->input->post('class_id');
            $section_id = $this->input->post('section_id');
            $getData = $this->input->post();
            $save_homework_data = array(
                'userid' => $data['user_data']['user_id'],
                'class_id' => $class_id,
                'section_id' => $section_id,
                'home_work_subject' => isset($getData['home_work_subject']) ? strtoupper($getData['home_work_subject']) : 'Homework',
                'home_work_name' => $this->input->post('home_work_name'),
                'home_work_date' => $this->input->post('home_work_date')
            );
            $this->global_model->save_data('student_home_work', $save_homework_data);
            $classes = $this->admin_model->toGetClassName($class_id);
            $sectons = $this->admin_model->toGetSectionName($section_id);
            $students = $this->admin_model->getStudentsInfo($data['user_data']['user_id'], $class_id, $section_id);
            if (!empty($students) && isset($students)) {
                $hw_date = date('dS-F-Y', strtotime($save_homework_data['home_work_date']));
                $hwmessage = "Homework for " . $sectons['section_name'] . "in" . $classes['class_name'] . "- " . $hw_date . "\r\n" . $save_homework_data['home_work_name'] . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];

                foreach ($students as $student):
                    if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                        $this->sendsms->send_sms($student['student_mobile'], $hwmessage);
                    }
                endforeach;
            }
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Homwork added successfully'));
            redirect(base_url() . 'homework/manage_home_works?date=&class_id=&section_id=');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/homework/add_home_work', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Homework
     * @param type $id
     */
    public function delete_home_work($id = 0) {
        if ($id != '0') {
            // $delete_homework = $this->section_model->delete_by('users', array('user_id' => $id));
            $delete_homework = $this->global_model->update_by('student_home_work', array('id' => $id), array('home_work_status' => 'D'));
            if ($delete_homework) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Homework deleted Successfully'));
            }
            redirect(base_url() . 'homework/manage_home_works?date=&class_id=&section_id=');
        }
    }

    public function delete_multiple_homeworks() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $hw_id):
                $delete_student = $this->global_model->update_by('student_home_work', array('id' => $hw_id), array('home_work_status' => 'D'));
            endforeach;
            if ($delete_student) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Homeworks deleted successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Homework
     * @param type $id
     */
    public function edit_home_work($id = 0) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = array();
        $classes = $this->homework_model->getClasses($data['user_data']['user_id']);
        if (!empty($classes) && isset($classes)) {
            foreach ($classes as $cls):
                $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                if ($studentCount) {
                    $data['classes'][] = $cls;
                }
            endforeach;
        }
        if ($id != '0') {
            $data['homeworks'] = $this->homework_model->edit_home_work(array('ss.id' => $id));
            if ($data['homeworks']) {
                $data['homeworks'] = $data['homeworks'][0];
            } else {
                $data['homeworks'] = array();
            }

            if ($_POST) {
                $class_id = $this->input->post('class_id');
                $section_id = $this->input->post('section_id');
                $getData = $this->input->post();
                $save_homework_data = array(
                    'class_id' => $class_id,
                    'section_id' => $section_id,
                    'home_work_subject' => isset($getData['home_work_subject']) ? strtoupper($getData['home_work_subject']) : 'Homework',
                    'home_work_name' => $this->input->post('home_work_name'),
                    'home_work_date' => $this->input->post('home_work_date')
                );
                $this->global_model->update_by('student_home_work', array('id' => $id), $save_homework_data);

                /* $result = $this->admin_model->getStudentsInfo($data['user_data']['user_id'], $class_id, $section_id);
                  $rand = time();
                  $fileName = 'homeworks_' . $rand . '.csv';
                  file_put_contents(FCPATH . "uploads/csv/homeworks/" . $fileName, array_to_csv($result));
                  $my_file = $fileName;
                  $my_path = FCPATH . "uploads/csv/homeworks/";
                  $my_name = $data['user_data']['institutename'];
                  $my_mail = $data['user_data']['email'];
                  $my_replyto = $data['user_data']['email'];
                  $my_subject = $this->input->post('home_work_subject');
                  $my_message = $this->input->post('home_work_name');
                  $this->mail_attachment($my_file, $my_path, "ali12riyaz@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message); */

                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Homework updated Successfully'));
                redirect(base_url() . 'homework/manage_home_works?date=&class_id=&section_id=');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/homework/edit_home_work', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    public function toGetSectionsByClass() {
        $class_id = $this->input->post('class_id');
        $where = array('class_id' => $class_id, 'status' => 'A');
        $sections = $this->homework_model->toGetSectionsByClass($where);
        if (!empty($sections) && isset($sections)) {
            foreach ($sections as $sec):
                $studentCount = $this->homework_model->toCheckStudentsWithSection($sec['id']);
                if ($studentCount) {
                    $data['sections'][] = $sec;
                }
            endforeach;
        }
        if (!empty($data['sections']) && isset($data['sections'])) {
            echo '<option value="">Select Section</option>';
            foreach ($data['sections'] as $sec):
                echo '<option value="' . $sec['id'] . '">' . $sec['section_name'] . '</option>';
            endforeach;
            exit;
        } else {
            echo "fail";
            exit;
        }
    }

    public function toGetSubjectsByClass() {
        $class_id = $this->input->post('class_id');
        $where = array('class_id' => $class_id);
        $subjects = $this->homework_model->toGetSubjectsByClass($where);
        if (!empty($subjects) && isset($subjects)) {
            echo '<option value="">Select Subjet</option>';
            foreach ($subjects as $sec):
                echo '<option value="' . $sec['id'] . '">' . $sec['subject_name'] . '</option>';
            endforeach;
            exit;
        } else {
            echo "fail";
            exit;
        }
    }

    function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message1) {

        $file = $path . $filename;
        $file_size = filesize($file);
        $handle = fopen($file, "r");
        $content = fread($handle, $file_size);
        fclose($handle);
        $content = chunk_split(base64_encode($content));
        $uid = md5(uniqid(time()));
        $name = basename($file);

        $eol = PHP_EOL;

// Basic headers
        $header = "From: " . $from_name . " <" . $from_mail . ">" . $eol;
        $header .= "Reply-To: " . $replyto . $eol;
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"";

// Put everything else in $message
        $message = "--" . $uid . $eol;
        $message .= "Content-Type: text/html; charset=ISO-8859-1" . $eol;
        $message .= "Content-Transfer-Encoding: 8bit" . $eol . $eol;
        $message .= $message1 . $eol;
        $message .= "--" . $uid . $eol;
        $message .= "Content-Type: application/pdf; name=\"" . $filename . "\"" . $eol;
        $message .= "Content-Transfer-Encoding: base64" . $eol;
        $message .= "Content-Disposition: attachment; filename=\"" . $filename . "\"" . $eol;
        $message .= $content . $eol;
        $message .= "--" . $uid . "--";

        if (mail($mailto, $subject, $message, $header)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
