<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Subject extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('subject_model', 'admin_model'));
        $this->load->library('session');
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Subjects
     */
    public function manage_subjects() {
        $data['user_data'] = $this->session->userdata();
        $data['subjects'] = $this->subject_model->get_subjects('', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/subjects/manage_subjects');
        $this->load->view('admin/layouts/footer');
    }

    /* to export subjects data */

    public function export_subjects_data() {
        $data['user_data'] = $this->session->userdata();
        $subjects = $this->subject_model->export_subjects_data($data['user_data']['user_id']);
        $subject_headings[] = array('S.No', 'Class Name', 'Subject Name');
        foreach ($subjects as $key => $subject):
            $subjectNew['S.No'] = ++$key;
            $subjectNew['class_name'] = ucfirst($subject['class_name']);
            $subjectNew['subject_name'] = ucfirst($subject['subject_name']);
            array_push($subject_headings, $subjectNew);
        endforeach;
        $fileName = 'Subjects' . rand() . '.csv';
        array_to_csv($subject_headings, $fileName);
    }

    /**
     * Add Subject
     */
    public function add_subject() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->global_model->get_all_classes('student_classes', $data['user_data']['user_id']);
        if ($_POST) {
            $class_id = $this->input->post('class_id');
            $subject_name = trim($this->input->post('subject_name'));
            $subjectName = $this->subject_model->toCheckSubjectName($subject_name, $class_id, '', 'student_class_subjects', $data['user_data']['user_id']);
            if (!empty($subjectName) && isset($subjectName)) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Subject is already exist with this name!.. please try with another name'));
                redirect(base_url() . 'subject/add_subject');
            }
            $save_subject_data = array(
                'userid' => $data['user_data']['user_id'],
                'class_id' => $class_id,
                'subject_name' => $subject_name,
                'subject_status' => $this->input->post('subject_status')
            );
            $this->global_model->save_data('student_class_subjects', $save_subject_data);
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Subject added Successfully'));
            redirect(base_url() . 'subject/manage_subjects');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/subjects/add_subject', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Subject
     * @param type $id
     */
    public function delete_subject($id = 0) {
        if ($id != '0') {
            $students = $this->subject_model->toCheckStudentsWithThisSubject($id);
            if ($students > 0) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Subject!..Having Students data with this subject, Please delete students under this subject before delete the subject!.'));
                redirect(base_url() . 'subject/manage_subjects');
            }
            $delete_user = $this->global_model->update_by('student_class_subjects', array('id' => $id), array('subject_status' => 'D'));
            if ($delete_user) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Subject deleted Successfully'));
            }
            redirect(base_url() . 'subject/manage_subjects');
        }
    }

    public function delete_multiple_subjects() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $sec_id):
                $students = $this->subject_model->toCheckStudentsWithThisSubject($sec_id);
                if ($students > 0) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Subject!..Having Exams data with this subject.'));
                    echo "exist";
                    exit;
                }
            endforeach;
            foreach ($ids as $sec_id):
                $delete_student = $this->global_model->update_by('student_class_subjects', array('id' => $sec_id), array('subject_status' => 'D'));
            endforeach;
            if ($delete_student) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Subject deleted Successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Subject
     * @param type $id
     */
    public function edit_subject($id = 0) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->global_model->get_all_classes('student_classes',$data['user_data']['user_id']);
        if ($id != '0') {
            $data['subjects'] = $this->subject_model->get_subjects(array('ss.id' => $id), $data['user_data']['user_id']);
            if ($data['subjects']) {
                $data['subjects'] = $data['subjects'][0];
            } else {
                $data['subjects'] = array();
            }

            if ($_POST) {
                $class_id = $this->input->post('class_id');
                $subject_name = trim($this->input->post('subject_name'));
                $subjectName = $this->subject_model->toCheckSubjectName($subject_name, $class_id, $id, 'student_class_subjects', $data['user_data']['user_id']);
                if (!empty($subjectName) && isset($subjectName)) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Subject is already exist with this name!.. please try with another name'));
                    redirect(base_url() . 'subject/edit_subject/' . $id);
                }
                $save_subject_data = array(
                    'class_id' => $class_id,
                    'subject_name' => $subject_name,
                    'subject_status' => $this->input->post('subject_status')
                );
                $save_subject = $this->global_model->update_by('student_class_subjects', array('id' => $id), $save_subject_data);
                if ($save_subject) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Subject updated Successfully'));
                }

                redirect(base_url() . 'subject/manage_subjects');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/subjects/edit_subject', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* To Check Section Name exist or not by using Name */

    public function toCheckSubjectName() {
        $subject_name = trim($this->input->post('subject_name'));
        $class_id = $this->input->post('class_id');
        $data['user_data'] = $this->session->userdata();
        $subject_id = $this->input->post('subject_id');
        if (!empty($subject_name)) {
            $result = $this->subject_model->toCheckSubjectName($subject_name, $class_id, $subject_id, 'student_class_subjects', $data['user_data']['user_id']);
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
