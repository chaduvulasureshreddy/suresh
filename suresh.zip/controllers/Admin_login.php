<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin_login extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->helper('csv');
        $this->load->model(array('admin_model'));
        $this->load->library('session');
        if ($this->session->userdata('user_id')) {
            redirect(base_url() . 'dashboard');
        }
    }

    /**
     * Login
     */
    public function index() {
        if (!empty($_POST) && $_POST['email'] != '' && $_POST['password'] != '') {
            $check_user = $this->admin_model->check_login($_POST);
            if ($check_user) {
                $session_data = array(
                    'user_id' => $check_user->id,
                    'institutename' => $check_user->institutename,
                    'email' => $check_user->email,
                    'profile_pic' => $check_user->image,
                    'last_name' => 'Global',
                    'first_name' => 'Amel'
                );

                $this->session->set_userdata($session_data);
                redirect(base_url() . 'dashboard');
            } else {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Invalid Login'));
                redirect(base_url() . 'admin_login');
            }
        }
        $this->load->view('admin/layouts/outside_header');
        $this->load->view('admin/login');
        $this->load->view('admin/layouts/outside_footer');
    }

    public function csvConvert() {
        $result = $this->admin_model->getStudentsInfo();
        $rand = time();
        $fileName = 'studentInfo_' . $rand . '.csv';
        file_put_contents("/var/www/html/school_website/uploads/csv/" . $fileName, array_to_csv($result));
        $this->toSendMail($fileName);
    }

    public function toSendMail($fileName) {
//        echo $fileName;exit;
        if (isset($fileName) && !empty($fileName)) {

            // config smtp
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://smtp.googlemail.com',
                'smtp_port' => 465,
                'smtp_user' => 'aaran.randy@gmail.com',
                'smtp_pass' => 'randy2015',
                'mailtype' => 'html',
                'charset' => 'iso-8859-1'
            );

            $data = array(
                'to' => 'chaitu.kuru@gmail.com',
                'from' => "noreply@balloonzy.com",
                'subject' => "Balloon is opened",
                'message' => "Your Balloon is opened by ",
                'attachment' => "/var/www/html/school_website/uploads/csv/" . $fileName
            );
            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");


            // Set to, from, message, etc.
            $this->email->to($data['to']);
            if (isset($data['from']) && !empty($data['from'])) {
                $this->email->from($data['from']);
            }
            if (isset($data['bcc']) && !empty($data['bcc'])) {
                $this->email->bcc($data['bcc']);
            }
            if (isset($data['cc']) && !empty($data['cc'])) {
                $this->email->cc($data['cc']);
            }
            $this->email->subject($data['subject']);
            $this->email->message($data['message']);
            if (isset($data['attachment']) && !empty($data['attachment'])) {
                $this->email->attach($data['attachment']);
            }
//            echo '<pre>';print_r($this->email);exit;
            return $this->email->send();
        } else {
            echo 'fail';
            exit;
        }
    }

    public function toSendMailNew() {

        $data = array(
            'to' => 'chaitu.kuru@gmail.com',
            'from' => "noreply@balloonzy.com",
            'subject' => "Balloon is opened",
            'message' => "Your Balloon is opened by chaitu"
        );
        if (isset($data) && !empty($data)) {
// config smtp
            $config = Array(
                'protocol' => 'smtp',
                'smtp_host' => 'ssl://smtp.googlemail.com',
                'smtp_port' => 465,
                'smtp_user' => 'aaran.randy@gmail.com',
                'smtp_pass' => 'randy2015',
                'mailtype' => 'html',
                'charset' => 'iso-8859-1'
            );

            $this->load->library('email', $config);
            $this->email->set_newline("\r\n");

// Set to, from, message, etc.
            $this->email->to($data['to']);
            if (isset($data['from']) && !empty($data['from'])) {
                $this->email->from($data['from']);
            }
            if (isset($data['bcc']) && !empty($data['bcc'])) {
                $this->email->bcc($data['bcc']);
            }
            if (isset($data['cc']) && !empty($data['cc'])) {
                $this->email->cc($data['cc']);
            }
            $this->email->subject($data['subject']);
            $this->email->message($data['message']);
            if (isset($data['attachment']) && !empty($data['attachment'])) {
                $this->email->attach($data['attachment']);
            }
            $success = $this->email->send();
            if ($success) {
                echo "success";
            } else {
                echo "fail";
            }
        } else {
            return 0;
        }
    }

    public function emailNew() {
        $my_file = "studentInfo_1497616171.csv";
        $my_path = $_SERVER['DOCUMENT_ROOT'] . "/uploads/csv/";
        $my_name = "school";
        $my_mail = "krishna.kurivella@gmail.com";
        $my_replyto = "krishna.kurivella@gmail.com";
        $my_subject = "Bulk Message Details";
        $my_message = "Hi Riyaz,\r\n Please find the message.\r\n\r\n";
        $this->mail_attachment($my_file, $my_path, "chaitu.kuru@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
    }

    function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message1) {

        $file = $path . $filename;
        $file_size = filesize($file);
        $handle = fopen($file, "r");
        $content = fread($handle, $file_size);
        fclose($handle);
        $content = chunk_split(base64_encode($content));
        $uid = md5(uniqid(time()));
        $name = basename($file);

        $eol = PHP_EOL;

// Basic headers
        $header = "From: " . $from_name . " <" . $from_mail . ">" . $eol;
        $header .= "Reply-To: " . $replyto . $eol;
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"";

// Put everything else in $message
        $message = "--" . $uid . $eol;
        $message .= "Content-Type: text/html; charset=ISO-8859-1" . $eol;
        $message .= "Content-Transfer-Encoding: 8bit" . $eol . $eol;
        $message .= $message1 . $eol;
        $message .= "--" . $uid . $eol;
        $message .= "Content-Type: application/pdf; name=\"" . $filename . "\"" . $eol;
        $message .= "Content-Transfer-Encoding: base64" . $eol;
        $message .= "Content-Disposition: attachment; filename=\"" . $filename . "\"" . $eol;
        $message .= $content . $eol;
        $message .= "--" . $uid . "--";

        if (mail($mailto, $subject, $message, $header)) {
            echo "mail_success";
            exit;
        } else {
            echo "mail_error";
            exit;
        }
    }

}
