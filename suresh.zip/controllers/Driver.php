<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Driver extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('driver_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Admin Dashboard
     */
    public function index() {
        echo "Welcome to Amel Global Technologies";
    }

    /**
     * Manage Drivers
     */
    public function manage_drivers() {
        $data['user_data'] = $this->session->userdata();
        $data['drivers'] = $this->driver_model->get_drivers($data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/drivers/manage_drivers');
        $this->load->view('admin/layouts/footer');
    }

    /* To Check Driver exist or not by using admission number */

    public function toCheckDriver() {
        $mobile_number = trim($this->input->post('mobile_number'));
        $id = trim($this->input->post('id'));
        if (!empty($mobile_number)) {
            $result = $this->driver_model->getDriverDetailsByMobileNumber($mobile_number, $id);
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Add Driver
     */
    public function add_driver() {
        $data['user_data'] = $this->session->userdata();
        if ($_POST) {
            $getData = $this->input->post();
            $mobile_number = $this->input->post('mobile_number');
            $driverInfo = $this->driver_model->getDriverDetailsByMobileNumber('mobile_number', $mobile_number, 'student_bus_drivers');
            //echo $this->db->last_query();
            //print_r($studentInfo);exit;

            if (empty($driverInfo)) {
                $save_driver_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'driver_name' => isset($getData['driver_name']) ? strtoupper($getData['driver_name']) : '',
                    'gender' => isset($getData['gender']) ? trim($getData['gender']) : '',
                    'aadhar_number' => isset($getData['aadhar_number']) ? $getData['aadhar_number'] : '',
                    'license_number' => isset($getData['license_number']) ? $getData['license_number'] : '',
                    'mobile_number' => isset($getData['mobile_number']) ? $getData['mobile_number'] : '',
                    'password' => isset($getData['password']) ? md5($getData['password']) : '',
                    'driver_status' => isset($getData['driver_status']) ? $getData['driver_status'] : '',
                    'driver_description' => isset($getData['driver_description']) ? $getData['driver_description'] : ''
                );
                if (isset($_FILES['driver_pic']['name']) && !empty($_FILES['driver_pic']['name'])) {
                    $imageDimensions = getimagesize($_FILES["driver_pic"]["tmp_name"]);
                    $image_width_size = $imageDimensions[0];
                    $image_height_size = $imageDimensions[1];
                    $uploadFile = $this->do_upload('profile_pics', 'gif|jpg|png|jpeg|PNG|GIF|JPG|JPEG', 2048, $image_width_size, $image_height_size);
                    $image = array('driver_image' => $uploadFile);
                    $save_driver_data = array_merge($save_driver_data, $image);
                }

                $save_user = $this->global_model->save_data('student_bus_drivers', $save_driver_data);
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Driver added Successfully'));
                redirect(base_url() . 'driver/manage_drivers');
            } else {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Driver already exist with given phone number'));
            }
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/drivers/add_driver', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Driver
     * @param type $id
     */
    public function delete_driver($id = 0) {
        if ($id != '0') {
            $delete_driver = $this->global_model->update_by('student_bus_drivers', array('id' => $id), array('driver_status' => 'D'));
            if ($delete_driver) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Driver deleted successfully'));
            }
            redirect(base_url() . 'driver/manage_drivers');
        }
    }

    public function delete_multiple_drivers() {
        $ids = explode(',', $_POST['ids']);
        foreach ($ids as $id):
            $delete_driver = $this->global_model->update_by('student_bus_drivers', array('id' => $id), array('driver_status' => 'D'));
        endforeach;
        if ($delete_driver) {
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Drivers deleted successfully'));
        }
        redirect(base_url() . 'driver/manage_drivers');
    }

    /**
     * Edit Driver
     * @param type $id
     */
    public function edit_driver($id) {
        $data['user_data'] = $this->session->userdata();
        $getData = $this->input->post();
        if ($id != '0') {
            $data['driver_details'] = $this->driver_model->get_driver_data($id);
            if ($_POST) {
                $save_driver_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'driver_name' => isset($getData['driver_name']) ? strtoupper($getData['driver_name']) : '',
                    'gender' => isset($getData['gender']) ? trim($getData['gender']) : '',
                    'aadhar_number' => isset($getData['aadhar_number']) ? $getData['aadhar_number'] : '',
                    'license_number' => isset($getData['license_number']) ? $getData['license_number'] : '',
                    'mobile_number' => isset($getData['mobile_number']) ? $getData['mobile_number'] : '',
                    'password' => isset($getData['password']) ? md5($getData['password']) : '',
                    'driver_status' => isset($getData['driver_status']) ? $getData['driver_status'] : '',
                    'driver_description' => isset($getData['driver_description']) ? $getData['driver_description'] : ''
                );
                if (isset($_FILES['driver_pic']['name']) && !empty($_FILES['driver_pic']['name'])) {
                    $imageDimensions = getimagesize($_FILES["driver_pic"]["tmp_name"]);
                    $image_width_size = $imageDimensions[0];
                    $image_height_size = $imageDimensions[1];
                    $uploadFile = $this->do_upload('profile_pics', 'gif|jpg|png|jpeg|PNG|GIF|JPG|JPEG', 2048, $image_width_size, $image_height_size);
                    $image = array('driver_image' => $uploadFile);
                    $save_driver_data = array_merge($save_driver_data, $image);
                }
                $save_driver = $this->global_model->update_by('student_bus_drivers', array('id' => $id), $save_driver_data);
                if ($save_driver) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Driver data updated successfully'));
                    redirect(base_url() . 'driver/manage_drivers');
                }
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/drivers/edit_driver', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* view driver info */

    public function view_driver($id) {
        $data['user_data'] = $this->session->userdata();
        if ($id != '0') {
            $data['driverInfo'] = $this->driver_model->view_driver_data($id);
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/drivers/view_driver', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* to export drivers data to csv */

    public function export_drivers_data() {
        $user_data = $this->session->userdata();
        $drivers = $this->driver_model->export_drivers_data($user_data['user_id']);
        $driver_headings[] = array('S.No', 'Driver Name', 'Aadhar Number', 'Driving License', 'mobile Number');
        foreach ($drivers as $key => $student):
            $driverNew['S.No'] = ++$key;
            $driverNew['sch_admission_id'] = ucfirst($student['driver_name']);
            $driverNew['driver_name'] = $student['aadhar_number'];
            $driverNew['license_number'] = ucfirst($student['license_number']);
            $driverNew['mobile_number'] = ucfirst($student['mobile_number']);
            array_push($driver_headings, $driverNew);
        endforeach;
        $fileName = 'drivers' . rand() . '.csv';
        array_to_csv($driver_headings, $fileName);
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

    /*
     * Function is used to upload the files
     */

    public function do_upload($uploadedPath, $allowTypes, $maxSize, $imgWidth = '', $imgheight = '') {
        $this->load->library('upload'); // Loading upload library to upload an image
        $this->load->library('image_lib'); // Loading image library to resize an image
        $imgName = $_FILES['driver_pic']['name'];

        $splittedArray = @explode(".", $imgName);
        if (!empty($splittedArray)) {

            $uploadedFile = $this->get_random_code() . '_' . time() . '.' . end($splittedArray);
        }
        $arr_config = array('allowed_types' => $allowTypes,
            'upload_path' => 'uploads/' . $uploadedPath . '/',
            'max_size' => $maxSize,
            'file_name' => $uploadedFile,
            'remove_spaces' => true,
            'overwrite' => true,
        );
        $this->upload->initialize($arr_config);

        if (!$this->upload->do_upload('driver_pic')) {
            return $this->upload->display_errors();
        } else {

            $resizeconfig = array();
            $resizeconfig['image_library'] = 'GD2';
            $resizeconfig['source_image'] = FCPATH . '/uploads/' . $uploadedPath . '/' . $uploadedFile;
            $resizeconfig['new_image'] = FCPATH . '/uploads/' . $uploadedPath . '/thumbnails/' . $uploadedFile;
            $resizeconfig['maintain_ratio'] = TRUE;

            if ($imgWidth < 100 && $imgheight < 100) {
                $resizeconfig['width'] = $imgWidth;
                $resizeconfig['height'] = $imgheight;
            } else {
                if ($imgWidth > $imgheight) {
                    $resizeconfig['width'] = 100;
                } elseif ($imgWidth < $imgheight) {
                    $resizeconfig['height'] = 100;
                } elseif ($imgWidth == $imgheight) {
                    $resizeconfig['width'] = 100;
                }
            }
            $resizeconfig['x_axis'] = '0';
            $resizeconfig['y_axis'] = '0';
            $resizeconfig['quality'] = '100%';
            $this->image_lib->initialize($resizeconfig);
            $this->load->library('image_lib', $resizeconfig);
            $this->image_lib->resize();
            $this->image_lib->clear();
            if (!$this->image_lib->resize()) {
                echo $this->image_lib->display_errors();
                exit;
            }
            return $uploadedFile;
        }
    }

// Generates Random Code

    public function get_random_code($chars_min = 6, $chars_max = 6, $use_upper_case = false, $include_numbers = true, $include_special_chars = false) {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if ($include_numbers) {
            $selection .= "1234567890";
        }
        if ($include_special_chars) {
            $selection .= "!@04f7c318ad0360bd7b04c980f950833f11c0b1d1quot;#$%&[]{}?|";
        }
        $password = "";
        for ($i = 0; $i < $length; $i++) {
            $current_letter = $use_upper_case ? (rand(0, 1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];
            $password .= $current_letter;
        }
        return $password;
    }

    public function toDownloadAsPdf() {
        $id = trim($_GET['id']);
        $data['user_data'] = $this->session->userdata();
        $data['driverInfo'] = $this->driver_model->view_driver_data($id);
        $html = $this->load->view('admin/drivers/driverpdf', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['driverInfo']['driver_name']) . "_profile_information.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

}
