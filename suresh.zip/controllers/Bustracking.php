<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Bustracking extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->library(array('session', 'sendsms'));
        $this->load->model(array('bustracking_model', 'global_model'));
    }

    public function index() {
        $this->load->view('welcome_message');
    }

    public function webService() {
        $this->load->view('webservices');
    }

    /* Parent Login */

    public function driverLogin() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            $result = $this->bustracking_model->driverLogin($ldata['password'], $ldata['phone'], $ldata['user_id']);
            if (!empty($result) && isset($result)) {
                if (!empty($result['driver_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $result['driver_image'])) {
                    $result['driver_image'] = base_url() . 'uploads/profile_pics/' . $result['driver_image'];
                }
                $data['status'] = 'success';
                $data['message'] = 'Driver logged successfully';
                $data['driverInfo'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Login Failed. Please provide valid details.';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* to Get Bus Driver Info */

    public function toGetBusDriverInfo() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            $result = $this->bustracking_model->toGetBusDriverInfo($ldata['driver_id'], $ldata['user_id']);
            if (!empty($result) && isset($result)) {
                if (!empty($result['driver_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $result['driver_image'])) {
                    $result['driver_image'] = base_url() . 'uploads/profile_pics/' . $result['driver_image'];
                }
                $data['status'] = 'success';
                $data['driverInfo'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Login Failed. Please provide valid details.';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* to get buses */

    public function toGetBuses() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id']) && isset($ldata['user_id'])) {
            $buses = $this->bustracking_model->toGetBuses($ldata['user_id']);
            if (!empty($buses) && isset($buses)) {
                $data['status'] = 'success';
                $data['buses'] = $buses;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* to get bus routes */

    public function toGetBusRoutes() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id']) && isset($ldata['user_id'])) {
            $busRoutes = $this->bustracking_model->toGetBusRoutes($ldata['user_id']);
            if (!empty($busRoutes) && isset($busRoutes)) {
                foreach ($busRoutes as $route):
                    $emptyRoute = $this->bustracking_model->checkBusRoute($route['id'], $ldata['user_id']);
                    if (empty($emptyRoute)) {
                        $emptyRoutes[] = $route;
                    }
                endforeach;
                if (!empty($emptyRoutes) && isset($emptyRoutes)) {
                    $data['status'] = 'success';
                    $data['busRoutes'] = $emptyRoutes;
                    $data['content'] = json_encode(array("response" => $data));
                } else {
                    $data['status'] = 'fail';
                    $data['message'] = 'No Data Found';
                    $data['content'] = json_encode(array("response" => $data));
                }
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* to get bus tracking Info for Parent */

    public function toGetBusTrackingInfoForParent() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            $result = $this->bustracking_model->toGetBusTrackingInfoForParent($ldata['route_id'], $ldata['user_id']);
            if (!empty($result['driver_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $result['driver_image'])) {
                $result['driver_image'] = base_url() . 'uploads/profile_pics/' . $result['driver_image'];
            }
//            echo $this->db->last_query();exit;
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['busTrackingInfo'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found!..Please try again';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* driver starts bus service */

    public function startBusServiceByDriver() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            if (!empty($ldata['routes'])) {
                foreach ($ldata['routes'] as $route):
                    $routes_allocation = $this->bustracking_model->checkBusRoute($route, $ldata['user_id']);
                    if (!empty($routes_allocation)) {
                        $data['status'] = 'fail';
                        $data['driverStartBuses'] = 'Some of your selected routes already allocated!.. please try with new routes';
                        $data['content'] = json_encode(array("response" => $data));
                        $this->load->view('blank', $data);
                        exit;
                    } else {
                        $data_to_store = array(
                            "bus_id" => $ldata['bus_id'],
                            "route_id" => $route,
                            "userid" => $ldata['user_id'],
                            "driver_id" => $ldata['driver_id'],
                            "tracking_date" => date("Y-m-d"),
                            "latitude" => $ldata['latitude'],
                            "longitude" => $ldata['longitude'],
                            "status" => "1"
                        );
                        $result = $this->global_model->save_data("student_bus_tracking", $data_to_store);
                    }
                endforeach;
                $data['status'] = 'success';
                $data['driverStartBuses'] = 'Bus Service Started';
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Please provide required data';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* update lat and lng of bus for every 3 seconds */

    public function toUpdateLatNLngOfBusByDriverLocation() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        //print_r($ldata);exit;
        if (!empty($ldata) && isset($ldata)) {
            //echo "ff";exit;
            if (!empty($ldata['routes'])) {
                foreach ($ldata['routes'] as $route):
                    $data_to_where = array(
                        "bus_id" => $ldata['bus_id'],
                        "route_id" => $route,
                        "userid" => $ldata['user_id'],
                        "driver_id" => $ldata['driver_id'],
                        "tracking_date" => date("Y-m-d"),
                        "status" => "1"
                    );
                    $data_to_update = array(
                        "latitude" => $ldata['latitude'],
                        "longitude" => $ldata['longitude'],
                    );
                    $result = $this->global_model->update_by("student_bus_tracking", $data_to_where, $data_to_update);
                endforeach;
                $data['status'] = 'success';
                $data['driverStartBuses'] = 'Latitude and Longitude Updated';
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Please Select Routes to update latitude and longitudes';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* To Delete Routes when bus get repaired */

    public function toClearSelectedRoutes() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        //print_r($ldata);exit;
        if (!empty($ldata) && isset($ldata)) {
            $data_to_delete = array(
                "userid" => $ldata['user_id'],
                "driver_id" => $ldata['driver_id'],
                "tracking_date" => date("Y-m-d")
            );
            $this->global_model->delete_by("student_bus_tracking", $data_to_delete);
            $data['status'] = 'success';
            $data['driverStartBuses'] = 'Routes deleted successfully!..';
            $data['content'] = json_encode(array("response" => $data));
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* end bus service */

    public function toStopBusService() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            if (!empty($ldata['routes'])) {
                foreach ($ldata['routes'] as $route):
                    $data_to_where = array(
                        "bus_id" => $ldata['bus_id'],
                        "route_id" => $route,
                        "userid" => $ldata['user_id'],
                        "driver_id" => $ldata['driver_id'],
                        "tracking_date" => date("Y-m-d")
                    );
                    $data_to_update = array(
                        "latitude" => $ldata['latitude'],
                        "longitude" => $ldata['longitude'],
                        "status" => "0"
                    );
                    //$result = $this->global_model->update_by("student_bus_tracking", $data_to_where, $data_to_update);
                    $this->global_model->delete_by("student_bus_tracking", $data_to_where);
                endforeach;
                $data['status'] = 'success';
                $data['driverStartBuses'] = 'Bus Reached To Destination';
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Please provide required data';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* To Get Route Map */

    public function toGetRouteMap() {
        $data = array();
        $routesArray = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id']) && isset($ldata['user_id'])) {
            $busRoutes = $this->bustracking_model->toGetRouteMap($ldata['user_id']);
            if (!empty($busRoutes) && isset($busRoutes)) {
                foreach ($busRoutes as $route):
                    $routesArray[$route['route_no']]['route_no'] = $route['route_no'];
                    $routesArray[$route['route_no']]['coveringAreas'] = $route['route_name'];
                endforeach;
                $data['status'] = 'success';
                $data['routeMap'] = array_values($routesArray);
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Please provide required data';
                $data['content'] = json_encode(array("response" => $data));
            }
            $this->load->view('blank', $data);
        }
    }

    /* To Add School Home Location */

    public function toAddSchoolHomeLocation() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id']) && !empty($ldata['latitude']) && !empty($ldata['longitude'])) {
            $data_to_save = array(
                "userid" => $ldata['user_id'],
                "latitude" => $ldata['latitude'],
                "longitude" => $ldata['longitude']
            );
            $result = $this->global_model->save_data("school_homelocation", $data_to_save);
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['message'] = 'Home Location Added Successfully!..';
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Something went wrong please try again!..';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toUpdateSchoolHomeLocation() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id']) && !empty($ldata['latitude']) && !empty($ldata['longitude'])) {
            $data_to_update = array(
                "userid" => $ldata['user_id'],
                "latitude" => $ldata['latitude'],
                "longitude" => $ldata['longitude']
            );
            $data_to_where = array(
                "userid" => $ldata['user_id']
            );
            $this->global_model->update_by("school_homelocation", $data_to_where, $data_to_update);
            $data['status'] = 'success';
            $data['message'] = 'Home Location Updated Successfully!..';
            $data['content'] = json_encode(array("response" => $data));
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toDeleteSchoolHomeLocation() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id'])) {
            $data_to_where = array(
                "userid" => $ldata['user_id']
            );
            $this->global_model->delete_by("school_homelocation", $data_to_where);
            $data['status'] = 'success';
            $data['message'] = 'Home Location Deleted Successfully!..';
            $data['content'] = json_encode(array("response" => $data));
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toGetSchoolHomeLocation() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id'])) {
            $school_homelocation = $this->bustracking_model->toGetSchoolHomeLocation($ldata['user_id']);
            if (!empty($school_homelocation) && isset($school_homelocation)) {
                $data['status'] = 'success';
                $data['homelocation'] = $school_homelocation;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No data found with this school';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toSaveLocationStages() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id'])) {
            $data_to_save = array(
                "userid" => $ldata['user_id'],
                "route_id" => $ldata['route_id'],
                "stage_name" => $ldata['stage_name'],
                "stage_latitude" => $ldata['stage_latitude'],
                "stage_longitude" => $ldata['stage_longitude']
            );
            $result = $this->global_model->save_data("student_bus_route_stages", $data_to_save);
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['message'] = 'Home Location Added Successfully!..';
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Something went wrong please try again!..';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toGetBusRoutesforStage() {

        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata['user_id']) && isset($ldata['user_id'])) {
            $busRoutes = $this->bustracking_model->toGetBusRoutes($ldata['user_id']);
            if (!empty($busRoutes) && isset($busRoutes)) {
                $data['status'] = 'success';
                $data['busroutes'] = array_values($busRoutes);
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {

            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

}
