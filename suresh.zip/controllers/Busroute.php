<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Busroute extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('busroute_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    public function index() {
        echo "Welcome to Amel Global Technologies";
    }

    /**
     * Manage Busroutes
     */
    public function manage_busroutes() {
        $data['user_data'] = $this->session->userdata();
        $data['busroutes'] = $this->busroute_model->get_busroutes($data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/busroutes/manage_busroutes');
        $this->load->view('admin/layouts/footer');
    }

    /* To Check Busroute exist or not by using route number */

    public function toCheckBusRoute() {
        $route_no = trim($this->input->post('route_no'));
        $id = trim($this->input->post('id'));
        if (!empty($route_no)) {
            $result = $this->busroute_model->getBusrouteDetailsByNumber($route_no, $id);
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Add Busroute
     */
    public function add_busroute() {
        $data['user_data'] = $this->session->userdata();
        if ($_POST) {
            $getData = $this->input->post();
            $route_no = $this->input->post('route_no');
            $busRouteInfo = $this->busroute_model->getBusrouteDetailsByNumber('route_no', $route_no, 'student_bus_routes');
            if (empty($busRouteInfo)) {
                $save_busroute_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'route_no' => isset($getData['route_no']) ? strtoupper($getData['route_no']) : '',
                    'route_name' => isset($getData['route_name']) ? trim($getData['route_name']) : '',
                    'status' => isset($getData['status']) ? $getData['status'] : '',
                );
                $save_busroute = $this->global_model->save_data('student_bus_routes', $save_busroute_data);
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Busroute added Successfully'));
                redirect(base_url() . 'busroute/manage_busroutes');
            } else {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Busroute already exist with given number'));
            }
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/busroutes/add_busroute', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Busroute
     * @param type $id
     */
    public function delete_busroute($id = 0) {
        if ($id != '0') {
            $delete_busroute = $this->global_model->update_by('student_bus_routes', array('id' => $id), array('status' => 'D'));
            if ($delete_busroute) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Busroute deleted successfully'));
            }
            redirect(base_url() . 'busroute/manage_busroutes');
        }
    }

    public function delete_multiple_busroutes() {
        $ids = explode(',', $_POST['ids']);
        foreach ($ids as $id):
            $delete_busroutes = $this->global_model->update_by('student_bus_routes', array('id' => $id), array('status' => 'D'));
        endforeach;
        $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Busroute deleted successfully'));
        echo "success";
        exit;
        //redirect(base_url() . 'busroute/manage_busroutes');
    }

    /**
     * Edit Busroute
     * @param type $id
     */
    public function edit_busroute($id) {
        $data['user_data'] = $this->session->userdata();
        $getData = $this->input->post();
        if ($id != '0') {
            $data['busroute_details'] = $this->busroute_model->get_busroute_data($id);
            if ($_POST) {
                $save_busroute_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'route_no' => isset($getData['route_no']) ? strtoupper($getData['route_no']) : '',
                    'route_name' => isset($getData['route_name']) ? trim($getData['route_name']) : '',
                    'status' => isset($getData['status']) ? $getData['status'] : '',
                );
                $save_busroute = $this->global_model->update_by('student_bus_routes', array('id' => $id), $save_busroute_data);
                if ($save_busroute) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Busroute data updated successfully'));
                    redirect(base_url() . 'busroute/manage_busroutes');
                }
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/busroutes/edit_busroute', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* view busroute info */

    public function view_busroute($id) {
        $data['user_data'] = $this->session->userdata();
        if ($id != '0') {
            $data['busRouteInfo'] = $this->busroute_model->view_busroute_data($id);
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/busroutes/view_busroute', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* to export busroutes data to csv */

    public function export_busroutes_data() {
        $user_data = $this->session->userdata();
        $busroutes = $this->busroute_model->export_busroutes_data($user_data['user_id']);
        $busroute_headings[] = array('S.No', 'Route No', 'Route Name');
        foreach ($busroutes as $key => $student):
            $busrouteNew['S.No'] = ++$key;
            $busrouteNew['route_no'] = ucfirst($student['route_no']);
            $busrouteNew['route_name'] = $student['route_name'];
            array_push($busroute_headings, $busrouteNew);
        endforeach;
        $fileName = 'busroutes' . rand() . '.csv';
        array_to_csv($busroute_headings, $fileName);
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
