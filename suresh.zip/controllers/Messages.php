<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Messages extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('messages_model', 'admin_model', 'homework_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Messages
     */
    public function manage_messages() {
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['messages'] = $this->messages_model->manage_messages($data['user_data']['user_id'], $date);
        //echo $this->db->last_query();exit;
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/messages/manage_messages');
        $this->load->view('admin/layouts/footer');
    }

    /* to export messages to csv */

    public function export_messages_data() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $messages = $this->messages_model->export_messages_data($data['user_data']['user_id'], $date);
        $message_headings[] = array('S.No', 'Message Date', 'Message Subject', 'Message');
        foreach ($messages as $key => $msg):
            $messageNew['S.No'] = ++$key;
            $messageNew['message_date'] = date('dS-F-Y', strtotime($msg['message_date']));
            $messageNew['message_subject'] = ucfirst($msg['message_subject']);
            $messageNew['message'] = ucfirst($msg['message']);
            array_push($message_headings, $messageNew);
        endforeach;
        $fileName = 'Messaegs' . rand() . '.csv';
        array_to_csv($message_headings, $fileName);
    }

    /**
     * Add Message
     */
//    public function send_message() {
//        $data['user_data'] = $this->session->userdata();
//        if ($_POST) {
//            $result = $this->admin_model->getStudentsInfo($data['user_data']['user_id'], '', '');
//            $save_message_data = array(
//                'userid' => $data['user_data']['user_id'],
//                'message_date' => $this->input->post('message_date'),
//                'message_subject' => $this->input->post('message_subject'),
//                'message' => $this->input->post('message'),
//                'message_count' => count($result)
//            );
//            $this->global_model->save_data('student_messages', $save_message_data);
//            $rand = time();
//            $fileName = 'studentInfo_' . $rand . '.csv';
//            file_put_contents(FCPATH . "uploads/csv/messages/" . $fileName, array_to_csv($result));
//            $my_file = $fileName;
//            $my_path = FCPATH . "uploads/csv/messages/";
//            $my_name = $data['user_data']['institutename'];
//            $my_mail = $data['user_data']['email'];
//            $my_replyto = $data['user_data']['email'];
//            $my_subject = $this->input->post('message_subject');
//            $my_message = $this->input->post('message');
//            $this->mail_attachment($my_file, $my_path, "ali12riyaz@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
//            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Message Send Successfully'));
//            redirect(base_url() . 'messages/manage_messages?date=');
//        }
//        $this->load->view('admin/layouts/header', $data);
//        $this->load->view('admin/layouts/sidebar', $data);
//        $this->load->view('admin/messages/add_message', $data);
//        $this->load->view('admin/layouts/footer');
//    }

    public function send_message() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = array();
        $students = array();
        $classes = $this->homework_model->getClasses($data['user_data']['user_id']);
        if (!empty($classes) && isset($classes)) {
            foreach ($classes as $cls):
                $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                if ($studentCount) {
                    $data['classes'][] = $cls;
                }
            endforeach;
        }
        if ($_POST) {
            $class_ids = $this->input->post('class_id');
            if (empty($class_ids) && !isset($class_ids)) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Please select at least one class to send message'));
                redirect(base_url() . 'messages/send_message');
            }
            if (!empty($class_ids) && isset($class_ids)) {
                foreach ($class_ids as $class_id):
                    $result[] = $this->admin_model->getStudentsInfo($data['user_data']['user_id'], $class_id, '');
                endforeach;
                foreach ($result as $student):
                    foreach ($student as $stu):
                        $students[] = $stu;
                    endforeach;
                endforeach;
            }
            $save_message_data = array(
                'userid' => $data['user_data']['user_id'],
                'message_date' => $this->input->post('message_date'),
//                'message_subject' => $this->input->post('message_subject'),W
                'message' => $this->input->post('message'),
                'message_count' => count($students)
            );
            $message_id = $this->global_model->save_data('student_messages', $save_message_data);
            if (!empty($class_ids) && isset($class_ids)) {
                foreach ($class_ids as $class_id):
                    $save_message_class_data = array(
                        'userid' => $data['user_data']['user_id'],
                        'class_id' => $class_id,
                        'message_id' => $message_id
                    );
                    $this->global_model->save_data('student_message_classes', $save_message_class_data);
                endforeach;
            }
            $message_date = date('dS-F-Y', strtotime($save_message_data['message_date']));
            //$message = $save_message_data['message_subject'] . '- ' . $message_date . "\r\n" . $save_message_data['message'] . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];
            $message = $message_date . "\r\n" . $save_message_data['message'] . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];
            if (!empty($students) && isset($students)) {
                foreach ($students as $student):
                    if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                        $this->sendsms->send_sms($student['student_mobile'], $message);
                    }
                    if (!empty($student['device_token'])) {
                        $messageData = array("device_token" => $student['device_token'],
                            "lastname" => "Message From - " . $data['user_data']['institutename'],
                            "message" => $save_message_data['message']);
                        $this->android($messageData);
                    }
                endforeach;
            }
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Message Send Successfully'));
            redirect(base_url() . 'messages/manage_messages?date=');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/messages/add_message', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Message
     * @param type $id
     */
    public function delete_message($id = 0, $smc_id = 0) {
        if ($id != '0' && $smc_id != '0') {
            // $delete_user = $this->section_model->delete_by('users', array('user_id' => $id));
            $count = $this->messages_model->toGetCountMessages($id);
            $delete_remark = $this->global_model->update_by('student_message_classes', array('id' => $smc_id), array('smc_status' => 'D'));
            if (empty($count)) {
                $this->global_model->update_by('student_messages', array('id' => $id), array('message_status' => 'D'));
            }

            if ($delete_remark) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Message deleted Successfully'));
            }
            redirect(base_url() . 'messages/manage_messages?date=');
        }
    }

    public function delete_multiple_messages() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $r_id):
                $delete_remark = $this->global_model->update_by('student_messages', array('id' => $r_id), array('message_status' => 'D'));
            endforeach;
            if ($delete_remark) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Messages deleted successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

    public function emailNew() {
        $my_file = "studentInfo_1497616171.csv";
        $my_path = FCPATH . "uploads/csv/";
        $my_name = "school";
        $my_mail = "krishna.kurivella@gmail.com";
        $my_replyto = "krishna.kurivella@gmail.com";
        $my_subject = "Bulk Message Details";
        $my_message = "Hi Riyaz,\r\n Please find the message.\r\n\r\n";
        $this->mail_attachment($my_file, $my_path, "chaitu.kuru@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
    }

    function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message1) {

        $file = $path . $filename;
        $file_size = filesize($file);
        $handle = fopen($file, "r");
        $content = fread($handle, $file_size);
        fclose($handle);
        $content = chunk_split(base64_encode($content));
        $uid = md5(uniqid(time()));
        $name = basename($file);

        $eol = PHP_EOL;

// Basic headers
        $header = "From: " . $from_name . " <" . $from_mail . ">" . $eol;
        $header .= "Reply-To: " . $replyto . $eol;
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"";

// Put everything else in $message
        $message = "--" . $uid . $eol;
        $message .= "Content-Type: text/html; charset=ISO-8859-1" . $eol;
        $message .= "Content-Transfer-Encoding: 8bit" . $eol . $eol;
        $message .= $message1 . $eol;
        $message .= "--" . $uid . $eol;
        $message .= "Content-Type: application/pdf; name=\"" . $filename . "\"" . $eol;
        $message .= "Content-Transfer-Encoding: base64" . $eol;
        $message .= "Content-Disposition: attachment; filename=\"" . $filename . "\"" . $eol;
        $message .= $content . $eol;
        $message .= "--" . $uid . "--";

        if (mail($mailto, $subject, $message, $header)) {
            return true;
        } else {
            return false;
        }
    }

    function android($message = '') {
//echo '<pre>';print_r($message);exit;
        //echo $rids.'---'.$message;
        error_reporting(E_ALL ^ (E_NOTICE | E_WARNING));
        $key = 'AIzaSyD7M6ux_kkJdMBvkHT9axN9wuTsDQVheXo'; //Dev Server
        // Set POST variables
        $url = 'https://fcm.googleapis.com/fcm/send';

        $fields = array(
            'to' => $message['device_token'],
            'notification' => array("title" => $message['lastname'], "body" => $message['message'])
        );

        /*  $fields = array (

          'data' => $message['message'],
          'registration_ids' => array (
          $message['device_token']
          )
          ); */

        // echo '<pre>';print_r($fields);
        $headers = array(
            'Authorization: key=' . $key,
            'Content-Type: application/json'
        );
        //echo '<pre>';print_r($headers);exit;
        // Open connection
        $ch = curl_init();

        // Set the url, number of POST vars, POST data
        curl_setopt($ch, CURLOPT_URL, $url);

        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);

        // Disabling SSL Certificate support temporarly
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_IPRESOLVE, CURL_IPRESOLVE_V4);
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

        // Execute post
        $result = curl_exec($ch);
//print_r($result);exit;
        if ($result === FALSE) {
            die('Curl failed: ' . curl_error($ch));
        }

        // Close connection
        curl_close($ch);
        return $result;
        //exit;
    }

}
