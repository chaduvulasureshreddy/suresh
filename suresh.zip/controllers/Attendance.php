<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Attendance extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('attendance_model', 'admin_model', 'homework_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Remarks
     */
    public function manage_attendance() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['date'])) {
            $date = $_GET['date'];
        } else {
            $date = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['attendance'] = $this->attendance_model->manage_attendance($data['user_data']['user_id'], $class_id, $section_id, $date);
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        if (!empty($data['attendance'])) {
            foreach ($data['attendance'] as $key => $attendance):
                $data['attendance'][$key]['total_students_count'] = $this->attendance_model->toGetStudentsCount($attendance['id'], 1);
                $data['attendance'][$key]['present_students_count'] = $this->attendance_model->toGetStudentsCount($attendance['id'], 2);
                $data['attendance'][$key]['morningabsent_students_count'] = $this->attendance_model->toGetStudentsCount($attendance['id'], 3);
                $data['attendance'][$key]['afternoonabsent_students_count'] = $this->attendance_model->toGetStudentsCount($attendance['id'], 4);
                $data['attendance'][$key]['absent_students_count'] = $this->attendance_model->toGetStudentsCount($attendance['id'], 5);
            endforeach;
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/attendance/manage_attendance');
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Add Remark
     */
    public function add_attendance() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = array();
        $classes = $this->homework_model->getClasses($data['user_data']['user_id']);
        if (!empty($classes) && isset($classes)) {
            foreach ($classes as $cls):
                $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                if ($studentCount) {
                    $data['classes'][] = $cls;
                }
            endforeach;
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/attendance/add_attendance', $data);
        $this->load->view('admin/layouts/footer');
    }

    public function getStudentsAttendanceData() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        if (!empty($_GET['attendance_date'])) {
            $attendance_date = $_GET['attendance_date'];
        } else {
            $attendance_date = '';
        }
        $where = array('class_id' => $class_id, 'section_id' => $section_id, 'userid' => $data['user_data']['user_id'], 'attendance_date' => $_GET['attendance_date']);
        $attendanceResult = $this->attendance_model->get_by('student_attendance', $where);
        if (!empty($attendanceResult)) {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Attendance already added for this class on selected date'));
            redirect(base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=');
        } else {
            $data['students'] = $this->admin_model->get_students($data['user_data']['user_id'], $class_id, $section_id);
            $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
            $data['className'] = $this->admin_model->toGetClassName($class_id);
            $data['sectionName'] = $this->admin_model->toGetSectionName($section_id);
            $data['attendanceDate'] = $attendance_date;
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/attendance/add_attendance_students');
            $this->load->view('admin/layouts/footer');
        }
    }

//    public function addAttendanceData() {
//        $attendance_list = $this->input->post();
//        $data['user_data'] = $this->session->userdata();
//        /* main table */
//        if (!isset($attendance_list['class_id']) || !isset($attendance_list['section_id']) || !isset($attendance_list['attendance_date'])) {
//            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Server is slow.. please try again after some time'));
//            redirect(base_url() . 'attendance/add_attendance');
//        }
//        $save_attendance_data = array(
//            'userid' => $data['user_data']['user_id'],
//            'class_id' => $attendance_list['class_id'],
//            'section_id' => $attendance_list['section_id'],
//            'attendance_date' => $attendance_list['attendance_date']
//        );
//        $attendance_list_id = $this->global_model->save_data('student_attendance', $save_attendance_data);
//        /* end */
//        /* child table */
//        for ($i = 1; $i <= $attendance_list['total_count']; $i++) {
//            $save_attendance_data2 = array(
//                'attendance_id' => $attendance_list_id,
//                'student_admission_id' => $this->input->post('student_admission_id_' . $i),
//                'date' => $this->input->post('attendance_date'),
//                'status' => $this->input->post('status_' . $i),
//                'attendance_status' => 'A'
//            );
//            $this->global_model->save_data('student_attendance_list', $save_attendance_data2);
//        }
//        /* mail */
//        $result = $this->createAttendanceCSV($attendance_list_id, $attendance_list['attendance_date']);
//        $rand = time();
//        $fileName = 'attendance' . $rand . '.csv';
//
//        file_put_contents(FCPATH . "uploads/csv/attendance/" . $fileName, array_to_csv($result));
//        $my_file = $fileName;
//        $my_path = FCPATH . "/uploads/csv/attendance/";
//        $my_name = $data['user_data']['institutename'];
//        $my_mail = $data['user_data']['email'];
//        $my_replyto = $data['user_data']['email'];
//        $my_subject = 'Attendance List:' . $attendance_list['attendance_date'];
//        $my_message = 'Please find the Attachment of Attendance of date' . $attendance_list['attendance_date'];
//        $this->mail_attachment($my_file, $my_path, "ali12riyaz@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
//        /* end here */
//        if (!empty($attendance_list_id)) {
//            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Attendance added Successfully'));
//            redirect(base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=');
//        } else {
//            echo "fail";
//            exit;
//        }
//
//        /* end here */
//    }

    public function addAttendanceData() {
        $attendance_list = $this->input->post();
//echo "<pre>";        print_r($attendance_list);exit;
        $data['user_data'] = $this->session->userdata();
        /* main table */
        if (!isset($attendance_list['class_id']) || !isset($attendance_list['section_id']) || !isset($attendance_list['attendance_date'])) {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Server is slow.. please try again after some time'));
            redirect(base_url() . 'attendance/add_attendance');
        }
        $save_attendance_data = array(
            'userid' => $data['user_data']['user_id'],
            'class_id' => $attendance_list['class_id'],
            'section_id' => $attendance_list['section_id'],
            'attendance_date' => $attendance_list['attendance_date']
        );
        $attendance_list_id = $this->global_model->save_data('student_attendance', $save_attendance_data);
        /* end */
        /* child table */
        for ($i = 1; $i <= $attendance_list['total_count']; $i++) {
            $save_attendance_data2 = array(
                'attendance_id' => $attendance_list_id,
                'student_admission_id' => $this->input->post('student_admission_id_' . $i),
                'date' => $this->input->post('attendance_date'),
                'status' => $this->input->post('status_' . $i),
                'attendance_status' => 'A'
            );
            $this->global_model->save_data('student_attendance_list', $save_attendance_data2);
        }
        $students = $this->createAttendanceCSVData($attendance_list_id, $attendance_list['attendance_date']);
        if (!empty($students) && isset($students)) {
            $a_date = date('dS-F-Y', strtotime($save_attendance_data2['date']));
            foreach ($students as $student):
                if ($student['status'] === 'F') {
                    $amessage = "Dear Parent, Your Child(" . $student['student_name'] . ") Absent on" . '- ' . $a_date . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];
                } elseif ($student['status'] === 'E') {
                    $amessage = "Dear Parent, Your Child(" . $student['student_name'] . ") Absent in Afternoon Session on date" . '- ' . $a_date . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];
                } elseif ($student['status'] === 'M') {
                    $amessage = "Dear Parent, Your Child(" . $student['student_name'] . ") Absent in Morning Session on date" . '- ' . $a_date . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];
                }
                if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                    $this->sendsms->send_sms($student['student_mobile'], $amessage);
                }
            endforeach;
        }
        if (!empty($attendance_list_id)) {
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Attendance added Successfully'));
            redirect(base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=');
        } else {
            echo "fail";
            exit;
        }

        /* end here */
    }

    /**
     * Delete Remark
     * @param type $id
     */
    public function delete_attendance($id = 0) {
        if ($id != '0') {
            // $delete_user = $this->section_model->delete_by('users', array('user_id' => $id));
            $delete_remark = $this->global_model->update_by('student_attendance', array('id' => $id), array('attendance_status' => 'D'));
            $this->global_model->update_by('student_attendance_list', array('attendance_id' => $id), array('attendance_status' => 'D'));
            if ($delete_remark) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Attendance deleted Successfully'));
            }
            redirect(base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=');
        }
    }

    public function delete_multiple_attendance() {
        $ids = explode(',', $_POST['ids']);
        foreach ($ids as $r_id):
            $delete_remark = $this->global_model->update_by('student_attendance', array('id' => $r_id), array('attendance_status' => 'D'));
            $this->global_model->update_by('student_attendance_list', array('attendance_id' => $id), array('attendance_status' => 'D'));
        endforeach;
        if ($delete_remark) {
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Attendance deleted successfully'));
        }
        redirect(base_url() . 'attendance/manage_attendance?date=&class_id=&section_id=');
    }

    /**
     * Edit Remark
     * @param type $id
     */
    public function edit_attendance() {
        $data['user_data'] = $this->session->userdata();
        if ($_GET['attendance_id'] != '0') {
            $data['attendanceDate'] = $_GET['attendance_date'];
            $data['students'] = $this->attendance_model->edit_attendance(array('sal.attendance_id' => $_GET['attendance_id']));
            $attendanceInfo = $this->attendance_model->attendanceInfo($_GET['attendance_id']);
            if (!empty($attendanceInfo)) {
                $data['className'] = $this->admin_model->toGetClassName($attendanceInfo['class_id']);
                $data['sectionName'] = $this->admin_model->toGetSectionName($attendanceInfo['section_id']);
            }
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/attendance/edit_attendance_students');
            $this->load->view('admin/layouts/footer');
        }
    }

    public function update_attendance() {
        $data['user_data'] = $this->session->userdata();
        if ($_POST) {
            $attendance_list = $this->input->post();
            $id = $attendance_list['attendance_post_id'];
            $this->global_model->delete_by('student_attendance_list', array('attendance_id' => $id));
            for ($i = 1; $i <= $attendance_list['total_count']; $i++) {
                $save_attendance_data = array(
                    'attendance_id' => $id,
                    'student_admission_id' => $this->input->post('student_admission_id_' . $i),
                    'date' => $this->input->post('attendance_date'),
                    'status' => $this->input->post('status_' . $i),
                    'attendance_status' => 'A'
                );
                $save_attend = $this->global_model->save_data('student_attendance_list', $save_attendance_data);
            }
            if ($save_attend) {
                /* mail */
//                $result = $this->createAttendanceCSV($id, $attendance_list['attendance_date']);
//                $rand = time();
//                $fileName = 'attendance' . $rand . '.csv';
//                file_put_contents(FCPATH . "uploads/csv/attendance/" . $fileName, array_to_csv($result));
//                $my_file = $fileName;
//                $my_path = FCPATH . "/uploads/csv/attendance/";
//                $my_name = $data['user_data']['institutename'];
//                $my_mail = $data['user_data']['email'];
//                $my_replyto = $data['user_data']['email'];
//                $my_subject = 'Attendance List:' . $attendance_list['attendance_date'];
//                $my_message = 'Please find the Attachment of Attendance of date' . $attendance_list['attendance_date'];
//                $this->mail_attachment($my_file, $my_path, "ali12riyaz@gmail.com", $my_mail, $my_name, $my_replyto, $my_subject, $my_message);
                /* end here */
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Attendance data updated Successfully'));
            }

            redirect(base_url() . 'attendance/manage_attendance?date=&class_id = &section_id = ');
        }
    }

    public function export_attendance_data() {
        $attendanceInfo = $this->attendance_model->attendanceInfo($_GET['id']);
        $students_headings = $this->createAttendanceCSV($_GET['id'], $attendanceInfo['attendance_date']);
        $fileName = 'Attendance' . rand() . '.csv';
        array_to_csv($students_headings, $fileName);
    }

    public function createAttendanceCSV($id, $attendance_date) {
        $students = $this->attendance_model->edit_attendance(array('sal.attendance_id' => $id));
        $students_headings[] = array('S.No', 'student Admission Number', 'Student Name', 'Mobile Number', 'Class Name', 'Section Name', 'Attendance Date', 'Present', 'Absent In Morning Session', 'Absent In Afternoon Session', 'Full day Absent');
        foreach ($students as $key => $student):
            $studentNew['S.No'] = ++$key;
            $studentNew['student_admission_id'] = ucfirst($student['student_admission_id']);
            $studentNew['student_name'] = ucfirst($student['student_name']);
            $studentNew['student_mobile'] = $student['student_mobile'];
            $studentNew['class_name'] = ucfirst($student['class_name']);
            $studentNew['section_name'] = ucfirst($student['section_name']);
            $studentNew['attendance_date'] = date('dS-F-Y', strtotime($attendance_date));
            if ($student['status'] == 'P') {
                $studentNew['present'] = 'P';
                $studentNew['morning'] = '';
                $studentNew['afternoon'] = '';
                $studentNew['absent'] = '';
            } else if ($student['status'] == 'M') {
                $studentNew['present'] = '';
                $studentNew['morning'] = 'A';
                $studentNew['afternoon'] = '';
                $studentNew['absent'] = '';
            } else if ($student['status'] == 'E') {
                $studentNew['present'] = '';
                $studentNew['morning'] = '';
                $studentNew['afternoon'] = 'A';
                $studentNew['absent'] = '';
            } else if ($student['status'] == 'F') {
                $studentNew['present'] = '';
                $studentNew['morning'] = '';
                $studentNew['afternoon'] = '';
                $studentNew['absent'] = 'A';
            }
            array_push($students_headings, $studentNew);
        endforeach;
        return $students_headings;
    }

    public function createAttendanceCSVData($id, $attendance_date) {
        $students = $this->attendance_model->edit_attendance(array('sal.attendance_id' => $id, 'sal.status!=' => 'P'));
        return $students;
    }

    function mail_attachment($filename, $path, $mailto, $from_mail, $from_name, $replyto, $subject, $message1) {

        $file = $path . $filename;
        $file_size = filesize($file);
        $handle = fopen($file, "r");
        $content = fread($handle, $file_size);
        fclose($handle);
        $content = chunk_split(base64_encode($content));
        $uid = md5(uniqid(time()));
        $name = basename($file);

        $eol = PHP_EOL;

// Basic headers
        $header = "From: " . $from_name . " <" . $from_mail . ">" . $eol;
        $header .= "Reply-To: " . $replyto . $eol;
        $header .= "MIME-Version: 1.0\r\n";
        $header .= "Content-Type: multipart/mixed; boundary=\"" . $uid . "\"";

// Put everything else in $message
        $message = "--" . $uid . $eol;
        $message .= "Content-Type: text/html; charset=ISO-8859-1" . $eol;
        $message .= "Content-Transfer-Encoding: 8bit" . $eol . $eol;
        $message .= $message1 . $eol;
        $message .= "--" . $uid . $eol;
        $message .= "Content-Type: application/pdf; name=\"" . $filename . "\"" . $eol;
        $message .= "Content-Transfer-Encoding: base64" . $eol;
        $message .= "Content-Disposition: attachment; filename=\"" . $filename . "\"" . $eol;
        $message .= $content . $eol;
        $message .= "--" . $uid . "--";

        if (mail($mailto, $subject, $message, $header)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
