<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url'));
        $this->load->library(array('session', 'sendsms'));
        $this->load->model(array('student_model', 'admin_model', 'homework_model'));
    }

    public function index() {
        $this->load->view('welcome_message');
    }

    public function webService() {
        $this->load->view('webservices');
    }

    /* Parent Login */

    public function parentLogin() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            $result = $this->student_model->parentLogin($ldata['admissionNumber'], $ldata['phone'], $ldata['user_id']);
            $result['stage_name'] = 'leela mahal';
            $result['stage_latitude'] = '13.6411';
            $result['stage_longitude'] = '79.4262';
            if (!empty($result) && isset($result)) {
                if (!empty($ldata['device_token']) && isset($ldata['device_token'])) {
                    $device_token = $ldata['device_token'];
                } else {
                    $device_token = '';
                }
                $where = array('id' => $result['id']);
                $update_data = array('platform' => 'Android', 'device_token' => $device_token);
                $this->global_model->update_by("student_profile_info", $where, $update_data);
//                } else {
//                    $data['status'] = 'fail';
//                    $data['message'] = 'Device token is required';
//                    $data['content'] = json_encode(array("response" => $data));
//                }
                $data['status'] = 'success';
                $data['message'] = 'User logged successfully';
                $data['userdata'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Login Failed. Please provide valid details.';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* teacher login */

    public function teacherLogin() {
        $data = array();
        $ldata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($ldata) && isset($ldata)) {
            $result = $this->student_model->teacherLogin($ldata['teacher_name'], md5($ldata['password']), $ldata['user_id']);
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['message'] = 'Teacher logged successfully';
                $data['userdata'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Login Failed. Please provide valid details.';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* Student Profile details */

    public function toGetStudentProfile() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['admissionNumber']) && isset($rdata['admissionNumber'])) {
            $result = $this->student_model->toGetStudentProfile($rdata['admissionNumber'], $rdata['user_id']);
            if (!empty($result['student_image']) && file_exists(FCPATH . '/uploads/profile_pics/' . $result['student_image'])) {
                $result['student_image'] = base_url() . 'uploads/profile_pics/' . $result['student_image'];
            }
            $result['student_dob'] = date('dS-F-Y', strtotime($result['student_dob']));
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['student_profile'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* student remarks details */

    public function toGetStudentRemarks() {
        $data = array();
        $dateArray = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['admissionNumber']) && isset($rdata['admissionNumber'])) {
            if (!empty($rdata['remark_date']) && isset($rdata['remark_date'])) {
                $remark_date = $rdata['remark_date'];
            } else {
                $remark_date = '';
            }
            $result = $this->student_model->toGetStudentRemarks('student_admission_id', $rdata['admissionNumber'], 'student_remarks', $remark_date, $rdata['user_id']);
            if (!empty($result) && isset($result)) {
                foreach ($result as $res) {
                    $dateArray1[$res['remark_date']]['date'] = date('dS-F-Y', strtotime($res['remark_date']));
                    $dateArray1[$res['remark_date']]['remark'][] = $res;
                }
                $data['status'] = 'success';
                $data['student_remarks'] = array_values($dateArray1);
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* student home work details */

    public function toGetStudentHomeWork() {
        $data = array();
        $dateArray = array();
        $dateArray1 = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['admissionNumber']) && isset($rdata['admissionNumber'])) {
            $studentInfo = $this->student_model->getdetailsById('sch_admission_id', $rdata['admissionNumber'], 'student_profile_info', $rdata['user_id']);
            if (!empty($studentInfo) && isset($studentInfo)) {
                if (!empty($rdata['home_work_date']) && isset($rdata['home_work_date'])) {
                    $home_work_date = $rdata['home_work_date'];
                } else {
                    $home_work_date = '';
                }
                $result = $this->student_model->toGetStudentHomeWork($studentInfo['student_class_id'], $studentInfo['student_section_id'], $home_work_date, $rdata['user_id']);

                if (!empty($result) && isset($result)) {

                    foreach ($result as $res) {
                        $dateArray1[$res['home_work_date']]['date'] = date('dS-F-Y', strtotime($res['home_work_date']));
                        $dateArray1[$res['home_work_date']]['homework'][] = $res;
                    }
                    $data['status'] = 'success';
                    $data['student_homework'] = array_values($dateArray1);
                    $data['content'] = json_encode(array("response" => $data));
                } else {
                    $data['status'] = 'fail';
                    $data['message'] = 'No Data Found';
                    $data['content'] = json_encode(array("response" => $data));
                }
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* To Add Student Homework from mobile app */

    public function toAddStudentHomeWork() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['user_id']) && isset($rdata['user_id'])) {
            $schoolInfo = $this->student_model->getdetailsById('id', $rdata['user_id'], 'schools');
            $class_id = $rdata['class_id'];
            $section_id = $rdata['section_id'];
            $save_homework_data = array(
                'userid' => $rdata['user_id'],
                'class_id' => $class_id,
                'section_id' => $section_id,
                'home_work_subject' => isset($rdata['home_work_subject']) ? strtoupper($rdata['home_work_subject']) : 'Homework',
                'home_work_name' => $rdata['home_work_name'],
                'home_work_date' => $rdata['home_work_date'],
                'home_channel' => "mobile"
            );
            $this->global_model->save_data('student_home_work', $save_homework_data);
            $classes = $this->admin_model->toGetClassName($class_id);
            $sectons = $this->admin_model->toGetSectionName($section_id);
            $students = $this->admin_model->getStudentsInfo($rdata['user_id'], $class_id, $section_id);
            if (!empty($students) && isset($students)) {
                $hw_date = date('dS-F-Y', strtotime($save_homework_data['home_work_date']));
                $hwmessage = "Homework for " . $sectons['section_name'] . " in " . $classes['class_name'] . "- " . $hw_date . "\r\n" . $save_homework_data['home_work_name'] . "\r\n" . "From" . "\r\n" . $schoolInfo['institutename'];

                foreach ($students as $student):
                    if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                        $this->sendsms->send_sms($student['student_mobile'], $hwmessage);
                    }
                endforeach;
            }
            $data['status'] = 'success';
            $data['student_homework'] = "Homework Added Successfully!..";
            $data['content'] = json_encode(array("response" => $data));
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* to get homework messages */

    public function toGetHomeWorkMessages() {
        $data = array();
//        $dateArray1 = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['user_id']) && isset($rdata['user_id'])) {
            $result = $this->homework_model->manage_home_works($rdata['user_id'], '', '', '');
            if (!empty($result) && isset($result)) {
//                foreach ($result as $res) {
//                    $dateArray1[$res['home_work_date']]['date'] = date('dS-F-Y', strtotime($res['home_work_date']));
//                    $dateArray1[$res['home_work_date']]['homework'][] = $res;
//                }
                $data['status'] = 'success';
                $data['homeworks'] = array_values($result);
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* end here */

    /* to Get homework data by id */

    public function toGetHomeWorkById() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['home_work_id']) && isset($rdata['home_work_id'])) {
            $result['homeworks'] = $this->homework_model->edit_mobile_home_work(array('ss.id' => $rdata['home_work_id']));
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['homework'] = $result['homeworks'][0];
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* end here */

    /* to Update homework data by id */

    public function toUpdateHomeWorkById() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['home_work_id']) && isset($rdata['home_work_id'])) {
            $class_id = $rdata['class_id'];
            $section_id = $rdata['section_id'];
            $save_homework_data = array(
                'class_id' => $class_id,
                'section_id' => $section_id,
                'home_work_subject' => isset($rdata['home_work_subject']) ? strtoupper($rdata['home_work_subject']) : 'Homework',
                'home_work_name' => $rdata['home_work_name'],
                'home_work_date' => $rdata['home_work_date']
            );
            $this->global_model->update_by('student_home_work', array('id' => $rdata['home_work_id']), $save_homework_data);
            $data['status'] = 'success';
            $data['message'] = 'Homework data updated successfully';
            $data['content'] = json_encode(array("response" => $data));
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* end here */


    /* to get classes having students only */

    public function toGetClassesHavingStudents() {
        $data = array();
        $dataNew = array();
        $dataNew['classes'] = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['user_id']) && isset($rdata['user_id'])) {
            $classes = $this->homework_model->getClasses($rdata['user_id']);
            if (!empty($classes) && isset($classes)) {
                foreach ($classes as $cls):
                    $studentCount = $this->homework_model->toCheckStudentsWithClass($cls['id']);
                    if ($studentCount) {
                        $dataNew['classes'][] = $cls;
                    }
                endforeach;
                if (!empty($dataNew['classes'])) {
                    $data['status'] = 'success';
                    $data['classes'] = array_values($dataNew['classes']);
                    $data['content'] = json_encode(array("response" => $data));
                } else {
                    $data['status'] = 'fail';
                    $data['message'] = 'No Data Found';
                    $data['content'] = json_encode(array("response" => $data));
                }
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* end here */

    /* to get sections having classes students only */

    public function toGetSectionsHavingStudents() {
        $data = array();
        $dataNew = array();
        $dataNew['sections'] = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['class_id']) && isset($rdata['class_id'])) {
            $class_id = $rdata['class_id'];
            $where = array('class_id' => $class_id, 'status' => 'A');
            $sections = $this->homework_model->toGetSectionsByClass($where);
            if (!empty($sections) && isset($sections)) {
                foreach ($sections as $sec):
                    $studentCount = $this->homework_model->toCheckStudentsWithSection($sec['id']);
                    if ($studentCount) {
                        $dataNew['sections'][] = $sec;
                    }
                endforeach;
                if (!empty($dataNew['sections'])) {
                    $data['status'] = 'success';
                    $data['sections'] = array_values($dataNew['sections']);
                    $data['content'] = json_encode(array("response" => $data));
                } else {
                    $data['status'] = 'fail';
                    $data['message'] = 'No Data Found';
                    $data['content'] = json_encode(array("response" => $data));
                }
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* end here */

    /* student attendance details */

    public function toGetStudentAttendanceList() {
        $data = array();
        $dateArray = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['admissionNumber']) && isset($rdata['admissionNumber'])) {
            if (!empty($rdata['attendance_date']) && isset($rdata['attendance_date'])) {
                $attendance_date = $rdata['attendance_date'];
            } else {
                $attendance_date = '';
            }
            $result = $this->student_model->toGetStudentAttendanceList($rdata['admissionNumber'], $attendance_date, $rdata['user_id']);
            if (!empty($result) && isset($result)) {
                foreach ($result as $k => $res):
                    if ($res['status'] === 'M') {
                        $result[$k]['absent'] = 'Morning Session';
                    } elseif ($res['status'] === 'E') {
                        $result[$k]['absent'] = 'Afternoon Session';
                    } else {
                        $result[$k]['absent'] = 'Full Day';
                    }
                endforeach;
                foreach ($result as $res) {
                    $dateArray[$res['date']]['date'] = date('dS-F-Y', strtotime($res['date']));
                    $dateArray[$res['date']]['attendance'][] = $res;
                }
                $data['status'] = 'success';
                $data['student_attendance'] = array_values($dateArray);
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* student fee details */

    public function toGetStudentFeeDetails() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['admissionNumber']) && isset($rdata['admissionNumber'])) {
            $result['feeDetails'] = $this->student_model->toGetStudentFeeDetails($rdata['admissionNumber'], $rdata['user_id']);
            if (!empty($result['feeDetails']['last_date_to_pay'])) {
                $result['feeDetails']['last_date_to_pay'] = date('dS-F-Y', strtotime($result['feeDetails']['last_date_to_pay']));
            }
            $result['previousfeeInfo'] = $this->student_model->getStudentPreviousFeeInfoByAdmission($rdata['admissionNumber'], $rdata['user_id']);
            if (!empty($result['previousfeeInfo']) && isset($result['previousfeeInfo'])) {
                foreach ($result['previousfeeInfo'] as $k => $fee):
                    $result['previousfeeInfo'][$k]['term_paid_date'] = date('dS-F-Y', strtotime($fee['term_paid_date']));
                endforeach;
            }
            if (!empty($result) && isset($result)) {
                $data['status'] = 'success';
                $data['student_fee_details'] = $result;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* admin messages list */

    public function toGetMessages() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['message_date']) && isset($rdata['message_date'])) {
            $message_date = $rdata['message_date'];
        } else {
            $message_date = '';
        }
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        $result['messages'] = $this->student_model->toGetMessages($message_date, $rdata['user_id']);
        if (!empty($result['messages']) && isset($result['messages'])) {
            foreach ($result['messages'] as $k => $message):
                $result['messages'][$k]['message_date'] = date('dS-F-Y', strtotime($message['message_date']));
            endforeach;
            $data['status'] = 'success';
            $data['institutemessage_info'] = $result['messages'];
            $data['content'] = json_encode(array("response" => $data));
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'No Data Found';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* to get exam types */

    public function toGetExamTypes() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if (!empty($rdata['user_id']) && isset($rdata['user_id'])) {
            $examtypes = $this->student_model->toGetExamTypes($rdata['user_id']);
            if (!empty($examtypes) && isset($examtypes)) {
                $data['status'] = 'success';
                $data['examTypes'] = $examtypes;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    /* student Examnation Marks */

    public function toGetStudentExamResults() {
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        $marksList = array();
        $total_marks = 0;
        $achieved_marks = 0;
        $common_id = 0;
        if (!empty($rdata['exam_type']) && isset($rdata['exam_type'])) {
            $exam_type = $rdata['exam_type'];
        } else {
            $exam_type = '';
        }
        if (!empty($rdata['admissionNumber']) && isset($rdata['admissionNumber'])) {
            $studentInfo = $this->student_model->toGetStudentProfile($rdata['admissionNumber'], $rdata['user_id']);
            $marks = $this->student_model->toGetStudentExamResults($rdata['admissionNumber'], $exam_type, $rdata['user_id']);
            if (!empty($marks) && isset($marks)) {
                foreach ($marks as $k => $mark):
                    if ($common_id !== $mark['common_id'] && $k != 0) {
                        $total_marks = 0;
                        $achieved_marks = 0;
                    }
                    $common_id = $mark['common_id'];
                    $mark['exam_date'] = date('dS-F-Y', strtotime($mark['exam_date']));
                    $total_marks += $marks[$k]['total_marks'];
                    $achieved_marks += $marks[$k]['achieved_marks'];
                    $marksList[$mark['common_id']]['marks'][] = $mark;
                    $marksList[$mark['common_id']]['totalmarks'] = $total_marks;
                    $marksList[$mark['common_id']]['achievedmarks'] = $achieved_marks;
                    $marksList[$mark['common_id']]['marks_percentage'] = sprintf('%.2f', ($achieved_marks / $total_marks) * 100);
                endforeach;
                $data['status'] = 'success';
                $data['marksInfo'] = array_values($marksList);
                $data['studentInfo'] = $studentInfo;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'No Data Found';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }

        $this->load->view('blank', $data);
    }

    /* to change password */

    public function toChanagePasswordForAdmin() {
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if ((!empty($rdata['password']) && isset($rdata['password'])) && (!empty($rdata['id']) && isset($rdata['id']))) {
            if ($rdata['password'] == $rdata['confirm_password']) {
                $where = array('id' => $rdata['id']);
                $update_data = array('password' => md5($rdata['password']));
                $this->global_model->update_by("schools", $where, $update_data);
                $data['status'] = 'success';
                $data['passwordsuccess'] = "Your Password was successfully changed!..";
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Your Password and confirm password not matching';
                $data['content'] = json_encode(array("response" => $data));
            }
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toGetStudentBirthdayDates() {
        $students = $this->student_model->toGetStudentBirthdayDates();
        if (!empty($students) && isset($students)) {
            foreach ($students as $student):
                if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                    $schoolInfo = $this->student_model->toGetSchoolName($student['userid']);
                    if (!empty($schoolInfo) && isset($schoolInfo)) {
                        $schoolName = $schoolInfo['institutename'];
                    } else {
                        $schoolName = "Patashala";
                    }
                    $message = "DEAR " . strtoupper($student['student_name']) . " WISHING YOU MANY MORE HAPPY RETURNS OF THE DAY" . "\r\n" . "FROM" . "\r\n" . $schoolName;
                    $this->sendsms->send_sms($student['student_mobile'], $message);
                }
            endforeach;
        }
    }

    public function toSendScheduleMessages() {
        $messages = $this->student_model->toSendScheduleMessages();
        if (!empty($messages) && isset($messages)) {
            foreach ($messages as $message):
                if (!empty($message['userid']) && isset($message['userid'])) {
                    if (!empty($message['grades']) && isset($message['grades'])) {
                        $classes = explode(',', $message['grades']);
                        for ($i = 0; $i < count($classes); $i++):
                            $students = $this->student_model->toGetStudentsByGrade($classes[$i], $message['userid']);
                            if (!empty($students) && isset($students)) {
                                foreach ($students as $student):
                                    if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                                        $schoolInfo = $this->student_model->toGetSchoolName($student['userid']);
                                        if (!empty($schoolInfo) && isset($schoolInfo)) {
                                            $schoolName = $schoolInfo['institutename'];
                                        } else {
                                            $schoolName = "Patashala";
                                        }
                                        $message = $message['message'] . "\r\n" . "FROM" . "\r\n" . $schoolName;
                                        $this->sendsms->send_sms($student['student_mobile'], $message);
                                    }
                                endforeach;
                            }
                        endfor;
                    } else if (!empty($message['activities']) && isset($message['activities'])) {
                        $classes = explode(',', $message['activities']);
                        for ($i = 0; $i < count($classes); $i++):
                            $students = $this->student_model->toGetStudentsByActivity($classes[$i], $message['userid']);
                            if (!empty($students) && isset($students)) {
                                foreach ($students as $student):
                                    if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                                        $schoolInfo = $this->student_model->toGetSchoolName($student['userid']);
                                        if (!empty($schoolInfo) && isset($schoolInfo)) {
                                            $schoolName = $schoolInfo['institutename'];
                                        } else {
                                            $schoolName = "Patashala";
                                        }
                                        $message = $message['message'] . "\r\n" . "FROM" . "\r\n" . $schoolName;
                                        $this->sendsms->send_sms($student['student_mobile'], $message);
                                    }
                                endforeach;
                            }
                        endfor;
                    } else if (!empty($message['classes']) && isset($message['classes'])) {
                        $classes = explode(',', $message['classes']);
                        for ($i = 0; $i < count($classes); $i++):
                            $students = $this->student_model->toGetStudentsByClass($classes[$i], $message['userid']);
                            if (!empty($students) && isset($students)) {
                                foreach ($students as $student):
                                    if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                                        $schoolInfo = $this->student_model->toGetSchoolName($student['userid']);
                                        if (!empty($schoolInfo) && isset($schoolInfo)) {
                                            $schoolName = $schoolInfo['institutename'];
                                        } else {
                                            $schoolName = "Patashala";
                                        }
                                        $message = $message['message'] . "\r\n" . "FROM" . "\r\n" . $schoolName;
                                        $this->sendsms->send_sms($student['student_mobile'], $message);
                                    }
                                endforeach;
                            }
                        endfor;
                    }
                }
            endforeach;
        }
    }

    /* IVRS Code */

    public function toGetSectionsByMultipleClasses(){
        $data = array();
        $rdata = json_decode(file_get_contents("php://input"), TRUE);
        if(!empty($rdata) && isset($rdata)){
            $sections = $this->student_model->toGetSectionsByMultipleClasses($rdata);
            if(!empty($sections) && isset($sections)){
                $data['status'] = 'success';
                $data['sections'] = array_values($sections);
                $data['content'] = json_encode(array("response" => $data));    
            }else{
                $data['status'] = 'fail';
                $data['message'] = 'No data found';
                $data['content'] = json_encode(array("response" => $data));    
            }

        }else{
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function toSendIVRSMessages() {
        $data = array();
        $rdata = $this->input->post();
        echo "<pre>";print_r($rdata);exit;
//        $rdata['classes'] = array(array("class_id"=> 1, "section_id" => 1),array("class_id"=> 1, "section_id" => 1));
        foreach($rdata['classes'] as $classes):
            print_r($classes['class_id']);
        print_r($classes['section_id']);
        echo "dd";
            endforeach;
            exit;
        if (!empty($rdata['user_id']) && isset($rdata['user_id'])) {
            if(!empty($rdata['classes']) && isset($rdata['classes'])){
                foreach($rdata['classes'] as $classes):
                    $save_data = array(
                    'posted_date' => date('Y-m-d'),
                    'class_id' => isset($classes['class_id']) ? $classes['class_id'] : '',
                    'section_id' => isset($classes['section_id']) ? $classes['section_id'] : '',
                    'ivrs_type' => $rdata['ivrs_type'],
                );
                if (isset($_FILES['ivrs_audio']['name']) && !empty($_FILES['ivrs_audio']['name'])) {
                    $uploadFile = $this->do_upload('ivrs_audio', '*', 2048);
                    $audio = array('ivrs_audio' => $uploadFile);
                    $save_data = array_merge($save_data, $audio);
                }
                $ivrs_id = $this->global_model->save_data('ivrs_messages', $save_data);
                endforeach;
            
            if (!empty($ivrs_id) && isset($ivrs_id)) {
                $auidoUrl = base_url() . '/uploads/ivrs_audio/' . $audio['ivrs_audio'];
                $eurl = "http://skfpostbox.com/httpapi/voiceupload?token=c7b12f5e6af095664709e038eaed21e2&fileurl=" . $auidoUrl;
                $ch = curl_init();
                curl_setopt($ch, CURLOPT_POST, 0);
                curl_setopt($ch, CURLOPT_URL, $eurl);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                $output = curl_exec($ch);
                curl_close($ch);
//                $this->ivrsGeneralMessage($output, )
                $data['status'] = 'success';
                $data['last_id'] = $output;
                $data['content'] = json_encode(array("response" => $data));
            } else {
                $data['status'] = 'fail';
                $data['message'] = 'Something went wrong.. please try again later';
                $data['content'] = json_encode(array("response" => $data));
            }
            }else{
                $data['status'] = 'fail';
                $data['message'] = 'Please select at least one class and section';
                $data['content'] = json_encode(array("response" => $data));
            }
            
        } else {
            $data['status'] = 'fail';
            $data['message'] = 'Please provide required data';
            $data['content'] = json_encode(array("response" => $data));
        }
        $this->load->view('blank', $data);
    }

    public function ivrsGeneralMessage($ivrs_data) {

        $classes = $this->admin_model->toGetClassName($ivrs_data['class_id']);
        $sectons = $this->admin_model->toGetSectionName($ivrs_data['section_id']);
        $students = $this->admin_model->getStudentsInfo($data['user_data']['user_id'], $ivrs_data['class_id'], $ivrs_data['section_id']);
        if (!empty($students) && isset($students)) {
            $hw_date = date('dS-F-Y');
            $hwmessage = "Homework for " . $sectons['section_name'] . "in" . $classes['class_name'] . "- " . $hw_date . "\r\n" . $save_homework_data['home_work_name'] . "\r\n" . "From" . "\r\n" . $data['user_data']['institutename'];

            foreach ($students as $student):
                if (!empty($student['student_mobile']) && (strlen($student['student_mobile']) == '10')) {
                    $this->sendsms->send_sms($student['student_mobile'], $hwmessage);
                }
            endforeach;
        }
    }

    public function do_upload($uploadedPath, $allowTypes, $maxSize) {
        $this->load->library('upload'); // Loading upload library to upload an image
        $imgName = $_FILES['ivrs_audio']['name'];
        $splittedArray = @explode(".", $imgName);
        if (!empty($splittedArray)) {

            $uploadedFile = rand() . '_' . time() . '.' . end($splittedArray);
        }
        $arr_config = array('allowed_types' => $allowTypes,
            'upload_path' => 'uploads/' . $uploadedPath . '/',
            'max_size' => $maxSize,
            'file_name' => $uploadedFile,
            'remove_spaces' => true,
            'overwrite' => true,
        );
        $this->upload->initialize($arr_config);
        if (!$this->upload->do_upload('ivrs_audio')) {
            return $this->upload->display_errors();
        } else {
            return $uploadedFile;
        }
    }

}
