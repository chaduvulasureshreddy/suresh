<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Allinfo extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('admin_model', 'allinfo_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    public function toSendSms() {
        $this->sendsms->send_sms("8019980319", "Testing Amel Global");
    }

    /**
     *  AllInfo Index Page
     */
    public function students() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['students'] = $this->admin_model->get_students($data['user_data']['user_id'], $class_id, $section_id);
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/allinfo/manage_students');
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Manage Students
     */
    public function all_students_info() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['students'] = $this->admin_model->get_students($data['user_data']['user_id'], $class_id, $section_id);
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/allinfo/manage_students');
        $this->load->view('admin/layouts/footer');
    }

    public function toGetSectionsByClass() {
        $class_id = $this->input->post('class_id');
        $where = array('class_id' => $class_id, 'status' => 'A');
        $data['sections'] = $this->admin_model->toGetSectionsByClass($where);
        if (!empty($data['sections']) && isset($data['sections'])) {
            echo '<option value="">Select Section</option>';
            foreach ($data['sections'] as $sec):
                echo '<option value="' . $sec['id'] . '">' . $sec['section_name'] . '</option>';
            endforeach;
            exit;
        } else {
            echo "fail";
            exit;
        }
    }

    public function toGetStudentsByClassSection() {
        $class_id = $this->input->post('class_id');
        $section_id = $this->input->post('section_id');
        $where = array('student_class_id' => $class_id, 'student_section_id' => $section_id);
        $data['students'] = $this->admin_model->toGetStudentsByClassSection($where);
        if (!empty($data['students']) && isset($data['students'])) {
            foreach ($data['students'] as $sec):
                echo '<option value="' . $sec['sch_admission_id'] . '">' . $sec['student_name'] . '</option>';
            endforeach;
            exit;
        } else {
            echo "fail";
            exit;
        }
    }

    /* view student info */

    public function view_student_info($admission_id) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        if ($admission_id != '0') {
            $data['studentInfo'] = $this->admin_model->view_student_data($admission_id);
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/allinfo/view_student_info', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* to export students data to csv */

    public function export_students_data() {
        $user_data = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $students = $this->admin_model->export_students_data($user_data['user_id'], $class_id, $section_id);
        $student_headings[] = array('S.No', 'student Admission Number', 'Student Name', 'Father Name', 'Mother Name', 'Gender', 'Class Name', 'Section Name', 'contact number', 'Date of Birth', 'Address');
        foreach ($students as $key => $student):
            $studentNew['S.No'] = ++$key;
            $studentNew['sch_admission_id'] = ucfirst($student['sch_admission_id']);
            $studentNew['student_name'] = ucfirst($student['student_name']);
            $studentNew['student_father_name'] = ucfirst($student['student_father_name']);
            $studentNew['student_mother_name'] = ucfirst($student['student_mother_name']);
            if ($student['student_gender'] == 'M') {
                $studentNew['student_gender'] = 'Boy';
            } else {
                $studentNew['student_gender'] = 'Girl';
            }
            $studentNew['class_name'] = ucfirst($student['class_name']);
            $studentNew['section_name'] = ucfirst($student['section_name']);
            $studentNew['student_mobile'] = $student['student_mobile'];
            $studentNew['student_dob'] = date('dS-F-Y', strtotime($student['student_dob']));
            $studentNew['student_address'] = ucfirst($student['student_address']);
            array_push($student_headings, $studentNew);
        endforeach;
        $fileName = 'students' . rand() . '.csv';
        array_to_csv($student_headings, $fileName);
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

    /* to get Attendance Info */

    public function toDownloadAttendanceInfo() {
        $dateArray = array();
        if (!empty($_GET['startDate'])) {
            $startDate = $_GET['startDate'];
        } else {
            $startDate = '';
        }
        if (!empty($_GET['endDate'])) {
            $endDate = $_GET['endDate'];
        } else {
            $endDate = '';
        }
        if (!empty($_GET['student_admission_id'])) {
            $admission_number = $_GET['student_admission_id'];
        } else {
            $admission_number = '';
        }
        $attendanceInfo = $this->allinfo_model->toDownloadAttendanceInfo($admission_number, $startDate, $endDate);
        $data['studentInfo'] = $this->admin_model->view_student_data($admission_number);
        if (!empty($attendanceInfo) && isset($attendanceInfo)) {
            foreach ($attendanceInfo as $attendance):
                $dateArray[date("F Y", strtotime($attendance['date']))][] = $attendance;
            endforeach;
            $data['attendance'] = $dateArray;
        }else {
            $data['attendance'] = $dateArray;
        }
        $data['user_data'] = $this->session->userdata();
        $html = $this->load->view('admin/allinfo/student_attendance_pdf', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['studentInfo']['student_name']) . '_' . $startDate . '_' . $endDate . "_attendanceinfo.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

    /* to get Remarks Info */

    public function toDownloadRemarksInfo() {
        $dateArray = array();
        if (!empty($_GET['startDate'])) {
            $startDate = $_GET['startDate'];
        } else {
            $startDate = '';
        }
        if (!empty($_GET['endDate'])) {
            $endDate = $_GET['endDate'];
        } else {
            $endDate = '';
        }
        if (!empty($_GET['student_admission_id'])) {
            $admission_number = $_GET['student_admission_id'];
        } else {
            $admission_number = '';
        }
        $remarksInfo = $this->allinfo_model->toDownloadRemarksInfo($admission_number, $startDate, $endDate);
        $data['studentInfo'] = $this->admin_model->view_student_data($admission_number);
        if (!empty($remarksInfo) && isset($remarksInfo)) {
            foreach ($remarksInfo as $attendance):
                $dateArray[date("F Y", strtotime($attendance['remark_date']))][] = $attendance;
            endforeach;
            $data['remarks'] = $dateArray;
        }else {
            $data['remarks'] = $dateArray;
        }
        $data['user_data'] = $this->session->userdata();
        $html = $this->load->view('admin/allinfo/student_remarks_pdf', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['studentInfo']['student_name']) . '_' . $startDate . '_' . $endDate . "_remarks.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

    public function toDownloadHomeworkInfo() {
        $user_data = $this->session->userdata();
        $dateArray = array();
        if (!empty($_GET['startDate'])) {
            $startDate = $_GET['startDate'];
        } else {
            $startDate = '';
        }
        if (!empty($_GET['endDate'])) {
            $endDate = $_GET['endDate'];
        } else {
            $endDate = '';
        }
        if (!empty($_GET['student_admission_id'])) {
            $admission_number = $_GET['student_admission_id'];
        } else {
            $admission_number = '';
        }
        $data['studentInfo'] = $this->admin_model->view_student_data($admission_number);
        $homeworkInfo = $this->allinfo_model->toDownloadHomeworkInfo($data['studentInfo']['student_class_id'], $data['studentInfo']['student_section_id'], $startDate, $endDate);
        if (!empty($homeworkInfo) && isset($homeworkInfo)) {
            foreach ($homeworkInfo as $hwork):
                $dateArray[date("F Y", strtotime($hwork['home_work_date']))][] = $hwork;
            endforeach;
            $data['homework'] = $dateArray;
        }else {
            $data['homework'] = $dateArray;
        }
        $data['user_data'] = $this->session->userdata();
        $html = $this->load->view('admin/allinfo/student_homework_pdf', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['studentInfo']['student_name']) . '_' . $startDate . '_' . $endDate . "_homework.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

    public function toDownloadAsPdf() {
        $admission_number = trim($_GET['student_admission_id']);
        $data['studentInfo'] = $this->admin_model->view_student_data($admission_number);
        $data['user_data'] = $this->session->userdata();
        $html = $this->load->view('admin/students/studentpdf', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['studentInfo']['student_name']) . "_profile_information.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

}
