<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper(array('url', 'csv'));
        $this->load->model(array('admin_model'));
        $this->load->library(array('session', 'sendsms'));
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Admin Dashboard
     */
    public function index() {
        echo "Welcome to Amel Global Technologies";
    }

    /**
     * Edit Profile
     */
    public function edit_profile() {
        $data['user'] = $this->session->userdata();
        $data['user_data'] = (array) $this->global_model->get_by('users', array('id' => $data['user']['user_id']));
        if ($_POST) {
            $save_data = array(
                'first_name' => $this->input->post('first_name'),
                'last_name' => $this->input->post('last_name'),
                'email' => $this->input->post('email')
            );
            if (isset($_FILES['profile_pic']['name']) && !empty($_FILES['profile_pic']['name'])) {
                $imageDimensions = getimagesize($_FILES["profile_pic"]["tmp_name"]);
                $image_width_size = $imageDimensions[0];
                $image_height_size = $imageDimensions[1];
                $uploadFile = $this->do_upload('profile_pics', 'gif|jpg|png|jpeg|PNG|GIF|JPG|JPEG', 2048, $image_width_size, $image_height_size);
                $image = array('profile_pic' => $uploadFile);
                $save_data = array_merge($save_data, $image);
            }
            $save_id = $this->admin_model->update_by('users', array('id' => $data['user_data']['id']), $save_data);

            if ($save_id) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Updated Successfully'));
            } else {
                $this->session->set_flashdata('alert', array('type' => 'warning', 'message' => 'No changes to update'));
            }

            redirect(base_url() . 'admin/edit_profile');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/edit_profile', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Change Password
     */
    public function change_password() {
        $data['user_data'] = $this->session->userdata();
        if ($_POST) {
            if ($this->input->post('password') == $this->input->post('confirm_password')) {
                $save_id = $this->global_model->update_by('schools', array('id' => $data['user_data']['user_id']), array('password' => md5($this->input->post('password'))));
                if ($save_id) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Updated Successfully'));
                } else {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Updated Successfully'));
                }
            } else {
                $this->session->set_flashdata('alert', array('type' => 'error', 'message' => 'Password and Confirm passwords are not matched.'));
            }
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/change_password', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Manage Students
     */
    public function manage_students() {
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $data['user_data'] = $this->session->userdata();
        $data['students'] = $this->admin_model->get_students($data['user_data']['user_id'], $class_id, $section_id);
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/students/manage_students');
        $this->load->view('admin/layouts/footer');
    }

    /* To Check student exist or not by using admission number */

    public function toCheckStudent() {
        $admission_number = trim($this->input->post('admission_number'));
        if (!empty($admission_number)) {
            $result = $this->admin_model->getStudentDetailsById('sch_admission_id', $admission_number, 'student_profile_info');
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Add Student
     */
    public function add_student() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $data['buses'] = $this->admin_model->get_all('student_buses', $data['user_data']['user_id']);
        if ($_POST) {
            $getData = $this->input->post();
            $studentInfo = $this->admin_model->getdetailsById('sch_admission_id', $getData['admissionnumber'], 'student_profile_info');
            //echo $this->db->last_query();
            //print_r($studentInfo);exit;

            if (empty($studentInfo)) {
                $save_student_data = array(
                    'userid' => $data['user_data']['user_id'],
                    'student_name' => isset($getData['student_name']) ? strtoupper($getData['student_name']) : '',
                    'sch_admission_id' => isset($getData['admissionnumber']) ? trim($getData['admissionnumber']) : '',
                    'student_father_name' => isset($getData['student_father_name']) ? strtoupper($getData['student_father_name']) : '',
                    'student_mother_name' => isset($getData['student_mother_name']) ? strtoupper($getData['student_mother_name']) : '',
                    'student_dob' => isset($getData['student_dob']) ? $getData['student_dob'] : '',
                    'student_blood_group' => isset($getData['student_blood_group']) ? $getData['student_blood_group'] : '',
                    'student_gender' => isset($getData['student_gender']) ? $getData['student_gender'] : '',
                    'student_mobile' => isset($getData['student_mobile']) ? $getData['student_mobile'] : '',
                    'student_caste' => isset($getData['student_caste']) ? $getData['student_caste'] : '',
                    'student_address' => isset($getData['address']) ? $getData['address'] : '',
                    'student_class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                    'student_section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                    'student_fee' => isset($getData['student_fee']) ? $getData['student_fee'] : '',
                    'bus_fee' => isset($getData['bus_fee']) ? $getData['bus_fee'] : '',
                    'books_fee' => isset($getData['books_fee']) ? $getData['books_fee'] : '',
                    'student_bus_no' => isset($getData['student_bus_no']) ? $getData['student_bus_no'] : '',
                    'student_joined_class' => isset($getData['student_joined_class']) ? $getData['student_joined_class'] : '',
                    'student_joining_date' => isset($getData['student_joining_date']) ? $getData['student_joining_date'] : '',
                    'student_documents' => isset($getData['student_documents']) ? $getData['student_documents'] : ''
                );
                $save_fee_info = array(
                    'userid' => $data['user_data']['user_id'],
                    'student_admission_id' => isset($getData['admissionnumber']) ? $getData['admissionnumber'] : '',
                    'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                    'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                    'total_amount' => isset($getData['student_fee']) ? $getData['student_fee'] : '',
                    'paid_amount' => 0,
                    'balance_amount' => isset($getData['student_fee']) ? $getData['student_fee'] : ''
                );
                $save_bus_fee_info = array(
                    'userid' => $data['user_data']['user_id'],
                    'student_admission_id' => isset($getData['admissionnumber']) ? $getData['admissionnumber'] : '',
                    'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                    'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                    'total_bus_amount' => isset($getData['bus_fee']) ? $getData['bus_fee'] : '',
                    'paid_bus_amount' => 0,
                    'concession_bus_amount' => 0,
                    'balance_bus_amount' => isset($getData['bus_fee']) ? $getData['bus_fee'] : ''
                );
                $save_books_fee_info = array(
                    'userid' => $data['user_data']['user_id'],
                    'student_admission_id' => isset($getData['admissionnumber']) ? $getData['admissionnumber'] : '',
                    'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                    'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                    'total_books_amount' => isset($getData['books_fee']) ? $getData['books_fee'] : '',
                    'paid_books_amount' => 0,
                    'concession_books_amount' => 0,
                    'balance_books_amount' => isset($getData['books_fee']) ? $getData['books_fee'] : ''
                );

                if (isset($_FILES['profile_pic']['name']) && !empty($_FILES['profile_pic']['name'])) {
                    $imageDimensions = getimagesize($_FILES["profile_pic"]["tmp_name"]);
                    $image_width_size = $imageDimensions[0];
                    $image_height_size = $imageDimensions[1];
                    $uploadFile = $this->do_upload('profile_pics', 'gif|jpg|png|jpeg|PNG|GIF|JPG|JPEG', 2048, $image_width_size, $image_height_size);
                    $image = array('student_image' => $uploadFile);
                    $save_student_data = array_merge($save_student_data, $image);
                }

                $save_user = $this->global_model->save_data('student_profile_info', $save_student_data);
                $this->global_model->save_data('student_fee', $save_fee_info);
                $this->global_model->save_data('student_bus_fee', $save_bus_fee_info);
                $this->global_model->save_data('student_books_fee', $save_books_fee_info);
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Student added Successfully'));
                redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
            } else {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Student already exist with given admission number'));
            }
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/students/add_student', $data);
        $this->load->view('admin/layouts/footer');
    }

    public function toGetSectionsByClass() {
        $class_id = $this->input->post('class_id');
        $where = array('class_id' => $class_id, 'status' => 'A');
        $data['sections'] = $this->admin_model->toGetSectionsByClass($where);
        if (!empty($data['sections']) && isset($data['sections'])) {
            echo '<option value="">Select Section</option>';
            foreach ($data['sections'] as $sec):
                echo '<option value="' . $sec['id'] . '">' . $sec['section_name'] . '</option>';
            endforeach;
            exit;
        } else {
            echo "fail";
            exit;
        }
    }

    /* To Check Section Name exist or not by using Name */

    public function toCheckSectionName() {
        $section_name = trim($this->input->post('section_name'));
        $class_id = $this->input->post('class_id');
        $data['user_data'] = $this->session->userdata();
        $section_id = $this->input->post('section_id');
        if (!empty($section_name)) {
            $result = $this->admin_model->toCheckSectionName($section_name, $class_id, $section_id, 'student_class_sections', $data['user_data']['user_id']);
            if (!empty($result) && isset($result)) {
                echo "success";
                exit;
            } else {
                echo "fail";
                exit;
            }
        } else {
            echo "fail";
            exit;
        }
    }

    public function toGetStudentsByClassSection() {
        $class_id = $this->input->post('class_id');
        $section_id = $this->input->post('section_id');
        $where = array('student_class_id' => $class_id, 'student_section_id' => $section_id);
        $data['students'] = $this->admin_model->toGetStudentsByClassSection($where);
        if (!empty($data['students']) && isset($data['students'])) {
            foreach ($data['students'] as $sec):
                echo '<option value="' . $sec['sch_admission_id'] . '">' . $sec['student_name'] . '</option>';
            endforeach;
            exit;
        } else {
            echo "fail";
            exit;
        }
    }

    /**
     * Delete Student
     * @param type $id
     */
    public function delete_student($admission_id = 0) {
        if ($admission_id != '0') {
//            $this->global_model->update_by('student_admission_info', array('admissionnumber' => $admission_id), array('status' => 'D'));
            $delete_student = $this->global_model->update_by('student_profile_info', array('sch_admission_id' => $admission_id), array('student_status' => 'D'));
            $this->global_model->update_by('student_bus_fee', array('student_admission_id' => $admission_id), array('busfee_status' => 'D'));
            $this->global_model->update_by('student_books_fee', array('student_admission_id' => $admission_id), array('booksfee_status' => 'D'));
            $this->global_model->update_by('student_fee', array('student_admission_id' => $admission_id), array('fee_status' => 'D'));
            if ($delete_student) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Student deleted successfully'));
            }
            redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
        }
    }

    public function delete_multiple_students() {
        $ids = explode(',', $_POST['ids']);
        foreach ($ids as $admission_id):
            $delete_student = $this->global_model->update_by('student_profile_info', array('id' => $admission_id), array('student_status' => 'D'));
        endforeach;
        if ($delete_student) {
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Students deleted successfully'));
        }
        redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
    }

    /**
     * Edit User
     * @param type $id
     */
    public function edit_student($admission_id) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        $data['buses'] = $this->admin_model->get_all('student_buses', $data['user_data']['user_id']);
        $getData = $this->input->post();
        if ($admission_id != '0') {
            $data['user_details'] = $this->admin_model->get_student_data($admission_id);
            if ($_POST) {
                $feeDetails = $this->admin_model->toGetStudentFeeInfo($admission_id);
                $busfeeDetails = $this->admin_model->toGetStudentBusFeeInfo($admission_id);
                $booksfeeDetails = $this->admin_model->toGetStudentBooksFeeInfo($admission_id);
                if (!empty($feeDetails) && isset($feeDetails)) {
                    $student_fee_info = $getData['student_fee'];
                    $paid_fee_info = $feeDetails['paid_amount'] - $feeDetails['concession_amount'];
                    if ($paid_fee_info > $student_fee_info) {
                        $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Fee Amount is lessthan already paid amount!.. Please enter valid amount.'));
                        redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
                    }
                }
                if (!empty($busfeeDetails) && isset($busfeeDetails)) {
                    $student_bus_fee_info = $getData['bus_fee'];
                    $paid_bus_fee_info = $busfeeDetails['paid_bus_amount'] - $busfeeDetails['concession_bus_amount'];
                    if ($paid_bus_fee_info > $student_bus_fee_info) {
                        $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Bus Fee Amount is lessthan already paid amount!.. Please enter valid amount.'));
                        redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
                    }
                }
                if (!empty($booksfeeDetails) && isset($booksfeeDetails)) {
                    $student_books_fee_info = $getData['books_fee'];
                    $paid_books_fee_info = $booksfeeDetails['paid_books_amount'] - $booksfeeDetails['concession_books_amount'];
                    if ($paid_books_fee_info > $student_books_fee_info) {
                        $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Books Fee Amount is lessthan already paid amount!.. Please enter valid amount.'));
                        redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
                    }
                }
                $save_student_data = array(
                    'student_name' => isset($getData['student_name']) ? strtoupper($getData['student_name']) : '',
                    'sch_admission_id' => isset($getData['admissionnumber']) ? trim($getData['admissionnumber']) : '',
                    'student_father_name' => isset($getData['student_father_name']) ? strtoupper($getData['student_father_name']) : '',
                    'student_mother_name' => isset($getData['student_mother_name']) ? strtoupper($getData['student_mother_name']) : '',
                    'student_dob' => isset($getData['student_dob']) ? $getData['student_dob'] : '',
                    'student_blood_group' => isset($getData['student_blood_group']) ? $getData['student_blood_group'] : '',
                    'student_gender' => isset($getData['student_gender']) ? $getData['student_gender'] : '',
                    'student_mobile' => isset($getData['student_mobile']) ? $getData['student_mobile'] : '',
                    'student_caste' => isset($getData['student_caste']) ? $getData['student_caste'] : '',
                    'student_address' => isset($getData['address']) ? $getData['address'] : '',
                    'student_class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                    'student_section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                    'student_fee' => isset($getData['student_fee']) ? $getData['student_fee'] : '',
                    'bus_fee' => isset($getData['bus_fee']) ? $getData['bus_fee'] : '',
                    'books_fee' => isset($getData['books_fee']) ? $getData['books_fee'] : '',
                    'student_bus_no' => isset($getData['student_bus_no']) ? $getData['student_bus_no'] : '',
                    'student_joined_class' => isset($getData['student_joined_class']) ? $getData['student_joined_class'] : '',
                    'student_joining_date' => isset($getData['student_joining_date']) ? $getData['student_joining_date'] : '',
                    'student_documents' => isset($getData['student_documents']) ? $getData['student_documents'] : ''
                );

                $id = $this->input->post('studentId');
                if (isset($_FILES['profile_pic']['name']) && !empty($_FILES['profile_pic']['name'])) {
                    $imageDimensions = getimagesize($_FILES["profile_pic"]["tmp_name"]);
                    $image_width_size = $imageDimensions[0];
                    $image_height_size = $imageDimensions[1];
                    $uploadFile = $this->do_upload('profile_pics', 'gif|jpg|png|jpeg|PNG|GIF|JPG|JPEG', 2048, $image_width_size, $image_height_size);
                    $image = array('student_image' => $uploadFile);
                    $save_student_data = array_merge($save_student_data, $image);
                }

                $save_user = $this->global_model->update_by('student_profile_info', array('id' => $id), $save_student_data);

                $save_student_remark_data = array(
                    'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                    'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : ''
                );
                $this->global_model->update_by('student_remarks', array('student_admission_id' => $admission_id), $save_student_remark_data);

                if (!empty($feeDetails) && isset($feeDetails)) {
                    $balance_amount = $getData['student_fee'] - $feeDetails['paid_amount'] - $feeDetails['concession_amount'];
                    $save_student_fee_data = array(
                        'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                        'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                        'total_amount' => isset($getData['student_fee']) ? $getData['student_fee'] : '',
                        'balance_amount' => $balance_amount
                    );
                    $this->global_model->update_by('student_fee', array('student_admission_id' => $admission_id), $save_student_fee_data);
                }
                if (!empty($busfeeDetails) && isset($busfeeDetails)) {
                    $balance_amount = $getData['bus_fee'] - $busfeeDetails['paid_bus_amount'] - $busfeeDetails['concession_bus_amount'];
                    $save_student_bus_fee_data = array(
                        'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                        'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                        'total_bus_amount' => isset($getData['bus_fee']) ? $getData['bus_fee'] : '',
                        'balance_bus_amount' => $balance_amount
                    );
                    $this->global_model->update_by('student_bus_fee', array('student_admission_id' => $admission_id), $save_student_bus_fee_data);
                }
                if (!empty($booksfeeDetails) && isset($booksfeeDetails)) {
                    $balance_amount = $getData['books_fee'] - $booksfeeDetails['paid_books_amount'] - $booksfeeDetails['concession_books_amount'];
                    $save_student_books_fee_data = array(
                        'class_id' => isset($getData['student_class_id']) ? $getData['student_class_id'] : '',
                        'section_id' => isset($getData['student_section_id']) ? $getData['student_section_id'] : '',
                        'total_books_amount' => isset($getData['books_fee']) ? $getData['books_fee'] : '',
                        'balance_books_amount' => $balance_amount
                    );
                    $this->global_model->update_by('student_books_fee', array('student_admission_id' => $admission_id), $save_student_books_fee_data);
                }
                if ($save_user) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Student data updated successfully'));
                    redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
                }
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/students/edit_student', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* view student info */

    public function view_student($admission_id) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->admin_model->get_all('student_classes', $data['user_data']['user_id']);
        if ($admission_id != '0') {
            $data['studentInfo'] = $this->admin_model->view_student_data($admission_id);
            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/students/view_student', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /* to export students data to csv */

    public function export_students_data() {
        $user_data = $this->session->userdata();
        if (!empty($_GET['class_id'])) {
            $class_id = $_GET['class_id'];
        } else {
            $class_id = '';
        }
        if (!empty($_GET['section_id'])) {
            $section_id = $_GET['section_id'];
        } else {
            $section_id = '';
        }
        $students = $this->admin_model->export_students_data($user_data['user_id'], $class_id, $section_id);
        $student_headings[] = array('S.No', 'student Admission Number', 'Student Name', 'Father Name', 'Mother Name', 'Gender', 'Class Name', 'Section Name', 'contact number', 'Date of Birth', 'Student Joined Date', 'Student Joined Class', 'Student Bus Number', 'Documents', 'Address');
        foreach ($students as $key => $student):
            $studentNew['S.No'] = ++$key;
            $studentNew['sch_admission_id'] = ucfirst($student['sch_admission_id']);
            $studentNew['student_name'] = ucfirst($student['student_name']);
            $studentNew['student_father_name'] = ucfirst($student['student_father_name']);
            $studentNew['student_mother_name'] = ucfirst($student['student_mother_name']);
            if ($student['student_gender'] == 'M') {
                $studentNew['student_gender'] = 'Boy';
            } else {
                $studentNew['student_gender'] = 'Girl';
            }
            $studentNew['class_name'] = ucfirst($student['class_name']);
            $studentNew['section_name'] = ucfirst($student['section_name']);
            $studentNew['student_mobile'] = $student['student_mobile'];
            $studentNew['student_dob'] = date('dS-F-Y', strtotime($student['student_dob']));
            $studentNew['student_joining_date'] = date('dS-F-Y', strtotime($student['student_joining_date']));
            $studentNew['student_joined_class'] = ucfirst($student['student_joined_class']);
            $studentNew['student_bus_no'] = ucfirst($student['bus_no']);
            $studentNew['student_documents'] = ucfirst(str_replace(',', '$', $student['student_documents']));
            $studentNew['student_address'] = ucfirst(str_replace(',', '$', $student['student_address']));
            array_push($student_headings, $studentNew);
        endforeach;
        $fileName = 'students' . rand() . '.csv';
        array_to_csv($student_headings, $fileName);
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

    /*
     * Function is used to upload the files
     */

    public function do_upload($uploadedPath, $allowTypes, $maxSize, $imgWidth = '', $imgheight = '') {
        $this->load->library('upload'); // Loading upload library to upload an image
        $this->load->library('image_lib'); // Loading image library to resize an image
        $imgName = $_FILES['profile_pic']['name'];

        $splittedArray = @explode(".", $imgName);
        if (!empty($splittedArray)) {

            $uploadedFile = $this->get_random_code() . '_' . time() . '.' . end($splittedArray);
        }
        $arr_config = array('allowed_types' => $allowTypes,
            'upload_path' => 'uploads/' . $uploadedPath . '/',
            'max_size' => $maxSize,
            'file_name' => $uploadedFile,
            'remove_spaces' => true,
            'overwrite' => true,
        );
        $this->upload->initialize($arr_config);

        if (!$this->upload->do_upload('profile_pic')) {
            return $this->upload->display_errors();
        } else {

            $resizeconfig = array();
            $resizeconfig['image_library'] = 'GD2';
            $resizeconfig['source_image'] = FCPATH . '/uploads/' . $uploadedPath . '/' . $uploadedFile;
            $resizeconfig['new_image'] = FCPATH . '/uploads/' . $uploadedPath . '/thumbnails/' . $uploadedFile;
            $resizeconfig['maintain_ratio'] = TRUE;

            if ($imgWidth < 100 && $imgheight < 100) {
                $resizeconfig['width'] = $imgWidth;
                $resizeconfig['height'] = $imgheight;
            } else {
                if ($imgWidth > $imgheight) {
                    $resizeconfig['width'] = 100;
                } elseif ($imgWidth < $imgheight) {
                    $resizeconfig['height'] = 100;
                } elseif ($imgWidth == $imgheight) {
                    $resizeconfig['width'] = 100;
                }
            }
            $resizeconfig['x_axis'] = '0';
            $resizeconfig['y_axis'] = '0';
            $resizeconfig['quality'] = '100%';
            $this->image_lib->initialize($resizeconfig);
            $this->load->library('image_lib', $resizeconfig);
            $this->image_lib->resize();
            $this->image_lib->clear();
            if (!$this->image_lib->resize()) {
                echo $this->image_lib->display_errors();
                exit;
            }
            return $uploadedFile;
        }
    }

// Generates Random Code

    public function get_random_code($chars_min = 6, $chars_max = 6, $use_upper_case = false, $include_numbers = true, $include_special_chars = false) {
        $length = rand($chars_min, $chars_max);
        $selection = 'aeuoyibcdfghjklmnpqrstvwxz';
        if ($include_numbers) {
            $selection .= "1234567890";
        }
        if ($include_special_chars) {
            $selection .= "!@04f7c318ad0360bd7b04c980f950833f11c0b1d1quot;#$%&[]{}?|";
        }
        $password = "";
        for ($i = 0; $i < $length; $i++) {
            $current_letter = $use_upper_case ? (rand(0, 1) ? strtoupper($selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))]) : $selection[(rand() % strlen($selection))];
            $password .= $current_letter;
        }
        return $password;
    }

    public function toDownloadAsPdf() {
        $admission_number = trim($_GET['student_admission_id']);
        $data['user_data'] = $this->session->userdata();
        $data['studentInfo'] = $this->admin_model->view_student_data($admission_number);
        $html = $this->load->view('admin/students/studentpdf', $data, true);
        $this->load->library('m_pdf');
        $pdfFilePath = str_replace(' ', '_', $data['studentInfo']['student_name']) . "_profile_information.pdf";
        $this->m_pdf->pdf->WriteHTML($html);
        $this->m_pdf->pdf->Output($pdfFilePath, "D");
    }

    /* to upload student images */

    public function uploadstudentImages() {
        $data['user_data'] = $this->session->userdata();
        if (!empty($_FILES) && isset($_FILES)) {
            $filesCount = count($_FILES['studentImages']['name']);
            for ($i = 0; $i < $filesCount; $i++) {
                $imageUrl = $_FILES['studentImages']['name'][$i];
                $destination = FCPATH . 'uploads/profile_pics/' . $imageUrl;
                move_uploaded_file($_FILES['studentImages']['tmp_name'][$i], $destination);
            }
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Images Uploaded successfully'));
            redirect(base_url() . 'admin/uploadstudentImages');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/students/csv_students', $data);
        $this->load->view('admin/layouts/footer');
    }

    public function toImportStudentsData() {
        $data['user_data'] = $this->session->userdata();
        $this->load->library("CSVReader"); // csv reader
        if (isset($_FILES['file']['name']) && !empty($_FILES['file']['name'])) {
            $uploadFile = $this->uploadCSV('uploaded_csv_files', '*', 0);
            $result = $this->csvreader->parse_file('uploads/uploaded_csv_files/' . $uploadFile);
            if (isset($result) && !empty($result)) {

                foreach ($result as $k => $student) {

                    if (!array_key_exists('studentname', $student) || !array_key_exists('admissionnumber', $student) || !array_key_exists('fathername', $student) ||
                            !array_key_exists('mothername', $student) || !array_key_exists('mobilenumber', $student) || !array_key_exists('gender', $student) ||
                            !array_key_exists('class', $student) || !array_key_exists('dateofbirth', $student) || !array_key_exists('bloodgroup', $student) ||
                            !array_key_exists('caste', $student) || !array_key_exists('section', $student) || !array_key_exists('feeamount', $student) ||
                            !array_key_exists('s.no', $student) || !array_key_exists('address', $student) || !array_key_exists('busfeeamount', $student) ||
                            !array_key_exists('booksfeeamount', $student) || !array_key_exists('studentimage', $student) || !array_key_exists('joineddate', $student) ||
                            !array_key_exists('joinedclass', $student) || !array_key_exists('documents', $student) || !array_key_exists('busno', $student)) {
                        $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Headings in the csv file are incorrect!.. Please try again with correct headings format'));
                        redirect(base_url() . 'admin/uploadstudentImages');
                    }
                    $reason = '';
                    if (trim($student['studentname']) == "") {
                        $reason .= " Student name";
                    }
                    if (trim($student['admissionnumber']) == "") {
                        $reason .= " Admission number";
                    }
                    if (trim($student['fathername']) == "") {
                        $reason .= " Father name";
                    }
                    if (trim($student['mobilenumber']) == "") {
                        $reason .= " Mobile number";
                    }
                    if (trim($student['gender']) == "") {
                        $reason .= " gender";
                    }
                    if (trim($student['class']) == "") {
                        $reason .= " Class name";
                    }
                    if (trim($student['section']) == "") {
                        $reason .= " Section name";
                    }
                    if (trim($student['feeamount']) == "") {
                        $reason .= " Fee Amount";
                    }
                    if (trim($student['busfeeamount']) == "") {
                        $reason .= " Bus Fee Amount";
                    }
                    if (trim($student['booksfeeamount']) == "") {
                        $reason .= " Books Fee Amount";
                    }
                    if (isset($reason) && !empty($reason)) {
                        $reason .= " are empty";
                        $rp = array('reason' => $reason);
                        $student = array_merge($student, $rp);
                        $not_imported[] = $student;
                    }
                    if (trim($student['admissionnumber']) != "") {
                        // to fetch inserted data
                        $studentQuery = $this->db->where('sch_admission_id', $student['admissionnumber'])->get('student_profile_info');
                        $studentResult = $studentQuery->row_array();
                        $classQuery = $this->db->where('class_name', $student['class'])->where('userid', $data['user_data']['user_id'])->get('student_classes');
                        $classResult = $classQuery->row_array();
                        //to check industry exist or not
                        if (isset($studentResult) && !empty($studentResult)) {
                            $reason = "Student already exists";
                            $rp = array('reason' => $reason);
                            $student = array_merge($student, $rp);
                            $not_imported[] = $student;
                        } elseif (empty($classResult)) {
                            $reason = "Class Name is not exist";
                            $rp = array('reason' => $reason);
                            $student = array_merge($student, $rp);
                            $not_imported[] = $student;
                        } elseif (!empty($classResult) && isset($classResult)) {
                            $sectionQuery = $this->db->where('section_name', $student['section'])->where('class_id', $classResult['id'])->where('userid', $data['user_data']['user_id'])->get('student_class_sections');
                            $sectionResult = $sectionQuery->row_array();
                            if (empty($sectionResult)) {
                                $reason = "Section Name is not exist";
                                $rp = array('reason' => $reason);
                                $student = array_merge($student, $rp);
                                $not_imported[] = $student;
                            } else {
                                if (!empty($student['dateofbirth'])) {
                                    $dateArray = explode('-', $student['dateofbirth']);
                                    $dob = $dateArray['2'] . '-' . $dateArray['1'] . '-' . $dateArray['0'];
                                } else {
                                    $dob = '';
                                }
                                if (!empty($student['joineddate'])) {
                                    $joineddateArray = explode('-', $student['joineddate']);
                                    $joineddate = $joineddateArray['2'] . '-' . $joineddateArray['1'] . '-' . $joineddateArray['0'];
                                } else {
                                    $joineddate = '';
                                }
                                $save_student_data = array(
                                    'userid' => $data['user_data']['user_id'],
                                    'student_name' => isset($student['studentname']) ? strtoupper($student['studentname']) : '',
                                    'sch_admission_id' => isset($student['admissionnumber']) ? trim($student['admissionnumber']) : '',
                                    'student_father_name' => isset($student['fathername']) ? strtoupper($student['fathername']) : '',
                                    'student_mother_name' => isset($student['mothername']) ? strtoupper($student['mothername']) : '',
                                    'student_dob' => $dob,
                                    'student_blood_group' => isset($student['bloodgroup']) ? $student['bloodgroup'] : '',
                                    'student_gender' => isset($student['gender']) ? $student['gender'] : '',
                                    'student_mobile' => isset($student['mobilenumber']) ? $student['mobilenumber'] : '',
                                    'student_caste' => isset($student['caste']) ? $student['caste'] : '',
                                    'student_address' => isset($student['address']) ? str_replace('$', ',', $student['address']) : '',
                                    'student_class_id' => isset($classResult['id']) ? $classResult['id'] : '',
                                    'student_section_id' => isset($sectionResult['id']) ? $sectionResult['id'] : '',
                                    'student_fee' => isset($student['feeamount']) ? $student['feeamount'] : '',
                                    'bus_fee' => isset($student['busfeeamount']) ? $student['busfeeamount'] : '',
                                    'books_fee' => isset($student['booksfeeamount']) ? $student['booksfeeamount'] : '',
                                    'platform' => 'Android',
                                    'student_image' => isset($student['studentimage']) ? $student['studentimage'] : '',
                                    'student_bus_no' => isset($student['busno']) ? $student['busno'] : '',
                                    'student_joined_class' => isset($student['joinedclass']) ? $student['joinedclass'] : '',
                                    'student_joining_date' => $joineddate,
                                    'student_documents' => isset($student['documents']) ? str_replace('$', ',', $student['documents']) : ''
                                );
                                $save_fee_info = array(
                                    'userid' => $data['user_data']['user_id'],
                                    'student_admission_id' => isset($student['admissionnumber']) ? $student['admissionnumber'] : '',
                                    'class_id' => isset($classResult['id']) ? $classResult['id'] : '',
                                    'section_id' => isset($sectionResult['id']) ? $sectionResult['id'] : '',
                                    'total_amount' => isset($student['feeamount']) ? $student['feeamount'] : '',
                                    'paid_amount' => 0,
                                    'balance_amount' => isset($student['feeamount']) ? $student['feeamount'] : ''
                                );
                                $save_bus_fee_info = array(
                                    'userid' => $data['user_data']['user_id'],
                                    'student_admission_id' => isset($student['admissionnumber']) ? $student['admissionnumber'] : '',
                                    'class_id' => isset($classResult['id']) ? $classResult['id'] : '',
                                    'section_id' => isset($sectionResult['id']) ? $sectionResult['id'] : '',
                                    'total_bus_amount' => isset($student['busfeeamount']) ? $student['busfeeamount'] : '',
                                    'paid_bus_amount' => 0,
                                    'concession_bus_amount' => 0,
                                    'balance_bus_amount' => isset($student['busfeeamount']) ? $student['busfeeamount'] : ''
                                );
                                $save_books_fee_info = array(
                                    'userid' => $data['user_data']['user_id'],
                                    'student_admission_id' => isset($student['admissionnumber']) ? $student['admissionnumber'] : '',
                                    'class_id' => isset($classResult['id']) ? $classResult['id'] : '',
                                    'section_id' => isset($sectionResult['id']) ? $sectionResult['id'] : '',
                                    'total_books_amount' => isset($student['booksfeeamount']) ? $student['booksfeeamount'] : '',
                                    'paid_books_amount' => 0,
                                    'concession_books_amount' => 0,
                                    'balance_books_amount' => isset($student['booksfeeamount']) ? $student['booksfeeamount'] : ''
                                );
                                $save_user = $this->global_model->save_data('student_profile_info', $save_student_data);
                                $this->global_model->save_data('student_fee', $save_fee_info);
                                $this->global_model->save_data('student_bus_fee', $save_bus_fee_info);
                                $this->global_model->save_data('student_books_fee', $save_books_fee_info);
                                $students_ids_imported[] = $student;
                            }
                        }
                    }
                }


                // Students imported data
                if (!empty($students_ids_imported) && isset($students_ids_imported)) {

                    $csv = "S.No.,studentname,admissionid,fathername,mothername,dob,bloodgroup,gender,mobile,caste,class,section,fee \n"; //Column headers

                    foreach ($students_ids_imported as $key => $record) {
                        $csv .= $key + 1 . ',' . $record['studentname'] . ',' . $record['admissionnumber'] . ',' .
                                $record['fathername'] . ',' . $record['mothername'] . ',' . $record['dateofbirth'] . ',' .
                                $record['bloodgroup'] . ',' . $record['gender'] . ',' .
                                $record['mobilenumber'] . ',' . $record['caste'] . ',' . $record['class'] . ',' .
                                $record['section'] . ',' . $record['feeamount'] . "\n"; //Append data to csv
                    }

                    $file_name = 'students_imported_' . time() . '.csv';
                    $csv_handler = fopen('uploads/student_import_csvs/' . $file_name, 'w');
                    fwrite($csv_handler, $csv);
                    fclose($csv_handler);
                    $data['imported'] = base_url() . 'uploads/student_import_csvs/' . $file_name;
                } else {
                    $data['imported'] = 0;
                }

                // Students not imported data
                if (!empty($not_imported) && isset($not_imported)) {
                    $csv_notimported = "S.No.,studentname,admissionid,fathername,mothername,dob,bloodgroup,gender,mobile,caste,class,section,fee, Reason \n"; //Column headers
                    foreach ($not_imported as $k => $record) {
                        $csv_notimported .= $k + 1 . ',' . $record['studentname'] . ',' . $record['admissionnumber'] . ',' .
                                $record['fathername'] . ',' . $record['mothername'] . ',' . $record['dateofbirth'] . ',' .
                                $record['bloodgroup'] . ',' . $record['gender'] . ',' .
                                $record['mobilenumber'] . ',' . $record['caste'] . ',' . $record['class'] . ',' .
                                $record['section'] . ',' . $record['feeamount'] . ',' . $record['reason'] . "\n"; //Append data to csv
                    }

                    $file_name_not_imported = 'students_not_imported_' . time() . '.csv';
                    $csv_handler = fopen('uploads/student_not_import_csvs/' . $file_name_not_imported, 'w');
                    fwrite($csv_handler, $csv_notimported);
                    fclose($csv_handler);
                    $data['not_imported'] = base_url() . 'uploads/student_not_import_csvs/' . $file_name_not_imported;
                } else {
                    $data['not_imported'] = 0;
                }
                if (!empty($not_imported)) {
                    $message = "<a href='" . $data['not_imported'] . "'>Not Uploaded</a>";
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Some of your students data not uploaded, please click on Not Uploaded text to download sheet ' . $message));
                    $fileName = 'students_not_uploaded' . rand() . '.csv';
                    redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
                    exit;
                } else {
                    $message = "<a href='" . $data['imported'] . "'>Uploaded</a>";
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Students data Uploaded Successfully!,please click on Uploaded text to download sheet' . $message));
                    $fileName = 'students_uploaded' . rand() . '.csv';
                    redirect(base_url() . 'admin/manage_students?class_id=&section_id=');
                    exit;
                }
            } else {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'No Data Found in CSV!..'));
                redirect(base_url() . 'admin/uploadstudentImages');
                exit;
            }
        }
    }

    public function uploadCSV($uploadedPath, $allowTypes, $maxSize, $imgWidth = '', $imgheight = '') {
        $this->load->library('upload'); // Loading upload library to upload an image
        $this->load->library('image_lib'); // Loading image library to resize an image
        $imgName = $_FILES['file']['name'];

        $splittedArray = @explode(".", $imgName);
        if (!empty($splittedArray)) {

            $uploadedFile = rand() . '_' . time() . '.' . end($splittedArray);
        }
        $arr_config = array('allowed_types' => $allowTypes,
            'upload_path' => 'uploads/' . $uploadedPath . '/',
            'max_size' => $maxSize,
            'file_name' => $uploadedFile,
            'remove_spaces' => true,
            'overwrite' => true,
        );
        $this->upload->initialize($arr_config);

        if (!$this->upload->do_upload('file')) {
            return $this->upload->display_errors();
        } else {
            $resizeconfig = array();
            $resizeconfig['image_library'] = 'GD2';
            $resizeconfig['source_image'] = FCPATH . '/uploads/' . $uploadedPath . '/' . $uploadedFile;
            $resizeconfig['new_image'] = FCPATH . '/uploads/' . $uploadedPath . '/thumbnails/' . $uploadedFile;
            $resizeconfig['maintain_ratio'] = TRUE;
            if ($imgWidth < 100 && $imgheight < 100) {
                $resizeconfig['width'] = $imgWidth;
                $resizeconfig['height'] = $imgheight;
            } else {
                if ($imgWidth > $imgheight) {
                    $resizeconfig['width'] = 100;
                } elseif ($imgWidth < $imgheight) {
                    $resizeconfig['height'] = 100;
                } elseif ($imgWidth == $imgheight) {
                    $resizeconfig['width'] = 100;
                }
            }
            $resizeconfig['x_axis'] = '0';
            $resizeconfig['y_axis'] = '0';
            $resizeconfig['quality'] = '100%';
            $this->image_lib->initialize($resizeconfig);
            $this->load->library('image_lib', $resizeconfig);
            $this->image_lib->resize();
            $this->image_lib->clear();
            if (!$this->image_lib->resize()) {
                echo $this->image_lib->display_errors();
                exit;
            }
            return $uploadedFile;
        }
    }

}
