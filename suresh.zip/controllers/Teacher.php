<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Teacher extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model(array('Teacher_model'));
        $this->load->library('session');
        $user_data = $this->session->userdata();
        if (!$this->session->userdata('user_id')) {
            redirect(base_url() . 'admin_login');
        }

        date_default_timezone_set('UTC');
    }

    /**
     * Manage Sections
     */
    public function manage_teachers() {
        $data['user_data'] = $this->session->userdata();
        $data['sections'] = $this->Teacher_model->get_teachers();
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/teachers/manage_teachers');
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Add Section
     */
    public function add_teacher() {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->global_model->get_all_classes('student_classes', $data['user_data']['user_id']);
        if ($_POST) {
            $save_section_data = array(
                'userid' => $data['user_data']['user_id'],
                'class_id' => $this->input->post('class_id'),
                'section_name' => $this->input->post('section_name'),
                'status' => $this->input->post('status')
            );
            $this->global_model->save_data('student_class_sections', $save_section_data);
            $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section added Successfully'));
            redirect(base_url() . 'section/manage_sections');
        }
        $this->load->view('admin/layouts/header', $data);
        $this->load->view('admin/layouts/sidebar', $data);
        $this->load->view('admin/teachers/add_teacher', $data);
        $this->load->view('admin/layouts/footer');
    }

    /**
     * Delete Section
     * @param type $id
     */
    public function delete_teacher($id = 0) {
        if ($id != '0') {
            $students = $this->Teacher_model->toCheckStudentsWithThisSection($id);
            if ($students > 0) {
                $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Section!..Having Students data with this section, Please delete students under this section before delete the section!.'));
                redirect(base_url() . 'section/manage_sections');
            }
            $delete_user = $this->global_model->update_by('student_class_sections', array('id' => $id), array('status' => 'D'));
            if ($delete_user) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section deleted Successfully'));
            }
            redirect(base_url() . 'section/manage_sections');
        }
    }

    public function delete_multiple_teachers() {
        $ids = explode(',', $_POST['ids']);
        if (!empty($ids)) {
            foreach ($ids as $sec_id):
                $students = $this->Teacher_model->toCheckStudentsWithThisSection($sec_id);
                if ($students > 0) {
                    $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Unable to delete this Section!..Having Students data with this section, Please delete students under this section before delete the section!.'));
                    echo "exist";
                    exit;
                }
            endforeach;
            foreach ($ids as $sec_id):
                $delete_student = $this->global_model->update_by('student_class_sections', array('id' => $sec_id), array('status' => 'D'));
            endforeach;
            if ($delete_student) {
                $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section deleted Successfully'));
                echo "success";
                exit;
            }
        } else {
            $this->session->set_flashdata('alert', array('type' => 'danger', 'message' => 'Something went wrong!.. please try again'));
            echo "fail";
            exit;
        }
    }

    /**
     * Edit Section
     * @param type $id
     */
    public function edit_teacher($id = 0) {
        $data['user_data'] = $this->session->userdata();
        $data['classes'] = $this->global_model->get_all_classes('student_classes', $data['user_data']['user_id']);
        if ($id != '0') {
            $data['sections'] = $this->Teacher_model->get_sections(array('ss.id' => $id));
            if ($data['sections']) {
                $data['sections'] = $data['sections'][0];
            } else {
                $data['sections'] = array();
            }

            if ($_POST) {
                $save_section_data = array(
                    'class_id' => $this->input->post('class_id'),
                    'section_name' => $this->input->post('section_name'),
                    'status' => $this->input->post('status')
                );
                $save_section = $this->global_model->update_by('student_class_sections', array('id' => $id), $save_section_data);
                if ($save_section) {
                    $this->session->set_flashdata('alert', array('type' => 'success', 'message' => 'Section updated Successfully'));
                }

                redirect(base_url() . 'section/manage_sections');
            }

            $this->load->view('admin/layouts/header', $data);
            $this->load->view('admin/layouts/sidebar', $data);
            $this->load->view('admin/teachers/edit_teacher', $data);
            $this->load->view('admin/layouts/footer');
        }
    }

    /**
     * Logout
     */
    public function logout() {
        $this->session->sess_destroy();
        redirect(base_url() . 'admin');
    }

}
