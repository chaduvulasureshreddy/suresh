<?php

class driver_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Drivers
     * @param type $where
     */
    function get_drivers($id) {
        $this->db->select('*');
        $this->db->from('student_bus_drivers');
        $this->db->where('userid', $id);
        $this->db->where('driver_status !=', 'D');
        $this->db->order_by('driver_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    function export_drivers_data($id) {
        $this->db->select('*');
        $this->db->from('student_bus_drivers');
        $this->db->where('userid', $id);
        $this->db->where('driver_status !=', 'D');
        $this->db->order_by('driver_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    function get_driver_data($id) {
        $this->db->select('*');
        $this->db->from('student_bus_drivers');
        $this->db->where('id', $id);
        $result = $this->db->get()->row_array();
        return $result;
    }

    function view_driver_data($id) {
        $this->db->select('*');
        $this->db->from('student_bus_drivers');
        $this->db->where('id', $id);
        $this->db->where('driver_status !=', 'D');
        $result = $this->db->get()->row_array();
        return $result;
    }

    function getDriverDetailsByMobileNumber($mobile_number, $id) {
        $this->db->select('*');
        $this->db->from("student_bus_drivers");
        $this->db->where('mobile_number', $mobile_number);
        if ($id) {
            $this->db->where('id!=', $id);
        }
        $query = $this->db->get();
        return $query->row_array();
    }

    function getDriverDetailsById($field, $id, $table) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        $this->db->where('student_status!=', 'D');
        $query = $this->db->get();
        return $query->row_array();
    }

}
