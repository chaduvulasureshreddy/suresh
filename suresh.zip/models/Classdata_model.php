<?php

class classdata_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Users
     * @param type $where
     */
    function get_classes($where = null, $userId) {
        $this->db->select('*')
                ->from('student_classes');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('status !=', 'D');
        $this->db->where('userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function export_classes_data($userId) {
        $this->db->select('class_name');
        $this->db->from('student_classes');
        $this->db->where('status !=', 'D');
        $this->db->where('userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function toCheckStudentsWithThisClass($class_id) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('student_class_id', $class_id);
        $result = $this->db->get()->num_rows();
        return $result;
    }

    function toCheckClassName($class_name, $class_id, $table, $userId) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('class_name', $class_name);
        $this->db->where('status!=', 'D');
        if (!empty($class_id)) {
            $this->db->where('id!=', $class_id);
        }
        $this->db->where('userid', $userId);
        $query = $this->db->get();
        return $query->row_array();
    }

}
