<?php

class admin_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Check Login
     * @param type $data
     * @return boolean
     */
    public function check_login($data) {
        $this->db->from('schools')
                ->where('email', $data['email'])
                ->where('password', md5($data['password']))
                ->where('status', 'A');
        $results = $this->db->get()->row();
        //echo $this->db->last_query();exit;
        if ($results) {
            return $results;
        }
        return false;
    }

    /**
     * Get Users
     * @param type $where
     */
    public function get_students($id, $class_id, $section_id) {
        $this->db->select('spi.*, sc.class_name, scs.section_name, sb.bus_no');
        $this->db->from('student_profile_info spi');
        $this->db->join('student_classes sc', 'sc.id=spi.student_class_id');
        $this->db->join('student_class_sections scs', 'scs.id=spi.student_section_id');
        $this->db->join('student_buses sb', 'sb.id=spi.student_bus_no', 'LEFT');
        if ($class_id) {
            $this->db->where('spi.student_class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('spi.student_section_id', $section_id);
        }
        $this->db->where('spi.userid', $id);
        $this->db->where('spi.student_status !=', 'D');
        $this->db->order_by('spi.student_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function export_students_data($id, $class_id, $section_id) {
        $this->db->select('spi.sch_admission_id, spi.student_name, spi.student_father_name, spi.student_mother_name, spi.student_gender, spi.student_joined_class,spi.student_joining_date,spi.student_documents,sc.class_name, scs.section_name, spi.student_mobile,spi.student_dob,spi.student_address, sb.bus_no');
        $this->db->from('student_profile_info spi');
        $this->db->join('student_classes sc', 'sc.id=spi.student_class_id');
        $this->db->join('student_class_sections scs', 'scs.id=spi.student_section_id');
        $this->db->join('student_buses sb', 'sb.id=spi.student_bus_no', 'LEFT');
        if ($class_id) {
            $this->db->where('spi.student_class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('spi.student_section_id', $section_id);
        }
        $this->db->where('spi.userid', $id);
        $this->db->where('spi.student_status !=', 'D');
        $this->db->order_by('spi.student_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function toGetStudentsByClassSection($where = null) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('student_status !=', 'D');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function get_student_data($admission_number) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('sch_admission_id', $admission_number);
        $result = $this->db->get()->row_array();
        return $result;
    }

    public function view_student_data($admission_number) {
        $this->db->select('spi.*, sc.class_name, scs.section_name, sb.bus_no');
        $this->db->from('student_profile_info spi');
        $this->db->join('student_classes sc', 'sc.id=spi.student_class_id');
        $this->db->join('student_class_sections scs', 'scs.id=spi.student_section_id');
        $this->db->join('student_buses sb', 'sb.id=spi.student_bus_no', 'LEFT');
        $this->db->where('spi.sch_admission_id', $admission_number);
        $this->db->where('spi.student_status !=', 'D');
        $result = $this->db->get()->row_array();
        return $result;
    }

    public function get_all($table, $userId) {
        if ($table != '') {
            $this->db->from($table);
            $this->db->where('userid', $userId);
            $this->db->where('status', 'A');
            $results = $this->db->get()->result_array();
            if (is_array($results) && count($results) > 0) {
                return $results;
            }
        }
        return false;
    }

    public function toGetSectionsByClass($where = null) {
        $this->db->select('*');
        $this->db->from('student_class_sections');
        if ($where) {
            $this->db->where($where);
        }
        $result = $this->db->get()->result_array();
        return $result;
    }

    function getdetailsById($field, $id, $table) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function getStudentDetailsById($field, $id, $table) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        $this->db->where('student_status!=', 'D');
        $query = $this->db->get();
        return $query->row_array();
    }

    function toCheckSectionName($section_name, $class_id, $section_id, $table, $userId) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('section_name', $section_name);
        $this->db->where('class_id', $class_id);
        $this->db->where('userid', $userId);
        $this->db->where('status!=', 'D');
        if (!empty($section_id)) {
            $this->db->where('id!=', $section_id);
        }
        $query = $this->db->get();
//        echo $this->db->last_query();exit;
        return $query->row_array();
    }

    public function getStudentsInfo($id, $class_id, $section_id) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('userid', $id);
        if ($class_id) {
            $this->db->where('student_class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('student_section_id', $section_id);
        }
        $this->db->where('student_status !=', 'D');
        $result = $this->db->get();

        return $result->result_array();
    }

    public function toGetClassName($class_id) {
        $this->db->select('class_name');
        $this->db->from('student_classes');
        $this->db->where('id', $class_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    public function toGetSectionName($section_id) {
        $this->db->select('section_name');
        $this->db->from('student_class_sections');
        $this->db->where('id', $section_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    public function toGetStudentFeeInfo($admission_id) {
        $this->db->select('*');
        $this->db->from('student_fee');
        $this->db->where('student_admission_id', $admission_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    public function toGetStudentBusFeeInfo($admission_id) {
        $this->db->select('*');
        $this->db->from('student_bus_fee');
        $this->db->where('student_admission_id', $admission_id);
        $result = $this->db->get();
        return $result->row_array();
    }

    public function toGetStudentBooksFeeInfo($admission_id) {
        $this->db->select('*');
        $this->db->from('student_books_fee');
        $this->db->where('student_admission_id', $admission_id);
        $result = $this->db->get();
        return $result->row_array();
    }

}
