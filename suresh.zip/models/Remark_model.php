<?php

class remark_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Homework
     * @param type $where
     */
    public function edit_remark($where = null) {
        $this->db->select('ss.*,sc.class_name,scs.section_name');
        $this->db->from('student_remarks ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('ss.remark_status !=', 'D');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function manage_remarks($id, $class_id, $section_id, $date) {
        $this->db->select('ss.*,sc.class_name,scs.section_name,spi.student_name');
        $this->db->from('student_remarks ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = ss.student_admission_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        if ($date) {
            $this->db->where('ss.remark_date', $date);
        }
        if ($class_id) {
            $this->db->where('ss.class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('ss.section_id', $section_id);
        }
        $this->db->where('ss.userid', $id);
        $this->db->where('ss.remark_status !=', 'D');
        $this->db->where('spi.student_status !=', 'D');
        $this->db->order_by('spi.student_name', 'ASC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function export_remarks_data($id, $class_id, $section_id, $date) {
        $this->db->select('ss.student_admission_id,spi.student_name,sc.class_name,scs.section_name,ss.remark_date, ss.remark_name');
        $this->db->from('student_remarks ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = ss.student_admission_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        if ($date) {
            $this->db->where('ss.remark_date', $date);
        }
        if ($class_id) {
            $this->db->where('ss.class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('ss.section_id', $section_id);
        }
        $this->db->where('ss.userid', $id);
        $this->db->where('ss.remark_status !=', 'D');
        $this->db->where('spi.student_status !=', 'D');
        $this->db->order_by('spi.student_name', 'ASC');
        $result = $this->db->get()->result_array();
        return $result;
    }

}
