<?php

class busfees_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Homework
     * @param type $where
     */
    public function getStudentFeeInfoByAdmission($admission_id, $userid) {
        $this->db->select('ss.*,sc.class_name,scs.section_name,spi.student_name, spi.student_image, spi.student_mobile');
        $this->db->from('student_bus_fee ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = ss.student_admission_id', 'LEFT');
        $this->db->where('ss.student_admission_id', $admission_id);
        $this->db->where('ss.userid', $userid);
        $result = $this->db->get()->row_array();
        return $result;
    }

    public function getStudentPreviousFeeInfoByAdmission($admission_id) {
        $this->db->select('*');
        $this->db->from('student_bus_fee_term');
        $this->db->where('student_admission_id', $admission_id);
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function toGetStudentsByClassSectionName($class_id, $section_id, $id, $student_name) {
        $this->db->select('ss.*,sc.class_name,scs.section_name,spi.student_name');
        $this->db->from('student_bus_fee ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = ss.student_admission_id', 'LEFT');
        if ($student_name) {
            $this->db->like('spi.student_name', $student_name);
        }
        $this->db->where('ss.class_id', $class_id);
        $this->db->where('ss.section_id', $section_id);
        $this->db->where('ss.userid', $id);
        $this->db->where('spi.student_status!=', 'D');
        $this->db->order_by('spi.student_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function getStudentsBusFeePendingData($class_id, $section_id, $id) {
        $this->db->select('ss.*,sc.class_name,scs.section_name,spi.student_name');
        $this->db->from('student_bus_fee ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = ss.student_admission_id', 'LEFT');
        $this->db->where('ss.class_id', $class_id);
        $this->db->where('ss.section_id', $section_id);
        $this->db->where('ss.userid', $id);
        $this->db->where('ss.busfee_status', 'A');
        $this->db->where('ss.balance_bus_amount!=', '0');
        $this->db->order_by('spi.student_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function toGetPendingFeesByClassAndSection($classId, $sectionId) {
        $this->db->select('SUM(balance_bus_amount) AS balance_amount, SUM(paid_bus_amount) AS paid_amount, SUM(total_bus_amount) AS total_amount, SUM(concession_bus_amount) AS concession_amount');
        $this->db->from('student_bus_fee');
        $this->db->where('class_id', $classId);
        $this->db->where('busfee_status', 'A');
        $this->db->where('section_id', $sectionId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function export_pendingfees_data($classId, $sectionId) {
        $this->db->select('SUM(balance_bus_amount) AS balance_amount, SUM(paid_bus_amount) AS paid_amount, SUM(total_bus_amount) AS total_amount, SUM(concession_bus_amount) AS concession_amount');
        $this->db->from('student_bus_fee');
        $this->db->where('class_id', $classId);
        $this->db->where('section_id', $sectionId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function exportPendingfeesdataByClass($class_id, $section_id, $id, $type) {
        $this->db->select('ss.*,sc.class_name,scs.section_name,spi.student_name');
        $this->db->from('student_bus_fee ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = ss.student_admission_id', 'LEFT');
        $this->db->where('ss.class_id', $class_id);
        $this->db->where('ss.section_id', $section_id);
        $this->db->where('ss.userid', $id);
        if ($type) {
            $this->db->where('ss.balance_bus_amount!=', '0');
        }
        $this->db->order_by('spi.student_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function paid_fee_amount($userid, $class_id, $section_id, $start_date, $end_date) {
        $this->db->select('spi.student_name,spi.student_father_name,sc.class_name,scs.section_name,sft.*');
        $this->db->from('student_bus_fee_term sft');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = sft.student_admission_id', 'LEFT');
        $this->db->join('student_classes sc', 'sc.id = spi.student_class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = spi.student_section_id', 'LEFT');
        $this->db->where('sft.userid', $userid);
        if ($start_date) {
            $this->db->where('sft.paid_date >=', $start_date);
        }
        if ($end_date) {
            $this->db->where('sft.paid_date <=', $end_date);
        }
        if ($class_id) {
            $this->db->where('spi.student_class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('spi.student_section_id', $section_id);
        }
        $this->db->where('spi.student_status!=', 'D');
        $this->db->order_by('sft.paid_date', 'DESC');
        $this->db->order_by('spi.student_name', 'ASC');
        $result = $this->db->get()->result_array();
        return $result;
    }

}
