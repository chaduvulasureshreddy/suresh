<?php

class global_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Save Data
     * @param type $table
     * @param type $data
     */
    public function save_data($table, $data) {
        if ($table != '' && !empty($data)) {
            $this->db->insert($table, $data);
            return $this->db->insert_id();
        }
    }

    /**
     * Update By
     * @param type $table
     * @param type $where
     * @param type $data
     */
    public function update_by($table, $where, $data) {
        if ($table != '') {
            $this->db->where($where);
            $this->db->update($table, $data);
            return $this->db->affected_rows();
        }
    }

    /**
     * Get all records
     * @param type $table
     */
    public function get_all($table) {
        if ($table != '') {
            $this->db->from($table);
            $results = $this->db->get()->result_array();
            if (is_array($results) && count($results) > 0) {
                return $results;
            }
        }
        return false;
    }

    /**
     * Get all records Where
     * @param type $table
     */
    public function get_all_where($table) {
        if ($table != '') {
            $this->db->from($table);
            $this->db->where('status !=', 'D');
            $results = $this->db->get()->result_array();
            if (is_array($results) && count($results) > 0) {
                return $results;
            }
        }
        return false;
    }

    public function get_all_classes($table, $userId) {
        if ($table != '') {
            $this->db->from($table);
            $this->db->where('status !=', 'D');
            $this->db->where('userid', $userId);
            $results = $this->db->get()->result_array();
            if (is_array($results) && count($results) > 0) {
                return $results;
            }
        }
        return false;
    }

    /**
     * Get record by id
     * @param type $table
     * @param type $id
     */
    public function get_by($table, $where) {
        if ($table != '') {
            $this->db->from($table);
            $this->db->where($where);
            $this->db->where('status !=', 'D');
            $this->db->order_by('created_date', 'desc');
            $results = $this->db->get()->row();
            if ($results) {
                return $results;
            }
        }
        return false;
    }

    /**
     * Delete By
     * @param type $table
     * @param type $where
     */
    public function delete_by($table, $where) {
        if ($table != '') {
            $this->db->where($where);
            $this->db->delete($table);
            return $this->db->affected_rows();
        }
    }

    public function get_all_examtypes($table, $user_id) {
        if ($table != '') {
            $this->db->from($table);
            $this->db->where('userid', $user_id);
            $results = $this->db->get()->result_array();
            if ($results) {
                return $results;
            }
        }
        return false;
    }

}
