<?php

class results_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Users
     * @param type $where
     */
    function get_user_exams($userId, $class_id, $section_id, $exam_date, $subject_id) {
        $this->db->select('sce.*,sc.class_name, scs.section_name,set.exam_name,scss.subject_name')->from('student_class_exams sce');
        $this->db->join('student_classes sc', 'sc.id = sce.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = sce.section_id', 'LEFT');
        $this->db->join('student_exam_types set', 'set.id = sce.exam_type_id', 'LEFT');
        $this->db->join('student_class_subjects scss', 'scss.id = sce.subject_id', 'LEFT');
        if ($exam_date) {
            $this->db->where('sce.exam_date', $exam_date);
        }
        if ($class_id) {
            $this->db->where('sce.class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('sce.section_id', $section_id);
        }
        if ($subject_id) {
            $this->db->where('sce.subject_id', $subject_id);
        }
        $this->db->where('sce.userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function export_classes_data($userId) {
        $this->db->select('class_name');
        $this->db->from('student_classes');
        $this->db->where('status !=', 'D');
        $this->db->where('userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function toCheckStudentsWithThisClass($class_id) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('student_class_id', $class_id);
        $result = $this->db->get()->num_rows();
        return $result;
    }

    function toCheckClassName($class_name, $class_id, $table, $userId) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('class_name', $class_name);
        $this->db->where('status!=', 'D');
        if (!empty($class_id)) {
            $this->db->where('id!=', $class_id);
        }
        $this->db->where('userid', $userId);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetExamSubjects($exam_id){
        $this->db->select('*');
        $this->db->from('student_exam_marks');
        $this->db->where('exam_id', $exam_id);
        $result = $this->db->get()->result_array();
        return $result;
    }

}
