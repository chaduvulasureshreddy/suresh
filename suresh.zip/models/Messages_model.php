<?php

class messages_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Homework
     * @param type $where
     */
    public function edit_remark($where = null) {
        $this->db->select('ss.*,sc.class_name,scs.section_name');
        $this->db->from('student_remarks ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('ss.remark_status !=', 'D');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function manage_messages($id, $message_date) {
        $this->db->select('sm.*,sc.class_name,smc.id as smc_id');
        $this->db->from('student_messages sm');
        $this->db->join('student_message_classes smc', 'smc.message_id = sm.id', 'LEFT');
        $this->db->join('student_classes sc', 'sc.id = smc.class_id', 'LEFT');
        $this->db->where('sm.userid', $id);
        if (!empty($message_date)) {
            $this->db->where('sm.message_date', $message_date);
        }
        $this->db->where('smc.smc_status !=', 'D');
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function toGetCountMessages($id) {
        $this->db->where('message_id', $id);
        $this->db->from('student_message_classes');
        $query = $this->db->get();
        return $query->num_rows();
    }

    /* $this->db->where($where);
      $this->db->delete($table);
      return $this->db->affected_rows(); */

    public function export_messages_data($id, $message_date) {
        $this->db->select('message_subject,message,message_date');
        $this->db->from('student_messages');
        $this->db->where('userid', $id);
        if (!empty($message_date)) {
            $this->db->where('message_date', $message_date);
        }
        $this->db->where('message_status !=', 'D');
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

}
