<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class bustracking_model extends CI_Model {

    function driverLogin($password, $phone, $user_id) {
        $this->db->select('*');
        $this->db->from('student_bus_drivers');
        $this->db->where('password', md5($password));
        $this->db->where('mobile_number', $phone);
        $this->db->where('driver_status', 'A');
        $this->db->where('userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetBusDriverInfo($driver_id, $user_id) {
        $this->db->select('*');
        $this->db->from('student_bus_drivers');
        $this->db->where('id', $driver_id);
        $this->db->where('driver_status', 'A');
        $this->db->where('userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetSchoolHomeLocation($user_id) {
        $this->db->select('*');
        $this->db->from('school_homelocation');
        $this->db->where('status', 'A');
        $this->db->where('userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetBusTrackingInfoForParent($route_id, $user_id) {
        $this->db->select('sbt.latitude,sbt.longitude,sbd.driver_name,sbd.driver_image,sbd.mobile_number,sbd.driver_description,sb.bus_no,sb.bus_tr_no, sbd.aadhar_number,sbd.license_number');
        $this->db->from('student_bus_tracking sbt');
        $this->db->join('student_bus_drivers sbd', 'sbd.id = sbt.driver_id', 'LEFT');
        $this->db->join('student_buses sb', 'sb.id = sbt.bus_id', 'LEFT');
        $this->db->where('sbt.tracking_date', date('Y-m-d'));
        $this->db->where('sbt.route_id', $route_id);
        $this->db->where('sbt.userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetBuses($user_id) {
        $this->db->select('*');
        $this->db->where('status', 'A');
        $this->db->from('student_buses');
        $this->db->where('userid', $user_id);
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function toGetBusRoutes($user_id) {
        $this->db->select('id, userid, route_no, status, route_name');
        $this->db->where('status', 'A');
        $this->db->from('student_bus_routes');
        $this->db->where('userid', $user_id);
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function checkBusRoute($routeId, $userId) {
        $this->db->select('route_id');
        $this->db->from('student_bus_tracking');
        $this->db->where('tracking_date', date('Y-m-d'));
        $this->db->where('userid', $userId);
        $this->db->where('route_id', $routeId);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetRouteMap($user_id) {
        $this->db->select('*');
        $this->db->where('status', 'A');
        $this->db->from('student_bus_routes');
        $this->db->where('userid', $user_id);
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

}
