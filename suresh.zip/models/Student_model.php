<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Student_model extends CI_Model {

    function parentLogin($admission, $phone, $user_id) {
        $this->db->select('spi.*,sc.class_name,scs.section_name');
        $this->db->from('student_profile_info spi');
        $this->db->join('student_classes sc', 'sc.id=spi.student_class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id=spi.student_section_id', 'LEFT');
        $this->db->where('spi.sch_admission_id', $admission);
        $this->db->where('spi.student_mobile', $phone);
        $this->db->where('spi.userid', $user_id);
        $this->db->where('spi.student_status!=', 'D');
        $query = $this->db->get();
        return $query->row_array();
    }

    function teacherLogin($teacher_name, $password, $user_id) {
        $this->db->select('*');
        $this->db->from('student_class_teacher');
        $this->db->where('teacher_name', $teacher_name);
        $this->db->where('teacher_password', $password);
        $this->db->where('teacher_status!=', 'D');
        $this->db->where('userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetStudentProfile($admissionId, $user_id) {
        $this->db->select('spi.*,sc.class_name,scs.section_name');
        $this->db->from('student_profile_info spi');
        $this->db->join('student_classes sc', 'sc.id=spi.student_class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id=spi.student_section_id', 'LEFT');
        $this->db->where('spi.sch_admission_id', $admissionId);
        $this->db->where('spi.userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetStudentRemarks($field, $id, $table, $remark_date, $user_id) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        if (!empty($remark_date)) {
            $this->db->where('remark_date', $remark_date);
        }
        $this->db->where('remark_status', 'A');
        $this->db->where('userid', $user_id);
        $this->db->order_by('remark_date', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function toGetStudentAttendanceList($id, $attendance_date, $user_id) {
        $this->db->select('sal.*,spi.student_name');
        $this->db->from('student_attendance_list sal');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id=sal.student_admission_id', 'LEFT');
        $this->db->where('sal.student_admission_id', $id);
        $this->db->where('sal.status!=', 'P');
        if (!empty($attendance_date)) {
            $this->db->where('sal.date', $attendance_date);
        }
        $this->db->where('spi.userid', $user_id);
        $this->db->order_by('sal.date', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function toGetStudentFeeDetails($id, $user_id) {
        $this->db->select('sf.*,spi.student_name');
        $this->db->from('student_fee sf');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id=sf.student_admission_id', 'LEFT');
        $this->db->where('sf.student_admission_id', $id);
        $this->db->where('spi.userid', $user_id);
        $query = $this->db->get();
        return $query->row_array();
    }

    public function getStudentPreviousFeeInfoByAdmission($admission_id, $user_id) {
        $this->db->select('*');
        $this->db->from('student_fee_term');
        $this->db->where('student_admission_id', $admission_id);
        $this->db->where('userid', $user_id);
        $this->db->order_by('id', 'DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    function getdetailsById($field, $id, $table) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        $query = $this->db->get();
        return $query->row_array();
    }

    function toGetStudentHomeWork($classId, $sectionId, $home_work_date, $user_id) {
        $this->db->select('*');
        $this->db->where('class_id', $classId);
        $this->db->where('section_id', $sectionId);
        $this->db->where('home_work_status', 'A');
        if (!empty($home_work_date)) {
            $this->db->where('home_work_date', $home_work_date);
        }
        $this->db->where('userid', $user_id);
        $this->db->from('student_home_work');
        $this->db->order_by('home_work_date', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function toGetMessages($message_date, $user_id) {
        $this->db->select('*');
        $this->db->where('message_status', 'A');
        if (!empty($message_date)) {
            $this->db->where('message_date', $message_date);
        }
        $this->db->from('student_messages');
        $this->db->where('userid', $user_id);
        $this->db->order_by('message_date', 'DESC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function toGetExamTypes($user_id) {
        $this->db->select('id,exam_name,exam_status');
        $this->db->where('exam_status', 'A');
        $this->db->from('student_exam_types');
        $this->db->where('userid', $user_id);
        $this->db->order_by('id', 'ASC');
        $query = $this->db->get();
        return $query->result_array();
    }

    function toGetStudentExamResults($student_admission_id, $exam_type_id, $user_id) {

        $this->db->select('sem.total_marks,sem.achieved_marks,sce.common_id,sce.exam_date,set.exam_name,scss.subject_name');
        $this->db->from('student_exam_marks sem');
        $this->db->join('student_class_exams sce', 'sce.id=sem.exam_id', 'LEFT');
        $this->db->join('student_exam_types set', 'set.id=sce.exam_type_id', 'LEFT');
        $this->db->join('student_class_subjects scss', 'scss.id=sce.subject_id', 'LEFT');
        $this->db->where('sem.student_admission_id', $student_admission_id);
        $this->db->where('sem.userid', $user_id);
        if (!empty($exam_type_id)) {
            $this->db->where('sce.exam_type_id', $exam_type_id);
        }
        $result = $this->db->get();
        return $result->result_array();
    }

    function toGetStudentBirthdayDates() {
        $currentDate = date('m-d');
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->like('student_dob', $currentDate);
        $this->db->where('student_dob!=', '');
        $this->db->where('student_status!=', 'D');
        $result = $this->db->get();
        return $result->result_array();
    }

    function toGetSchoolName($id) {
        $this->db->select('*');
        $this->db->from('schools');
        $this->db->where('id', $id);
        $result = $this->db->get();
        return $result->row_array();
    }

    function toSendScheduleMessages() {
        $currentDate = date('Y-m-d');
        $currentTime = date('H:i:s');
        $this->db->select('*');
        $this->db->from('student_messages');
        $this->db->where('message_date', $currentDate);
        $this->db->where('message_time', $currentTime);
        $this->db->where('message_date!=', '');
        $this->db->where('message_time!=', '');
        $this->db->where('schedule_message', '1');
        $result = $this->db->get();
        return $result->result_array();
    }

    function toGetStudentsByClass($classId, $userId) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('student_class_id', $classId);
        $this->db->where('userid', $userId);
        $this->db->where('student_status!=', 'D');
        $result = $this->db->get();
        return $result->result_array();
    }

    function toGetStudentsByGrade($gradeId, $userId) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('student_grade', $gradeId);
        $this->db->where('userid', $userId);
        $this->db->where('student_status!=', 'D');
        $result = $this->db->get();
        return $result->result_array();
    }

    function toGetStudentsByActivity($activityId, $userId) {
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('student_activity', $activityId);
        $this->db->where('userid', $userId);
        $this->db->where('student_status!=', 'D');
        $result = $this->db->get();
        return $result->result_array();
    }

    function toGetSectionsByMultipleClasses($rdata){
        $this->db->select('*');
        $this->db->from('student_class_sections');
        $this->db->where_in('class_id', $rdata['class_id']);
        $query = $this->db->get();
        return $query->result_array();
    }

}
