<?php

class section_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Users
     * @param type $where
     */
    public function get_sections($where = null, $userId) {
        $this->db->select('ss.*,sc.class_name');
        $this->db->from('student_class_sections ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('ss.status !=', 'D');
        $this->db->where('ss.userid',$userId);
        $result = $this->db->get()->result_array();
        return $result;
    }
    
    function export_sections_data($userId){
        $this->db->select('sc.class_name, ss.section_name');
        $this->db->from('student_class_sections ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->where('ss.status !=', 'D');
        $this->db->where('ss.userid',$userId);
        $result = $this->db->get()->result_array();
        return $result;
    }
    
    public function toCheckStudentsWithThisSection($section_id){
        $this->db->select('*');
        $this->db->from('student_profile_info');
        $this->db->where('student_section_id', $section_id);
        $result = $this->db->get()->num_rows();
        return $result;
    }

}
