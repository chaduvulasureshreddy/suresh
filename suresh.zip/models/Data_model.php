<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Data_model extends CI_Model {

    function chkUser($email) {
        $this->db->select('id');
        $query = $this->db->get_where('schools', array('email' => $email));
        $row = $query->row_array();
        return $row;
    }
    
    function chkUserId($id) {
        $this->db->select('id');
        $query = $this->db->get_where('schools', array('id' => $id));
        $row = $query->row_array();
        return $row;
    }

    function addRecords($data, $table) {
        if ($this->db->insert($table, $data)) {
            return $this->db->insert_id();
        } else {
            return FALSE;
        }
    }

    function checkUserLogin($email, $password) {
        $this->db->select('*');
        $query = $this->db->get_where('schools', array('email' => $email, 'password' => $password));
        return $query->row_array();
    }

    function updateRecord($datatoupdate, $data_modify, $table) {
        $this->db->where($data_modify);
        if ($this->db->update($table, $datatoupdate)) {
            return TRUE;
        } else {
            return FALSE;
        }
    }

    function getUserdetails($userid) {
        $this->db->select('*');
        $this->db->from('schools');
        $this->db->where('id', $userid);
        $query = $this->db->get();
        return $query->row_array();
    }
    
    function getBranddetails($brandId, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $brandId);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function getaboutUs($brandId, $table){
    	$this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $brandId);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function tocheckdevicetoken($devicetoken, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('device_token', $devicetoken);
        $query = $this->db->get();
        return $query->num_rows();
    }
    function tocheckUserId($userid, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $userid);
        $query = $this->db->get();
        return $query->num_rows();
    }

    
    
    function removeBrandRecords($dataId, $table) {
        
        $this->db->where('id', $dataId);
        $query = $this->db->delete($table);
        return TRUE;
    }
    function removemultipleBrandRecords($dataId, $table) {
        
        $this->db->where_in('id', $dataId);
        $query = $this->db->delete($table);
        return TRUE;
    }

    
    
    function getAllBrandsofUserWithCategory($userId, $category){
        $this->db->select('*');
        $this->db->from('brands');
        $this->db->where(array('userId' => $userId, 'category' => $category ));
        $query = $this->db->get();
        sort($query);
        
        return $query->result_array();
    }
     function getSingleBrandofUser($userId, $table){
       // $this->db->select('*');
        // $this->db->from($table);
      //   $this->db->where('userid', $userId);
         $query = $this->db->query("SELECT * FROM `$table` ORDER BY `id` DESC LIMIT 1");
       // $query = $db->query("SELECT * FROM `$table` ORDER BY `id` DESC");
        $data=array();
        if($query->num_rows()>0){
        foreach($query->result_array() as $k=>$rw){
        $data[$k]=$rw;
        // $data[$k]['doctor_specialist_name']='';
        }
        }
        return $data;
    }
    
    function getSingleDataofUser($userId, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $userId);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function getAllBrandsofUser($userId, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $userId);
        $query = $this->db->get();
        return $query->result_array();
    }
    function getallgallery($userId, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $userId);
               $this->db->order_by('id','DESC');

        $query = $this->db->get();
        return $query->result_array();
    }
    function getallgalleryDetails($galleryId, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('galleryId', $galleryId);
               $this->db->order_by('id','DESC');

        $query = $this->db->get();
        return $query->result_array();
    }
 
    
    function getAllmessagesofUser($userId, $message_date,$table){
        $this->db->select('*');
        $this->db->from($table);
        if (!empty($message_date)) {
            $this->db->where('updated_date', $message_date);
        }
               // $this->db->order_by('ss.remark_date','DESC');

        $this->db->where('userid', $userId);
       $this->db->order_by('created_date','DESC');

        $query = $this->db->get();
        return $query->result_array();
    }
    function getfacultybyuserid($userId, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('userid', $userId);
        $this->db->order_by('sort_order','ASC');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    
    function getresultsArray($table){
        $this->db->select('count(*) as count , ExamName');
        $this->db->from($table);
        $this->db->group_by('ExamName');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function getresultsbyexamname($ExamName, $table){
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('ExamName', $ExamName);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    
    function getAllUsers($type){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where('type', $type);
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function getAllUsersFromCity($city, $type){
        $this->db->select('*');
        $this->db->from('users');
        $this->db->where(array('city' => $city, 'type' => $type ));
        $query = $this->db->get();
        return $query->result_array();
    }
    
    function getAllCities(){
        $this->db->select('*');
        $this->db->from('city');
        $query = $this->db->get();
        return $query->result_array();
    }
    
    
    function getBusinessTypes(){
        $this->db->select('*');
        $this->db->from('business');
        
        $query = $this->db->get();
        return $query->result_array();
    }
    
   
    
    
     function samplede(){
        $this->db->select('id');
        $this->db->from('brands');
        $query = $this->db->where('id', $brandid);
        return $query->result_row();
    }
	
	function chkPassword($userId,$password){
		$this->db->select('*');
		$this->db->where('id',$userId);
		$this->db->where('password',$password);
		$this->db->from('users');
		$query = $this->db->get();
		return $query->row_array();
	}
	
	function forgetPassword($mobile,$username,$email){
		$this->db->select('*');
		$this->db->where('mobile',$mobile);
		$this->db->where('username',$username);
		$this->db->where('email',$email);
		$this->db->from('users');
		$query = $this->db->get();
		//echo $this->db->last_query();exit;
		return $query->row_array();
	}
	
	function getMudradetails($name,$mobile){
		$this->db->select('*');
		$this->db->where('mobile',$mobile);
		$this->db->where('name',$name);
		$this->db->from('mudra');
		$query = $this->db->get();
		//echo $this->db->last_query();exit;
		return $query->row_array();
	}
	

	
	function getSpecialization(){
        $this->db->select('*');
        $this->db->from('HospitalSpecial');
        $query = $this->db->get();
        return $query->result_array();
    }

}