<?php

class examtypes_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Users
     * @param type $where
     */
    function get_examtypes($where = null, $userId) {
        $this->db->select('*')
                ->from('student_exam_types');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('exam_status !=', 'D');
        $this->db->where('userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function export_examtypes_data($userId) {
        $this->db->select('exam_name');
        $this->db->from('student_exam_types');
        $this->db->where('exam_status !=', 'D');
        $this->db->where('userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function toCheckExamTypesWithExams($examtype_id) {
        $this->db->select('*');
        $this->db->from('student_class_exams');
        $this->db->where('exam_type_id', $examtype_id);
        $result = $this->db->get()->num_rows();
        return $result;
    }

    function toCheckExamTypeName($examtype_name, $examtype_id, $table, $userId) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('exam_name', $examtype_name);
        $this->db->where('exam_status!=', 'D');
        if (!empty($examtype_id)) {
            $this->db->where('id!=', $examtype_id);
        }
        $this->db->where('userid', $userId);
        $query = $this->db->get();
        return $query->row_array();
    }

}
