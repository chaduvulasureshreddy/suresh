<?php

class subject_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Users
     * @param type $where
     */
    public function get_subjects($where = null, $userId) {
        $this->db->select('ss.*,sc.class_name');
        $this->db->from('student_class_subjects ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('ss.subject_status !=', 'D');
        $this->db->where('ss.userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function export_subjects_data($userId) {
        $this->db->select('sc.class_name, ss.subject_name');
        $this->db->from('student_class_subjects ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->where('ss.subject_status !=', 'D');
        $this->db->where('ss.userid', $userId);
        $result = $this->db->get()->result_array();
        return $result;
    }

    function toCheckSubjectName($subject_name, $class_id, $subject_id, $table, $userId) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where('subject_name', $subject_name);
        $this->db->where('class_id', $class_id);
        $this->db->where('userid', $userId);
        $this->db->where('subject_status!=', 'D');
        if (!empty($subject_id)) {
            $this->db->where('id!=', $subject_id);
        }
        $query = $this->db->get();
        return $query->row_array();
    }

    public function toCheckStudentsWithThisSubject($subject_id) {
        $this->db->select('*');
        $this->db->from('student_class_exams');
        $this->db->where('subject_id', $subject_id);
        $result = $this->db->get()->num_rows();
        return $result;
    }

}
