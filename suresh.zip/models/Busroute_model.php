<?php

class busroute_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Drivers
     * @param type $where
     */
    function get_busroutes($id) {
        $this->db->select('*');
        $this->db->from('student_bus_routes');
        $this->db->where('userid', $id);
        $this->db->where('status !=', 'D');
        $this->db->order_by('id','DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    function export_busroutes_data($id) {
        $this->db->select('*');
        $this->db->from('student_bus_routes');
        $this->db->where('userid', $id);
        $this->db->where('status !=', 'D');
        $this->db->order_by('id','DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    function get_busroute_data($id) {
        $this->db->select('*');
        $this->db->from('student_bus_routes');
        $this->db->where('id', $id);
        $result = $this->db->get()->row_array();
        return $result;
    }

    function view_busroute_data($id) {
        $this->db->select('*');
        $this->db->from('student_bus_routes');
        $this->db->where('id', $id);
        $this->db->where('status !=', 'D');
        $result = $this->db->get()->row_array();
        return $result;
    }

    function getBusrouteDetailsByNumber($route_no, $id) {
        $this->db->select('*');
        $this->db->from("student_bus_routes");
        $this->db->where('route_no', $route_no);
        if ($id) {
            $this->db->where('id!=', $id);
        }
        $query = $this->db->get();
        return $query->row_array();
    }

    function getBusrouteDetailsById($field, $id, $table) {
        $this->db->select('*');
        $this->db->from($table);
        $this->db->where($field, $id);
        $this->db->where('status!=', 'D');
        $query = $this->db->get();
        return $query->row_array();
    }

}
