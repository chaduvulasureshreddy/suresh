<?php

class attendance_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Homework
     * @param type $where
     */
    public function attendanceInfo($id) {
        $this->db->select('*');
        $this->db->from('student_attendance');
        $this->db->where('id', $id);
        $result = $this->db->get();
        return $result->row_array();
    }

    public function edit_attendance($where = null) {
        $this->db->select('sal.*,spi.student_name,spi.student_mobile,spi.sch_admission_id,sc.class_name,scs.section_name');
        $this->db->from('student_attendance_list sal');
        $this->db->join('student_profile_info spi', 'spi.sch_admission_id = sal.student_admission_id', 'LEFT');
        $this->db->join('student_classes sc', 'sc.id = spi.student_class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = spi.student_section_id', 'LEFT');
        if ($where) {
            $this->db->where($where);
        }
        $this->db->where('sal.attendance_status !=', 'D');
        $this->db->where('spi.student_status !=', 'D');
        $this->db->order_by('spi.student_name');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function manage_attendance($id, $class_id, $section_id, $date) {
        $this->db->select('ss.*,sc.class_name,scs.section_name');
        $this->db->from('student_attendance ss');
        $this->db->join('student_classes sc', 'sc.id = ss.class_id', 'LEFT');
        $this->db->join('student_class_sections scs', 'scs.id = ss.section_id', 'LEFT');
        if ($date) {
            $this->db->where('ss.attendance_date', $date);
        }
        if ($class_id) {
            $this->db->where('ss.class_id', $class_id);
        }
        if ($section_id) {
            $this->db->where('ss.section_id', $section_id);
        }
        $this->db->where('ss.userid', $id);
        $this->db->where('ss.attendance_status !=', 'D');
        $this->db->order_by('ss.id', 'DESC');
        $result = $this->db->get()->result_array();
        return $result;
    }

    public function get_by($table, $where) {
        if ($table != '') {
            $this->db->from($table);
            $this->db->where($where);
            $this->db->where('attendance_status !=', 'D');
            $this->db->order_by('created_date', 'desc');
            $results = $this->db->get()->row();
            if ($results) {
                return $results;
            }
        }

        return false;
    }

    function toGetStudentsCount($attendance_id, $type) {
        $this->db->from('student_attendance_list');
        $this->db->where('attendance_id', $attendance_id);
        $this->db->where('attendance_status !=', 'D');
        if ($type == 1) {
            $this->db->where('status !=', '');
        } elseif ($type == 2) {
            $this->db->where('status', 'P');
        } elseif ($type == 3) {
            $this->db->where('status', 'M');
        } elseif ($type == 4) {
            $this->db->where('status', 'E');
        } elseif ($type == 5) {
            $this->db->where('status', 'F');
        }
        $result = $this->db->get()->num_rows();
        return $result;
    }

}
