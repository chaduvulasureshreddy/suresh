<?php

class dashboard_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }

    /**
     * Get Students Count
     * @param type $id
     */
    function get_students($id) {
        $this->db->from('student_profile_info spi');
        $this->db->join('student_classes sc', 'sc.id=spi.student_class_id');
        $this->db->join('student_class_sections scs', 'scs.id=spi.student_section_id');
        $this->db->where('spi.userid', $id);
        $this->db->where('spi.student_status !=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Classes Count
     * @param type $id
     */
    function get_classes($id) {
        $this->db->from('student_classes');
        $this->db->where('userid =', $id);
        $this->db->where('status !=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Sections Count
     * @param type $id
     */
    function get_sections($id) {
        $this->db->from('student_class_sections');
        $this->db->where('userid =', $id);
        $this->db->where('status !=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Homework Count
     * @param type $id
     */
    function get_homeworks($id) {
        $this->db->from('student_home_work');
        $this->db->where('userid =', $id);
        $this->db->where('home_work_status !=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Remarks Count
     * @param type $id
     */
    function get_remarks($id) {
        $this->db->from('student_remarks');
        $this->db->where('userid =', $id);
        $this->db->where('remark_status !=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Attendance Count
     * @param type $id
     */
    function get_attendance($id) {
        $this->db->from('student_attendance');
        $this->db->where('userid =', $id);
        $this->db->where('attendance_status !=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Fee Count
     * @param type $id
     */
    function get_fee_pedning_details($id) {
        $this->db->select_sum('balance_amount');
        $this->db->from('student_fee');
        $this->db->where('userid =', $id);
        $this->db->where('fee_status', 'A');
        $result = $this->db->get()->result_array();
        return $result;
    }

    function get_fee_paid_details($id) {
        $this->db->select_sum('paid_amount');
        $this->db->from('student_fee');
        $this->db->where('userid =', $id);
        $this->db->where('fee_status', 'A');
        $result = $this->db->get()->result_array();
        return $result;
    }

    /**
     * Get Messages Count
     * @param type $id
     */
    function get_messages($id) {
        $this->db->from('student_message_classes');
        $this->db->where('userid =', $id);
        $this->db->where('smc_status!=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    /**
     * Get Subjects Count
     * @param type $id
     */
    function get_subjects($id) {
        $this->db->from('student_class_subjects');
        $this->db->where('userid =', $id);
        $this->db->where('subject_status!=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

    function get_drivers($id) {
        $this->db->from('student_bus_drivers');
        $this->db->where('userid =', $id);
        $this->db->where('driver_status!=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }
    
    function get_busroutes($id){
        $this->db->from('student_bus_routes');
        $this->db->where('userid =', $id);
        $this->db->where('status!=', 'D');
        $result = $this->db->get()->num_rows();
        return $result;
    }

}
