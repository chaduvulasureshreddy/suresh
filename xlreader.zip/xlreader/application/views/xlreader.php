<html>
    <head>
        
    </head>
    <body>
        <form method="POST" action="" enctype='multipart/form-data'>
            <input type="file" name="file" value="" >
            <input type="submit" value="Submit">
        </form>
    </body>
</html>