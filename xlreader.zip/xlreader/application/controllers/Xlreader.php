<?php
defined('BASEPATH') OR exit('No direct script access allowed');
/**
 * Xlreader Controller
 * @author
 * Created On
 */
class Xlreader extends CI_Controller {
    
    public function __construct()
    {
        parent::__construct();
        $this->load->model('xl_model');
        $this->load->library('PHPExcel');
    }

    public function index(){
        if(($_FILES) && ($_FILES['file']['name'])){
            $config = array();
            $config['upload_path'] = COMMON_UPLOAD_PATH.'xl';
            $config['allowed_types'] = 'xls | xlsx';
            $config['max_size'] = '5120';
            $config['overwrite'] = TRUE;
            $config['remove_spaces'] = TRUE;

            $this->load->library('upload', $config);
            $this->upload->initialize($config);

            if ($this->upload->do_upload('file')) {
                $filepath = COMMON_UPLOAD_PATH.'xl/'.$_FILES['file']['name'];
                $objPHPExcel = PHPExcel_IOFactory::load($filepath);
                $allDataInSheet = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);

                if($allDataInSheet){
                    foreach($allDataInSheet as $row){
                        $user_data = array(
                            'first_name' => $row['A'],
                            'last_name' => $row['B'],
                            'email' => $row['C']
                        );

                        $save_data = $this->xl_model->save_data($user_data);
                    }
                }
                
                
            } else {
                echo $this->upload->display_errors();
            }
        }
        
        $this->load->view('xlreader');
    }
    
}
