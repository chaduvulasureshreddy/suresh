<?php

class Xl_model extends CI_Model {

    public function __construct() {
        // Call the CI_Model constructor
        parent::__construct();
        $this->load->database();
    }
    
    public function save_data($data){
        $this->db->insert('xlread', $data);
        $insert_id = $this->db->insert_id();
        return $insert_id;
    }
}
